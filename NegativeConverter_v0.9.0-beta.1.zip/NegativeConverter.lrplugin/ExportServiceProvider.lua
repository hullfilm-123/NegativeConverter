--[[ 네거티브 → 포지티브 변환 : 라이트룸 클래식 "내보내기 대상" 플러그인
     라이트룸이 RAW(CR3 등)를 현상해 16비트 TIFF(ProPhoto)로 렌더링하면, 같은 폴더의 neg_convert.py 가 그것을
     포지티브로 변환합니다. 라이트룸은 서명된 프로그램이라 Windows 스마트 앱 컨트롤에 걸리지 않습니다.
     (Lua 5.1 문법만 사용) ]]

local LrView        = import 'LrView'
local LrDialogs     = import 'LrDialogs'
local LrTasks       = import 'LrTasks'
local LrFileUtils   = import 'LrFileUtils'
local LrPathUtils   = import 'LrPathUtils'
local LrApplication = import 'LrApplication'
local LrShell       = import 'LrShell'
local LrLogger      = import 'LrLogger'

local bind = LrView.bind

local logger = LrLogger('NegConvert')
logger:enable('logfile')                       -- Documents/LrClassicLogs/NegConvert.log
local function log(msg) logger:info(tostring(msg)) end

local okVer, VER = pcall(require, 'Version')                  -- Version.lua: the one place the version number is read from
if not (okVer and type(VER) == 'table') then                  -- (second try: load the file by its path)
	local okL, chunk = pcall(loadfile, LrPathUtils.child(_PLUGIN.path, 'Version.lua'))
	if okL and chunk then okVer, VER = pcall(chunk) end
end
local VERSION_TEXT = (okVer and type(VER) == 'table' and VER.text) or '?'

local resolvedPython                           -- remembered while Lightroom runs: { key = ..., cmd = ... }

---------------------------------------------------------------- small helpers
local function isAscii(s) return not string.find(s, '[\128-\255]') end

local function trim(s)
	s = tostring(s or '')
	s = string.gsub(s, '^%s+', '')
	s = string.gsub(s, '%s+$', '')
	return s
end

local function num(x)                          -- always a decimal POINT, whatever the system language
	local s = string.format('%.4f', tonumber(x) or 0)
	s = string.gsub(s, ',', '.')
	return s
end

local function flag(b) if b then return '1' end return '0' end

local function split(s, sep)
	local out, pos = {}, 1
	while true do
		local i = string.find(s, sep, pos, true)
		if not i then out[#out + 1] = string.sub(s, pos); break end
		out[#out + 1] = string.sub(s, pos, i - 1)
		pos = i + #sep
	end
	return out
end

local function quote(p)
	if WIN_ENV then return '"' .. p .. '"' end
	local q = string.gsub(p, "'", "'\\''")
	return "'" .. q .. "'"
end

local function readFile(path)
	local f = io.open(path, 'rb')
	if not f then return nil end
	local t = f:read('*a')
	f:close()
	return t
end

local function writeFile(path, text)
	local f, err = io.open(path, 'wb')
	if not f then return false, err end
	f:write(text)
	f:close()
	return true
end

-- Windows: LrTasks.execute hands the line to cmd.exe, which wants the WHOLE line wrapped in one more pair of quotes
local function shell(cmd)
	local line = cmd
	if WIN_ENV then line = '"' .. cmd .. '"' end
	log('execute: ' .. line)
	local code = LrTasks.execute(line)
	log('exit code: ' .. tostring(code))
	return code
end

---------------------------------------------------------------- where the work files go (plain ASCII path!)
-- Non-ASCII characters (a Korean user name in %TEMP%) can get lost on the way to cmd.exe, so the files that appear
-- on the command line live in an ASCII-only folder. Paths of the photos travel inside the UTF-8 job file instead.
local function workDir()
	local base = LrPathUtils.getStandardFilePath('temp')
	if not base or not isAscii(base) then
		if WIN_ENV then
			local ok, pub = pcall(os.getenv, 'PUBLIC')
			base = (ok and pub and isAscii(pub)) and pub or 'C:\\Users\\Public'
		else
			base = '/tmp'
		end
	end
	local dir = LrPathUtils.child(base, 'NegConvert')
	LrFileUtils.createAllDirectories(dir)
	return dir
end

local function engineFile(dir)
	local src = LrPathUtils.child(_PLUGIN.path, 'neg_convert.py')
	if not LrFileUtils.exists(src) then
		return nil, 'neg_convert.py 가 플러그인 폴더에 없습니다: ' .. src
	end
	if isAscii(src) then return src end
	local dst = LrPathUtils.child(dir, 'neg_convert.py')       -- plug-in folder has non-ASCII letters: use a copy
	LrFileUtils.delete(dst)
	LrFileUtils.copy(src, dst)
	if not LrFileUtils.exists(dst) then return nil, 'neg_convert.py 를 ' .. dir .. ' 에 복사하지 못했습니다' end
	return dst
end

---------------------------------------------------------------- finding a Python that has numpy + OpenCV
local function pythonCommand(props)
	local custom = trim(props.python)
	local list
	if custom ~= '' then
		if string.find(custom, '[\\/]') and string.sub(custom, 1, 1) ~= '"' and LrFileUtils.exists(custom) then
			custom = quote(custom)
		end
		list = { custom }
	elseif WIN_ENV then
		list = { 'py -3', 'python', 'python3' }
	else
		list = { 'python3', 'python' }
	end
	local key = table.concat(list, '|')
	if resolvedPython and resolvedPython.key == key then return resolvedPython.cmd end
	local tried = {}
	for _, cand in ipairs(list) do
		if shell(cand .. ' -c "import numpy, cv2"') == 0 then
			resolvedPython = { key = key, cmd = cand }
			return cand
		end
		tried[#tried + 1] = cand
	end
	return nil, tried
end

---------------------------------------------------------------- export dialog
local function sliderRow(f, props, label, key, min, max, fmt, hint)
	return f:row {
		spacing = f:control_spacing(),
		f:static_text { title = label, width = 120, alignment = 'right' },
		f:slider { value = bind { key = key, object = props }, min = min, max = max, width = 220 },
		f:static_text {
			title = bind { key = key, object = props,
				transform = function(v) return string.format(fmt, tonumber(v) or 0) end },
			width = 48,
		},
		f:static_text { title = hint },
	}
end

local function sectionsForTopOfDialog(f, props)
	local function B(key) return bind { key = key, object = props } end
	return {
		{
			title = '네거티브 → 포지티브 변환 · 베타 v' .. VERSION_TEXT,
			bind_to_object = props,

			f:static_text {
				title = '같은 필름의 사진을 한꺼번에 선택해서 내보내면 색이 일정하게 맞춰집니다.\n'
					.. '아래 "파일 설정" 이 TIFF · ProPhoto RGB · 16비트 인지 확인하세요 (창을 열 때 그렇게 맞춰 둡니다).',
				fill_horizontal = 1,
				height_in_lines = 2,
			},

			sliderRow(f, props, '감마 (대비)',     'gamma',    0.5,  1.3, '%.2f', '낮을수록 대비가 강해집니다 (기본 0.85)'),
			sliderRow(f, props, 'S자 커브',        'scurve',   0,    0.5, '%.2f', '0 이면 끔 (기본 0.12)'),
			sliderRow(f, props, '채도',            'sat',      0,    2,   '%.2f', '1.00 이 원본 그대로'),
			sliderRow(f, props, '노출 (스톱)',     'exposure', -2,   2,   '%+.2f', '자동 노출 위에 더하는 값'),
			sliderRow(f, props, '파랑 ↔ 노랑',     'blue',     -1.5, 1.5, '%+.2f', '+ 차갑게 / - 따뜻하게'),
			sliderRow(f, props, '초록 ↔ 마젠타',   'tint',     -1,   1,   '%+.2f', '+ 초록 / - 마젠타'),

			f:row {
				spacing = f:control_spacing(),
				f:spacer { width = 120 },
				f:column {
					spacing = f:control_spacing(),
					f:checkbox { title = '파란 채널 복원 (잘려 나간 파랑을 추정으로 채움)', value = B 'fixBlue' },
					f:checkbox { title = '같은 필름 사진들을 함께 분석해 색을 일정하게 (여러 장일 때)', value = B 'roll' },
					f:checkbox { title = '어두운 사진 자동으로 밝히기', value = B 'autoExp' },
					f:checkbox { title = '프레임 인식 확인용 이미지도 저장 (_check.jpg)', value = B 'check' },
				},
			},

			f:separator { fill_horizontal = 1 },

			f:row {
				spacing = f:control_spacing(),
				f:static_text { title = '결과 저장', width = 120, alignment = 'right' },
				f:column {
					spacing = f:control_spacing(),
					f:radio_button { title = '원본 사진 옆의 "positive" 폴더', value = B 'outMode', checked_value = 'beside' },
					f:row {
						f:radio_button { title = '이 폴더:', value = B 'outMode', checked_value = 'folder' },
						f:edit_field { value = B 'outFolder', width_in_chars = 34 },
						f:push_button {
							title = '찾아보기…',
							action = function()
								local r = LrDialogs.runOpenPanel {
									title = '결과를 저장할 폴더',
									canChooseFiles = false, canChooseDirectories = true,
									canCreateDirectories = true, allowsMultipleSelection = false,
								}
								if r and r[1] then
									props.outFolder = r[1]
									props.outMode = 'folder'
								end
							end,
						},
					},
				},
			},

			f:row {
				spacing = f:control_spacing(),
				f:static_text { title = '카탈로그에 추가', width = 120, alignment = 'right' },
				f:popup_menu {
					value = B 'importWhat',
					items = {
						{ title = '프레임 JPG',            value = 'jpg' },
						{ title = '프레임 16비트 TIFF',    value = 'tif' },
						{ title = 'JPG 와 16비트 TIFF 모두', value = 'both' },
						{ title = '추가 안 함',            value = 'none' },
					},
				},
				f:checkbox { title = '끝나면 결과 폴더 열기', value = B 'openFolder' },
			},

			f:row {
				spacing = f:control_spacing(),
				f:static_text { title = 'Python 명령', width = 120, alignment = 'right' },
				f:edit_field { value = B 'python', width_in_chars = 34 },
				f:static_text { title = '비워 두면 자동 (numpy · OpenCV 가 있는 Python 을 찾습니다)' },
			},
		},
	}
end

-- File settings: preset when the dialog opens (the user can still look at / change them in "파일 설정").
-- updateExportSettings repeats them for the render itself - some Lightroom versions ignore values set there, which is
-- why the result is checked afterwards (the engine reports the colour space and bit depth it really got).
local function applyFileSettings(t)
	t.LR_format = 'TIFF'
	t.LR_export_colorSpace = 'ProPhotoRGB'
	t.LR_export_bitDepth = 16
	t.LR_tiff_bitDepth = 16
	t.LR_tiff_compressionMethod = 'compressionMethod_None'
	t.LR_size_doConstrain = false
	t.LR_outputSharpeningOn = false
end

local function startDialog(props) applyFileSettings(props) end

local function updateExportSettings(exportSettings) applyFileSettings(exportSettings) end

---------------------------------------------------------------- the actual work
local function parseResult(text)
	local rows = {}
	for line in string.gmatch(text or '', '[^\r\n]+') do
		local c = split(line, '\t')
		rows[#rows + 1] = { status = c[1] or '', name = c[2] or '', crop = c[3] or '', tif = c[4] or '',
			info = c[5] or '', msg = c[6] or '' }
	end
	return rows
end

local function tail(text, n)
	text = text or ''
	if #text > n then return '…' .. string.sub(text, #text - n + 1) end
	return text
end

local function processRenderedPhotos(functionContext, exportContext)
	local props = exportContext.propertyTable
	local session = exportContext.exportSession
	local total = session:countRenditions()
	log('--- export started, version ' .. VERSION_TEXT .. ', ' .. total .. ' photo(s)')
	local progress = exportContext:configureProgress { title = '네거티브 변환 - 라이트룸이 현상하는 중 (' .. total .. '장)' }

	-- 1. let Lightroom render every photo, remember the temp files
	local items, rendered, renderFailed, used, warnings = {}, {}, {}, {}, {}
	for i, rendition in exportContext:renditions { stopIfCanceled = true } do
		progress:setPortionComplete((i - 1) / total)
		local ok, pathOrMessage = rendition:waitForRender()
		if progress:isCanceled() then break end
		if ok then
			rendered[#rendered + 1] = pathOrMessage
			local src = rendition.photo:getRawMetadata('path') or pathOrMessage
			local stem = LrPathUtils.removeExtension(LrPathUtils.leafName(src))
			local out
			if props.outMode == 'folder' and trim(props.outFolder) ~= '' then
				out = trim(props.outFolder)
			else
				out = LrPathUtils.child(LrPathUtils.parent(src), 'positive')
			end
			local name, n = stem, 1
			while used[string.lower(out .. '|' .. name)] do n = n + 1; name = stem .. '_' .. n end
			used[string.lower(out .. '|' .. name)] = true
			if not string.find(string.lower(pathOrMessage), '%.tiff?$') then
				warnings[#warnings + 1] = stem .. ': 라이트룸이 TIFF 가 아닌 파일을 만들었습니다 (' .. pathOrMessage .. ')'
			end
			items[#items + 1] = { path = pathOrMessage, out = out, name = name }
		else
			renderFailed[#renderFailed + 1] = tostring(pathOrMessage)
		end
	end
	if progress:isCanceled() or #items == 0 then
		for _, p in ipairs(rendered) do LrTasks.pcall(LrFileUtils.delete, p) end
		if #renderFailed > 0 then
			LrDialogs.message('네거티브 변환', '라이트룸이 사진을 렌더링하지 못했습니다:\n' .. table.concat(renderFailed, '\n'), 'critical')
		end
		return
	end
	LrTasks.pcall(function() progress:setCaption('Python 으로 변환하는 중 (' .. #items .. '장) - 장당 10~30초 걸립니다') end)
	LrTasks.pcall(function() progress:setIndeterminate() end)

	-- 2. job file + run the engine
	local function cleanup() for _, p in ipairs(rendered) do LrTasks.pcall(LrFileUtils.delete, p) end end
	local dir = workDir()
	local python, tried = pythonCommand(props)
	if not python then
		cleanup()
		LrDialogs.message('네거티브 변환 - Python 을 찾지 못했습니다',
			'numpy 와 OpenCV 가 설치된 Python 을 실행하지 못했습니다.\n시도한 명령: ' .. table.concat(tried, ',  ')
			.. '\n\n내보내기 창 아래쪽 "Python 명령" 칸에 python.exe 의 전체 경로를 적어 주세요.\n'
			.. '(neg_convert_gui.bat 이 잘 되는 PC 라면 CMD 에서  where python  /  py -0p  로 경로를 확인할 수 있습니다)', 'critical')
		return
	end
	local engine, err = engineFile(dir)
	if not engine then cleanup(); LrDialogs.message('네거티브 변환', err, 'critical'); return end

	local jobPath, logPath, resultPath = LrPathUtils.child(dir, 'job.txt'), LrPathUtils.child(dir, 'log.txt'), LrPathUtils.child(dir, 'result.txt')
	LrFileUtils.delete(resultPath)
	LrFileUtils.delete(logPath)
	local job = {
		'version=1',
		'gamma=' .. num(props.gamma), 'scurve=' .. num(props.scurve), 'sat=' .. num(props.sat),
		'exposure=' .. num(props.exposure), 'blue=' .. num(props.blue), 'tint=' .. num(props.tint),
		'inset=20',
		'fixblue=' .. flag(props.fixBlue), 'roll=' .. flag(props.roll), 'autoexp=' .. flag(props.autoExp),
		'check=' .. flag(props.check), 'input=auto',
		'result=' .. resultPath,
	}
	for _, it in ipairs(items) do job[#job + 1] = 'item=' .. it.path .. '\t' .. it.out .. '\t' .. it.name end
	local okw, werr = writeFile(jobPath, table.concat(job, '\n') .. '\n')
	if not okw then cleanup(); LrDialogs.message('네거티브 변환', '작업 파일을 쓰지 못했습니다: ' .. tostring(werr), 'critical'); return end

	local cmd = python .. ' ' .. quote(engine) .. ' --job ' .. quote(jobPath) .. ' > ' .. quote(logPath) .. ' 2>&1'
	local code = shell(cmd)
	local result = readFile(resultPath)
	cleanup()                                                  -- the big temp TIFFs are not needed any more

	if not result then
		LrDialogs.message('네거티브 변환 - 변환에 실패했습니다',
			'종료 코드 ' .. tostring(code) .. '. 결과 목록이 만들어지지 않았습니다.\n\n로그 끝부분:\n' .. tail(readFile(logPath) or '(로그 없음)', 1500)
			.. '\n\n전체 로그: ' .. logPath, 'critical')
		return
	end

	-- 3. report, optionally add the results to the catalog
	local rows = parseResult(result)
	local nOk, nWarn, nFail, nSrgb, lines = 0, 0, 0, 0, {}
	for _, r in ipairs(rows) do
		if r.status ~= 'fail' and string.find(r.info, '^sRGB') then nSrgb = nSrgb + 1 end
		if r.status == 'ok' then nOk = nOk + 1
		elseif r.status == 'warn' then nWarn = nWarn + 1; lines[#lines + 1] = '⚠ ' .. r.name .. ': ' .. tail(r.msg, 260)
		else nFail = nFail + 1; lines[#lines + 1] = '✘ ' .. r.name .. ': ' .. tail(r.msg, 260) end
	end
	for _, w in ipairs(warnings) do lines[#lines + 1] = '⚠ ' .. w end
	if nSrgb > 0 then
		lines[#lines + 1] = 'ℹ ' .. nSrgb .. '장이 sRGB 로 내보내졌습니다. ProPhoto RGB 로 내보내야 파랑이 덜 잘립니다 (파란 채널 복원이 보정하지만 추정값입니다). 내보내기 창의 "파일 설정 > 색 공간" 을 확인하세요.'
	end

	local imported = 0
	if props.importWhat ~= 'none' then
		local paths = {}
		for _, r in ipairs(rows) do
			if r.status ~= 'fail' then
				if (props.importWhat == 'jpg' or props.importWhat == 'both') and r.crop ~= '' then paths[#paths + 1] = r.crop end
				if (props.importWhat == 'tif' or props.importWhat == 'both') and r.tif ~= '' then paths[#paths + 1] = r.tif end
			end
		end
		if #paths > 0 then
			local catalog = LrApplication.activeCatalog()
			local okc, cerr = LrTasks.pcall(function()
				catalog:withWriteAccessDo('네거티브 변환 결과 추가', function()
					for _, p in ipairs(paths) do
						local oka = LrTasks.pcall(function() catalog:addPhoto(p) end)
						if oka then imported = imported + 1 end
					end
				end, { timeout = 20 })
			end)
			if not okc then lines[#lines + 1] = '⚠ 카탈로그에 추가하지 못했습니다: ' .. tostring(cerr) end
		end
	end

	if props.openFolder and items[1] then LrTasks.pcall(LrShell.revealInShell, LrPathUtils.child(items[1].out, items[1].name .. '_positive_crop.jpg')) end

	local head = '완료 ' .. nOk .. '장 · 확인 필요 ' .. nWarn .. '장 · 실패 ' .. nFail .. '장'
	if props.importWhat ~= 'none' then head = head .. ' · 카탈로그에 ' .. imported .. '개 추가' end
	local body = head .. '\n저장 위치: ' .. items[1].out
	if #lines > 0 then body = body .. '\n\n' .. table.concat(lines, '\n', 1, math.min(#lines, 12)) end
	if nFail > 0 or nWarn > 0 or nSrgb > 0 then body = body .. '\n\n자세한 로그: ' .. logPath end
	LrDialogs.message('네거티브 변환', body, (nFail > 0) and 'warning' or 'info')
end

---------------------------------------------------------------- the service provider
return {
	hideSections = { 'exportLocation', 'fileNaming', 'imageSettings', 'outputSharpening', 'metadata', 'watermarking' },
	allowFileFormats = { 'TIFF' },
	canExportVideo = false,
	hidePrintResolution = true,

	exportPresetFields = {
		{ key = 'gamma',      default = 0.85 },
		{ key = 'scurve',     default = 0.12 },
		{ key = 'sat',        default = 1.0 },
		{ key = 'exposure',   default = 0.0 },
		{ key = 'blue',       default = 0.0 },
		{ key = 'tint',       default = 0.0 },
		{ key = 'fixBlue',    default = true },
		{ key = 'roll',       default = true },
		{ key = 'autoExp',    default = true },
		{ key = 'check',      default = false },
		{ key = 'outMode',    default = 'beside' },
		{ key = 'outFolder',  default = '' },
		{ key = 'importWhat', default = 'jpg' },
		{ key = 'openFolder', default = false },
		{ key = 'python',     default = '' },
	},

	startDialog = startDialog,
	sectionsForTopOfDialog = sectionsForTopOfDialog,
	updateExportSettings = updateExportSettings,
	processRenderedPhotos = processRenderedPhotos,
}
