return {
	LrSdkVersion = 6.0,
	LrSdkMinimumVersion = 5.0,
	LrToolkitIdentifier = 'local.negconvert.lightroom',
	LrPluginName = '네거티브 → 포지티브 변환 (베타)',

	LrExportServiceProvider = {
		title = '네거티브 → 포지티브 변환',
		file = 'ExportServiceProvider.lua',
	},

	LrExportMenuItems = {
		{ title = '네거티브 변환 패널 열기…', file = 'NegPanel.lua' },
	},

	LrLibraryMenuItems = {
		{ title = '네거티브 변환 패널 열기…', file = 'NegPanel.lua' },
		{
			title = '네거티브 스캔용 중립 현상 적용 (선택한 사진)',
			file = 'ApplyNeutral.lua',
			enabledWhen = 'photosSelected',
		},
	},

	-- 베타 버전. Version.lua 와 같은 숫자 (tools/bump_version.py 가 함께 바꿉니다)
	VERSION = { major = 0, minor = 9, revision = 0, build = 1, display = '0.9.0-beta.1' },
}
