--[[ 이 플러그인의 버전 (패널 제목 · 내보내기 창 · 로그가 여기서 읽습니다).
     Info.lua 의 VERSION 도 같은 숫자여야 합니다 (플러그인 관리자에 표시). 고칠 때는 tools/bump_version.py 가 한꺼번에 바꿉니다.
     버전 규칙: 베타 동안은 0.9.0-beta.N 의 N 을 패치마다 1씩 올립니다. 정식은 1.0.0. ]]
return {
	major = 0, minor = 9, revision = 0, build = 1,
	text = '0.9.0-beta.1',
	date = '2026-11-26',
}
