--[[ 네거티브 변환 패널 (라이트룸 클래식, Negative Lab Pro 방식)
     RAW 는 그대로 두고, 변환 결과를 "현상 설정"(채널별 톤 커브 + 자르기)으로 사진에 적용합니다.
     라이트룸은 픽셀을 읽는 방법이 없어서, 분석에는 작은(긴 변 2400px) 임시 렌더 한 장만 씁니다 (자동 · 자동 삭제).
     사진마다: 분석 -> 패널 미리보기를 보며 슬라이더 조정 -> [확인] 을 누르면 그때 사진에 적용 -> 다음 사진.
     (Lua 5.1 문법만 사용; 기다릴 수 있는 SDK 호출은 일반 pcall 이 아니라 LrTasks.pcall 로 감쌉니다) ]]

local LrApplication     = import 'LrApplication'
local LrTasks           = import 'LrTasks'
local LrDialogs         = import 'LrDialogs'
local LrView            = import 'LrView'
local LrBinding         = import 'LrBinding'
local LrFunctionContext = import 'LrFunctionContext'
local LrFileUtils       = import 'LrFileUtils'
local LrPathUtils       = import 'LrPathUtils'
local LrExportSession   = import 'LrExportSession'
local LrLogger          = import 'LrLogger'
local LrPrefs           = import 'LrPrefs'
local okSI, LrSystemInfo = pcall(import, 'LrSystemInfo')          -- only used to size the enlarged view; absent = default size

local bind = LrView.bind
local logger = LrLogger('NegConvert')
logger:enable('logfile')
local function log(msg) logger:info(tostring(msg)) end
local okVer, VER = pcall(require, 'Version')                  -- Version.lua: the one place the version number is read from
if not (okVer and type(VER) == 'table') then                  -- (second try: load the file by its path)
	local okL, chunk = pcall(loadfile, LrPathUtils.child(_PLUGIN.path, 'Version.lua'))
	if okL and chunk then okVer, VER = pcall(chunk) end
end
local VERSION_TEXT = (okVer and type(VER) == 'table' and VER.text) or '?'

local ANALYSIS_PX = 2400
local function concatLists(...)
	local out = {}
	for _, l in ipairs({ ... }) do for _, v in ipairs(l) do out[#out + 1] = v end end
	return out
end
-- Edit tab: numbers + check boxes; Detail tab: Lightroom's own detail settings (applied at [확인], not in the preview)
local EDIT_NUM = { 'exposure', 'gamma', 'scurve', 'bright', 'lights', 'darks', 'whites', 'blacks', 'fade', 'sat', 'hilite',
	'blue', 'tint', 'wclip', 'bclip', 'mdR', 'mdG', 'mdB', 'hiR', 'hiG', 'hiB', 'shR', 'shG', 'shB', 'hiRange', 'shRange' }
local EDIT_BOOL = { 'softHi', 'softLo' }
local DETAIL_KEYS = { 'sharp', 'radius', 'nrLum', 'nrColor', 'grain', 'clarity', 'texture' }
local CONVERT_KEYS = { 'model', 'presat', 'border', 'autoExp', 'autoCrop', 'noSat' }
local VALUE_KEYS = concatLists(EDIT_NUM, EDIT_BOOL, DETAIL_KEYS)      -- what presets / copy / reset / the "first conversion" snapshot work on
local VIEW_KEYS = { 'rot' }                                           -- how the preview is shown (turned), not a look
local LOOK_KEYS = concatLists(EDIT_NUM, EDIT_BOOL, CONVERT_KEYS, VIEW_KEYS)      -- everything that changes the preview
local PHOTO_KEYS = { exposure = true, blue = true, tint = true, wclip = true, bclip = true }    -- per photo: presets and copy leave them alone
local LOOK_DEFAULTS = { exposure = 0.0, gamma = 0.85, scurve = 0.12, bright = 0, lights = 0, darks = 0, whites = 0, blacks = 0, fade = 0,
	sat = 1.0, hilite = 0.0, blue = 0.0, tint = 0.0, wclip = 0.0, bclip = 0.0,
	mdR = 0, mdG = 0, mdB = 0, hiR = 0, hiG = 0, hiB = 0, shR = 0, shG = 0, shB = 0, hiRange = 5, shRange = 5,
	softHi = false, softLo = false, rot = 0 }
-- Lightroom's usual start values for a raw file (sharpening 25 / radius 1.0 / colour noise 25)
local DETAIL_DEFAULTS = { sharp = 25, radius = 1.0, nrLum = 0, nrColor = 25, grain = 0, clarity = 0, texture = 0 }
local OPTION_DEFAULTS = { autoExp = true, autoCrop = true, carry = false, python = '', preset = 'standard', profile = 'standard',
	model = 'noritsu', presat = 3, border = 0.5, verify = true, noSat = false }
local PREVIEW_W, PREVIEW_H = 480, 314

math.randomseed(os.time())
local TOKEN = tostring(math.random(10000, 99999))          -- keeps the files of two open panels apart

---------------------------------------------------------------- helpers
local function isAscii(s) return not string.find(s, '[\128-\255]') end

local function trim(s)
	s = tostring(s or '')
	s = string.gsub(s, '^%s+', '')
	s = string.gsub(s, '%s+$', '')
	return s
end

local function num(x)
	local s = string.format('%.4f', tonumber(x) or 0)
	s = string.gsub(s, ',', '.')
	return s
end

local function split(s, sep)
	local out, pos = {}, 1
	while true do
		local i = string.find(s, sep, pos, true)
		if not i then out[#out + 1] = string.sub(s, pos); break end
		out[#out + 1] = string.sub(s, pos, i - 1)
		pos = i + #sep
	end
	return out
end

local function quote(p)
	if WIN_ENV then return '"' .. p .. '"' end
	local q = string.gsub(p, "'", "'\\''")
	return "'" .. q .. "'"
end

local function readFile(path)
	local f = io.open(path, 'rb')
	if not f then return nil end
	local t = f:read('*a')
	f:close()
	return t
end

local function writeFile(path, text)
	local f, err = io.open(path, 'wb')
	if not f then return false, err end
	f:write(text)
	f:close()
	return true
end

local function shell(cmd)
	local line = cmd
	if WIN_ENV then line = '"' .. cmd .. '"' end
	log('execute: ' .. line)
	local code = LrTasks.execute(line)
	log('exit code: ' .. tostring(code))
	return code
end

-- plain-ASCII folder for everything that appears on a command line (see ExportServiceProvider.lua)
local function workDir()
	local base = LrPathUtils.getStandardFilePath('temp')
	if not base or not isAscii(base) then
		if WIN_ENV then
			local ok, pub = pcall(os.getenv, 'PUBLIC')
			base = (ok and pub and isAscii(pub)) and pub or 'C:\\Users\\Public'
		else
			base = '/tmp'
		end
	end
	local dir = LrPathUtils.child(base, 'NegConvert')
	LrFileUtils.createAllDirectories(dir)
	return dir
end

local function engineFile(dir)
	local src = LrPathUtils.child(_PLUGIN.path, 'neg_convert.py')
	if not LrFileUtils.exists(src) then return nil, 'neg_convert.py 가 플러그인 폴더에 없습니다: ' .. src end
	if isAscii(src) then return src end
	local dst = LrPathUtils.child(dir, 'neg_convert.py')
	LrFileUtils.delete(dst)
	LrFileUtils.copy(src, dst)
	if not LrFileUtils.exists(dst) then return nil, 'neg_convert.py 를 ' .. dir .. ' 에 복사하지 못했습니다' end
	return dst
end

local resolvedPython
local function pythonCommand(custom)
	custom = trim(custom)
	local list
	if custom ~= '' then
		if string.find(custom, '[\\/]') and string.sub(custom, 1, 1) ~= '"' and LrFileUtils.exists(custom) then custom = quote(custom) end
		list = { custom }
	elseif WIN_ENV then
		list = { 'py -3', 'python', 'python3' }
	else
		list = { 'python3', 'python' }
	end
	local key = table.concat(list, '|')
	if resolvedPython and resolvedPython.key == key then return resolvedPython.cmd end
	local tried = {}
	for _, cand in ipairs(list) do
		if shell(cand .. ' -c "import numpy, cv2"') == 0 then
			resolvedPython = { key = key, cmd = cand }
			return cand
		end
		tried[#tried + 1] = cand
	end
	return nil, tried
end

---------------------------------------------------------------- develop settings
local LINEAR = { 0, 0, 255, 255 }

-- the state the analysis render is taken in: nothing that changes tones or colours, no crop
local NEUTRAL = {
	ToneCurveName2012 = 'Linear',
	ToneCurvePV2012 = LINEAR, ToneCurvePV2012Red = LINEAR, ToneCurvePV2012Green = LINEAR, ToneCurvePV2012Blue = LINEAR,
	Exposure2012 = 0, Contrast2012 = 0, Highlights2012 = 0, Shadows2012 = 0, Whites2012 = 0, Blacks2012 = 0,
	Texture = 0, Clarity2012 = 0, Dehaze = 0, Vibrance = 0, Saturation = 0,
	Sharpness = 0, SharpenRadius = 1.0, LuminanceSmoothing = 0, ColorNoiseReduction = 0, GrainAmount = 0,
}
local NO_CROP = { CropLeft = 0, CropTop = 0, CropRight = 1, CropBottom = 1, CropAngle = 0, HasCrop = false }
-- more settings that would change the analysis render if the photo already carries them (HSL, colour grading, calibration, ...).
-- They are only touched when this Lightroom reports them and they are not neutral; the complete original settings are backed up first.
local NEUTRAL_EXTRA = {
	ParametricShadows = 0, ParametricDarks = 0, ParametricLights = 0, ParametricHighlights = 0,
	SplitToningShadowSaturation = 0, SplitToningHighlightSaturation = 0, SplitToningBalance = 0,
	ColorGradeMidtoneSat = 0, ColorGradeShadowLum = 0, ColorGradeMidtoneLum = 0, ColorGradeHighlightLum = 0,
	ColorGradeGlobalSat = 0, ColorGradeGlobalLum = 0,
	ShadowTint = 0, RedHue = 0, RedSaturation = 0, GreenHue = 0, GreenSaturation = 0, BlueHue = 0, BlueSaturation = 0,
	PostCropVignetteAmount = 0, DefringePurpleAmount = 0, DefringeGreenAmount = 0, ConvertToGrayscale = false,
}
-- Newer Lightroom versions keep a second copy of the tone curves (ExtendedToneCurvePV2012 / Red / Green / Blue) next to the usual ones, and
-- add it to a photo as soon as Lightroom's own screens look at it. When that copy holds the old curve, resetting only the usual keys leaves
-- the picture converted (and a new conversion has no effect). So both copies are always written together, and only when the photo reports them.
local EXT_KEY = { ToneCurvePV2012 = 'ExtendedToneCurvePV2012', ToneCurvePV2012Red = 'ExtendedToneCurvePV2012Red',
	ToneCurvePV2012Green = 'ExtendedToneCurvePV2012Green', ToneCurvePV2012Blue = 'ExtendedToneCurvePV2012Blue' }
local EXT_NEUTRAL = {}
for _, ext in pairs(EXT_KEY) do NEUTRAL_EXTRA[ext] = LINEAR; EXT_NEUTRAL[ext] = LINEAR end
for _, c in ipairs({ 'Red', 'Orange', 'Yellow', 'Green', 'Aqua', 'Blue', 'Purple', 'Magenta' }) do
	NEUTRAL_EXTRA['HueAdjustment' .. c] = 0
	NEUTRAL_EXTRA['SaturationAdjustment' .. c] = 0
	NEUTRAL_EXTRA['LuminanceAdjustment' .. c] = 0
end

local function shortErr(e)
	e = string.gsub(tostring(e or ''), '[\r\n]+', ' ')
	if #e > 400 then e = string.sub(e, 1, 400) .. '…' end
	return e
end

-- NOTE: plain pcall() must not wrap SDK calls that may yield (error "Yielding is not allowed within a C or metamethod call"); LrTasks.pcall() is the yield-safe version.
-- Lightroom refuses a write call at once when another plug-in (or Lightroom itself) is writing to the catalog,
-- unless a timeout is given. So: wait up to 20 s per try and try again a few times.
local function withWrite(catalog, name, fn)
	local lastErr, lastRes = nil, nil
	for attempt = 1, 4 do
		local ok, res = LrTasks.pcall(function() return catalog:withWriteAccessDo(name, fn, { timeout = 20 }) end)
		if ok and (res == nil or res == 'executed') then return true end
		lastRes, lastErr = (ok and res or nil), (not ok) and shortErr(res) or nil
		log('write access try ' .. attempt .. ' failed: ' .. tostring(lastErr or lastRes))
		if attempt < 4 then LrTasks.sleep(1.5) end
	end
	return false, lastErr or ('카탈로그 쓰기 권한을 얻지 못했습니다 (결과: ' .. tostring(lastRes) .. ')')
end

-- apply settings; when Lightroom refuses the whole table, try key by key and report the culprits with Lightroom's own message
local function applySettings(catalog, photo, settings, history)
	local bad, nKeys, firstErr = {}, 0, nil
	for _ in pairs(settings) do nKeys = nKeys + 1 end
	local ok, err = withWrite(catalog, history, function()
		bad, firstErr = {}, nil
		local okAll, errAll = LrTasks.pcall(function() photo:applyDevelopSettings(settings, history) end)
		if not okAll then
			firstErr = shortErr(errAll)
			log('settings table refused (' .. history .. '): ' .. firstErr)
			for k, v in pairs(settings) do
				local okK, errK = LrTasks.pcall(function() photo:applyDevelopSettings({ [k] = v }, history) end)
				if not okK then
					bad[#bad + 1] = k .. ' (' .. shortErr(errK) .. ')'
					log('setting refused: ' .. k .. ' -> ' .. shortErr(errK))
				end
			end
		end
	end)
	if not ok then return false, err end
	if #bad >= nKeys then return false, firstErr or '라이트룸이 모든 설정을 거부했습니다' end
	if #bad > 0 then
		return true, '라이트룸이 받아들이지 않은 설정: ' .. table.concat(bad, ', ')
	end
	return true
end

local function copyOf(t) local c = {}; for k, v in pairs(t) do c[k] = v end; return c end
local function merge(a, b) local c = copyOf(a); for k, v in pairs(b) do c[k] = v end; return c end

-- plain copy of a settings table (numbers, strings, booleans, tables of those)
local function deepCopy(v, depth)
	depth = depth or 0
	local t = type(v)
	if t ~= 'table' then
		if t == 'number' or t == 'string' or t == 'boolean' then return v end
		return nil
	end
	if depth > 8 then return nil end
	local c = {}
	for k, x in pairs(v) do
		local tk = type(k)
		if tk == 'string' or tk == 'number' then
			local y = deepCopy(x, depth + 1)
			if y ~= nil then c[k] = y end
		end
	end
	return c
end

local function sameValue(a, b)
	if type(a) ~= type(b) then return false end
	if type(a) == 'number' then return math.abs(a - b) <= 1e-4 + 1e-6 * math.abs(b) end
	if type(a) == 'table' then
		for k, v in pairs(a) do if not sameValue(v, b[k]) then return false end end
		for k in pairs(b) do if a[k] == nil then return false end end
		return true
	end
	return a == b
end

local function currentSettings(photo)
	local ok, cur = LrTasks.pcall(function() return photo:getDevelopSettings() end)
	if ok and type(cur) == 'table' then return cur end
	return nil
end

local ALL_NEUTRAL = merge(merge(NEUTRAL, NEUTRAL_EXTRA), NO_CROP)

-- bring a photo to `target` (a table of develop settings, may be partial): write only what differs, read back (Lightroom can take a moment
-- to report a change), write again what did not stick. returns ok, note, list of keys that still differ afterwards.
-- `absent` (optional): neutral values for keys the plugin writes; a key that `target` does not mention is put back to this value
-- when the photo now differs (a settings table that left a key out means "default").
local function restoreTo(catalog, photo, target, history, absent)
	local cur = currentSettings(photo)
	local diff, n = {}, 0
	for k, v in pairs(target) do
		if cur == nil or not sameValue(cur[k], v) then diff[k] = v; n = n + 1 end
	end
	if absent and cur then
		for k, v in pairs(absent) do
			if target[k] == nil and cur[k] ~= nil and not sameValue(cur[k], v) then diff[k] = v; n = n + 1 end
		end
	end
	if n == 0 then return true, nil, {} end
	local ok, note = applySettings(catalog, photo, diff, history)
	if not ok then return false, note, {} end
	local pending = diff
	for round = 1, 4 do
		LrTasks.sleep(0.4)
		local after = currentSettings(photo)
		if not after then pending = {}; break end                      -- cannot be read back: nothing to verify with
		local nxt, nn = {}, 0
		for k, v in pairs(pending) do if not sameValue(after[k], v) then nxt[k] = v; nn = nn + 1 end end
		pending = nxt
		if nn == 0 then break end
		if round == 2 then applySettings(catalog, photo, pending, history) end      -- still not taken: write it once more
	end
	local left = {}
	for k in pairs(pending) do left[#left + 1] = k end
	table.sort(left)
	return true, note, left
end

-- the analysis state for this photo: every neutral value Lightroom reports (plus the ones the plug-in itself always writes)
local function neutralTarget(photo)
	local cur = currentSettings(photo)
	local t = {}
	for k, v in pairs(ALL_NEUTRAL) do
		if cur == nil or cur[k] ~= nil or NEUTRAL[k] ~= nil or NO_CROP[k] ~= nil then t[k] = v end
	end
	return t
end
local function applyNeutral(catalog, photo, history)
	return restoreTo(catalog, photo, neutralTarget(photo), history)
end

-- 원래대로 without a backup: tones, saturation, detail and crop back to neutral, everything else stays
local PLAIN_BASE = merge(merge(NEUTRAL, NO_CROP), (function() local t = {}; for _, c in ipairs({ 'Red', 'Orange', 'Yellow', 'Green', 'Aqua', 'Blue', 'Purple', 'Magenta' }) do t['SaturationAdjustment' .. c] = 0 end; return t end)())
local function plainTarget(photo)
	local cur = currentSettings(photo)
	local t = {}
	for k, v in pairs(PLAIN_BASE) do t[k] = v end
	for _, ext in pairs(EXT_KEY) do
		if cur and cur[ext] ~= nil then t[ext] = LINEAR end
	end
	return t
end

-- the curves just written must also go into the second copy, when the photo has one
local function withExtended(photo, settings)
	local cur = currentSettings(photo)
	if not cur then return settings end
	local t = copyOf(settings)
	for legacy, ext in pairs(EXT_KEY) do
		if cur[ext] ~= nil and settings[legacy] ~= nil then t[ext] = settings[legacy] end
	end
	return t
end
local function curveKeysLeft(left)
	local out = {}
	for _, k in ipairs(left or {}) do if string.find(k, '^ToneCurve') or string.find(k, '^ExtendedToneCurve') then out[#out + 1] = k end end
	return out
end

local function toNumbers(text)
	local out = {}
	for _, v in ipairs(split(text, ',')) do out[#out + 1] = tonumber(v) end
	return out
end

---------------------------------------------------------------- analysis render (small, wide gamut, 16 bit)
local function renderSmall(photo, tag, opts)
	opts = opts or {}
	local dir = LrPathUtils.child(workDir(), 'r_' .. tostring(photo.localIdentifier) .. tag)
	LrFileUtils.createAllDirectories(dir)
	for p in LrFileUtils.files(dir) do LrFileUtils.delete(p) end
	local settings = {
		LR_exportServiceProvider = 'com.adobe.ag.export.file',
		LR_export_destinationType = 'specificFolder',
		LR_export_destinationPathPrefix = dir,
		LR_export_useSubfolder = false,
		LR_collisionHandling = 'overwrite',
		LR_reimportExportedPhoto = false,
		LR_format = opts.jpeg and 'JPEG' or 'TIFF',
		LR_size_doConstrain = true, LR_size_doNotEnlarge = true, LR_size_resizeType = 'longEdge', LR_size_units = 'pixels',
		LR_size_maxHeight = opts.px or ANALYSIS_PX, LR_size_maxWidth = opts.px or ANALYSIS_PX,
		LR_outputSharpeningOn = false,
		LR_minimizeEmbeddedMetadata = true,
		LR_extensionCase = 'lowercase',
	}
	if opts.jpeg then
		settings.LR_jpeg_quality = 0.85
		settings.LR_export_colorSpace = 'sRGB'
	else
		settings.LR_tiff_compressionMethod = 'compressionMethod_None'
		settings.LR_export_colorSpace = 'ProPhotoRGB'
		settings.LR_export_bitDepth = 16
	end
	local okS, session = LrTasks.pcall(LrExportSession, { photosToExport = { photo }, exportSettings = settings })
	if not okS then return nil, '내보내기 세션을 만들지 못했습니다: ' .. tostring(session) end
	local ok, err = LrTasks.pcall(function() session:doExportOnCurrentTask() end)
	if not ok then return nil, '임시 렌더링에 실패했습니다: ' .. tostring(err) end
	for p in LrFileUtils.files(dir) do
		if string.find(string.lower(p), opts.jpeg and '%.jpe?g$' or '%.tiff?$') then return p end
	end
	return nil, '임시 렌더링 파일을 찾지 못했습니다 (' .. dir .. ')'
end

---------------------------------------------------------------- engine
local engineLocked = false

local function runEngineNow(lines, pythonField)
	local dir = workDir()
	local python, tried = pythonCommand(pythonField)
	if not python then
		return nil, 'Python 을 찾지 못했습니다 (시도: ' .. table.concat(tried, ', ') .. '). 패널 Convert 탭 아래쪽의 "Python 명령" 칸에 python.exe 전체 경로를 적어 주세요 (numpy · OpenCV 필요).'
	end
	local engine, err = engineFile(dir)
	if not engine then return nil, err end
	local cache = LrPathUtils.child(dir, 'cache')
	LrFileUtils.createAllDirectories(cache)
	local jobPath = LrPathUtils.child(dir, 'lrjob_' .. TOKEN .. '.txt')
	local logPath = LrPathUtils.child(dir, 'lrlog_' .. TOKEN .. '.txt')
	local resultPath = LrPathUtils.child(dir, 'lrresult_' .. TOKEN .. '.txt')
	LrFileUtils.delete(resultPath)
	LrFileUtils.delete(logPath)
	local all = {}
	for _, l in ipairs(lines) do all[#all + 1] = l end
	all[#all + 1] = 'result=' .. resultPath
	all[#all + 1] = 'cachedir=' .. cache
	local okw, werr = writeFile(jobPath, table.concat(all, '\n') .. '\n')
	if not okw then return nil, '작업 파일을 쓰지 못했습니다: ' .. tostring(werr) end
	local code = shell(python .. ' ' .. quote(engine) .. ' --job ' .. quote(jobPath) .. ' > ' .. quote(logPath) .. ' 2>&1')
	local text = readFile(resultPath)
	if not text then
		local lg = readFile(logPath) or '(로그 없음)'
		return nil, '변환 엔진이 실패했습니다 (종료 코드 ' .. tostring(code) .. '):\n' .. string.sub(lg, math.max(1, #lg - 900)) .. '\n로그: ' .. logPath
	end
	local rows = {}
	for line in string.gmatch(text, '[^\r\n]+') do rows[#rows + 1] = split(line, '\t') end
	return rows
end

-- one engine run at a time (preview tasks and the conversion flow share the job files)
local function runEngine(lines, pythonField)
	while engineLocked do LrTasks.sleep(0.05) end
	engineLocked = true
	local rows, err
	local ok, e1 = LrTasks.pcall(function() rows, err = runEngineNow(lines, pythonField) end)
	engineLocked = false
	if not ok then return nil, shortErr(e1) end
	return rows, err
end

local function lookLines(p, axis, kind)
	local function flag(v) return v and '1' or '0' end
	return {
		'gamma=' .. num(p.gamma), 'scurve=' .. num(p.scurve), 'hilite=' .. num(p.hilite), 'exposure=' .. num(p.exposure),
		'blue=' .. num(p.blue), 'tint=' .. num(p.tint), 'autoexp=' .. flag(p.autoExp),
		'bright=' .. num(p.bright), 'lights=' .. num(p.lights), 'darks=' .. num(p.darks), 'whites=' .. num(p.whites),
		'blacks=' .. num(p.blacks), 'fade=' .. num(p.fade), 'softhi=' .. flag(p.softHi), 'softlo=' .. flag(p.softLo),
		'wclip=' .. num(p.wclip), 'bclip=' .. num(p.bclip),
		'mdr=' .. num(p.mdR), 'mdg=' .. num(p.mdG), 'mdb=' .. num(p.mdB),
		'hir=' .. num(p.hiR), 'hig=' .. num(p.hiG), 'hib=' .. num(p.hiB), 'hirange=' .. num(p.hiRange),
		'shr=' .. num(p.shR), 'shg=' .. num(p.shG), 'shb=' .. num(p.shB), 'shrange=' .. num(p.shRange),
		'border=' .. num(p.border),
		'axis=' .. axis, 'kind=' .. (kind or 'cubic'),
	}
end

-- engine row (fit / refit) -> develop settings   (p.sat is already the effective saturation: colour model x pre-saturation x slider)
-- The basic-panel Saturation / Vibrance act BEFORE the tone curve, i.e. on the orange negative: a boost there shifts the neutral axis and
-- the picture turns blue. The HSL saturation sliders come after the curve, so the saturation goes there (the same value on all 8 colours).
local HSL_COLORS = { 'Red', 'Orange', 'Yellow', 'Green', 'Aqua', 'Blue', 'Purple', 'Magenta' }
local function curveSettings(row, p, plain)
	local sat = math.floor(((tonumber(p.sat) or 1) - 1) * 100 + 0.5)
	if plain or p.noSat then sat = 0 end                 -- plain: the curve check must see the curves only
	if sat > 100 then sat = 100 elseif sat < -100 then sat = -100 end
	local t = {
		ToneCurveName2012 = 'Custom',
		ToneCurvePV2012 = LINEAR,
		ToneCurvePV2012Red = toNumbers(row[5]), ToneCurvePV2012Green = toNumbers(row[6]), ToneCurvePV2012Blue = toNumbers(row[7]),
		Saturation = 0,
	}
	for _, c in ipairs(HSL_COLORS) do t['SaturationAdjustment' .. c] = sat end
	return t
end

local function cropSettings(row)
	local c = toNumbers(row[4])
	if #c ~= 4 then return nil end
	return { CropLeft = c[1], CropTop = c[2], CropRight = c[3], CropBottom = c[4], CropAngle = 0, HasCrop = true }
end

-- the detail sliders -> Lightroom develop settings (whole numbers, as Lightroom's own sliders)
local function detailSettings(d)
	local function r(x) return math.floor((tonumber(x) or 0) + 0.5) end
	return {
		Sharpness = r(d.sharp), SharpenRadius = math.floor((tonumber(d.radius) or 1) * 10 + 0.5) / 10,
		LuminanceSmoothing = r(d.nrLum), ColorNoiseReduction = r(d.nrColor),
		GrainAmount = r(d.grain), Clarity2012 = r(d.clarity), Texture = r(d.texture),
	}
end

-- what the engine's result depends on (so a preview made for the same values is reused when [확인] is pressed)
local function lookKey(p)
	local parts = {}
	for _, k in ipairs(LOOK_KEYS) do
		local v = p[k]
		if type(v) == 'boolean' then parts[#parts + 1] = v and '1' or '0'
		elseif type(v) == 'string' then parts[#parts + 1] = v
		else parts[#parts + 1] = num(v) end
	end
	return table.concat(parts, '|')
end

local function roundTo(x, step) return math.floor(x / step + 0.5) * step end

---------------------------------------------------------------- the panel
-- colour models (Convert tab). Measured from three same-frame pairs of Kodak ColorPlus 200 (Fuji SP-3000 vs Noritsu HS-1800), see README.
-- Noritsu is the reference of that comparison, so its model is the plain default look. The model multiplies saturation / adds to the
-- highlights (and, for 'basic', to gamma / S-curve) on top of the Edit sliders, which therefore stay where they are.
-- 'basic' = no scanner look at all, the counterpart of a digital camera's RAW: the standard contrast of the sliders (gamma 0.85 +
-- S-curve 0.12) is taken out again (dgamma / dscurve), saturation and highlights are not touched.
local COLOR_MODELS = {
	{ key = 'basic', name = '기본 (스캐너 룩 없음 · RAW 같은 중립)', sat = 1.0, hilite = 0.0, dgamma = 0.15, dscurve = -0.12,
	  note = '스캐너 색감을 넣지 않은 가장 기본적인 변환입니다. RAW 처럼 대비(감마 1.0 · S자 0)를 더하지 않아 밋밋하게 나오니, 필요한 톤은 Edit 탭에서 직접 얹으세요 (슬라이더는 그대로 두면 됩니다).' },
	{ key = 'noritsu', name = '노리츠 (HS-1800) · 기준', sat = 1.0, hilite = 0.0,
	  note = '비교 사진에서 기준으로 삼은 스캐너입니다. 지금까지의 기본 결과와 같습니다 (표준 대비: 감마 0.85 · S자 0.12).' },
	{ key = 'frontier', name = '프론티어 (후지 SP-3000)', sat = 0.85, hilite = -0.09,
	  note = '비교 3컷 모두에서 비슷하게 나온 차이만 넣었습니다: 밝은 부분을 살짝 눌러주고(−0.09) 채도를 조금 낮춥니다(×0.85). 대비 차이는 컷마다 달라서 넣지 않았습니다.' },
}
local MODEL_BY_KEY = {}
for _, m in ipairs(COLOR_MODELS) do MODEL_BY_KEY[m.key] = m end
-- "pre-saturation" 1..5: the base saturation level before the model and the sliders (3 = unchanged)
local PRESAT = { 0.80, 0.90, 1.00, 1.10, 1.20 }

-- slider rows: label, key, range, step of the < > buttons, number format (%d = whole numbers)
local S_TONE = {
	{ label = '노출',        key = 'exposure', min = -2,   max = 2,   step = 0.1,  fmt = '%+.1f' },
	{ label = '대비 (감마)',  key = 'gamma',    min = 0.5,  max = 1.3, step = 0.02, fmt = '%.2f' },
	{ label = 'S자 커브',    key = 'scurve',   min = 0,    max = 0.5, step = 0.02, fmt = '%.2f' },
	{ label = '밝기',        key = 'bright',   min = -100, max = 100, step = 5,    fmt = '%+d' },
	{ label = '라이트',      key = 'lights',   min = -100, max = 100, step = 5,    fmt = '%+d' },
	{ label = '다크',        key = 'darks',    min = -100, max = 100, step = 5,    fmt = '%+d' },
	{ label = '화이트',      key = 'whites',   min = -100, max = 100, step = 5,    fmt = '%+d' },
	{ label = '블랙',        key = 'blacks',   min = -100, max = 100, step = 5,    fmt = '%+d' },
	{ label = '페이드',      key = 'fade',     min = -100, max = 100, step = 5,    fmt = '%+d' },
	{ label = '채도',        key = 'sat',      min = 0,    max = 2,   step = 0.05, fmt = '%.2f' },
	{ label = '밝은 부분',   key = 'hilite',   min = -0.25, max = 0.25, step = 0.01, fmt = '%+.2f' },
}
local S_CLIP = {
	{ label = '화이트 클립 %', key = 'wclip', min = -0.3, max = 3, step = 0.1, fmt = '%+.1f' },
	{ label = '블랙 클립 %',   key = 'bclip', min = -0.5, max = 3, step = 0.1, fmt = '%+.1f' },
}
local S_WB = {
	{ label = '노랑 ↔ 파랑',   key = 'blue', min = -1.5, max = 1.5, step = 0.05, fmt = '%+.2f' },
	{ label = '마젠타 ↔ 초록', key = 'tint', min = -1,   max = 1,   step = 0.05, fmt = '%+.2f' },
}
local function balanceRows(prefix, withRange)
	local rows = {
		{ label = '시안 ↔ 빨강',   key = prefix .. 'R', min = -100, max = 100, step = 5, fmt = '%+d' },
		{ label = '마젠타 ↔ 초록', key = prefix .. 'G', min = -100, max = 100, step = 5, fmt = '%+d' },
		{ label = '노랑 ↔ 파랑',   key = prefix .. 'B', min = -100, max = 100, step = 5, fmt = '%+d' },
	}
	if withRange then rows[#rows + 1] = { label = '범위', key = prefix .. 'Range', min = 0, max = 10, step = 1, fmt = '%d' } end
	return rows
end
local S_BORDER = { label = '여백 (경계 버퍼) %', key = 'border', min = 0, max = 5, step = 0.1, fmt = '%.1f', always = true }
local S_DETAIL = {
	{ label = '선명도',         key = 'sharp',   min = 0,    max = 100, step = 5,   fmt = '%d' },
	{ label = '선명도 반경',    key = 'radius',  min = 0.5,  max = 2.5, step = 0.1, fmt = '%.1f' },
	{ label = '노이즈 감소',    key = 'nrLum',   min = 0,    max = 100, step = 5,   fmt = '%d' },
	{ label = '색 노이즈 감소', key = 'nrColor', min = 0,    max = 100, step = 5,   fmt = '%d' },
	{ label = '입자 (그레인)',  key = 'grain',   min = 0,    max = 100, step = 5,   fmt = '%d' },
	{ label = '명료도',         key = 'clarity', min = -100, max = 100, step = 5,   fmt = '%+d' },
	{ label = '질감',           key = 'texture', min = -100, max = 100, step = 5,   fmt = '%+d' },
}
local ALL_ROWS = {}
for _, list in ipairs({ S_TONE, S_CLIP, S_WB, balanceRows('md'), balanceRows('hi', true), balanceRows('sh', true), S_DETAIL, { S_BORDER } }) do
	for _, r in ipairs(list) do ALL_ROWS[#ALL_ROWS + 1] = r end
end

-- Edit presets (a preset sets every Edit / Detail value; what it does not list goes back to the standard value.
-- Exposure, yellow-blue, magenta-green and the clip values are per photo: only presets that list them change them)
local PRESETS = {
	{ key = 'standard', name = '표준 (보정 없음)', values = {},
	  note = '기본값입니다. 스캐너 색감은 Convert 탭의 컬러 모델에서 고릅니다.' },
	{ key = 'warm', name = '따뜻하게', values = { blue = -0.15 },
	  note = '노랑 ↔ 파랑을 노랑 쪽으로 0.15 옮깁니다 (사진별 노랑 ↔ 파랑 값을 덮어씁니다).' },
	{ key = 'cool', name = '차갑게', values = { blue = 0.15 },
	  note = '노랑 ↔ 파랑을 파랑 쪽으로 0.15 옮깁니다 (사진별 노랑 ↔ 파랑 값을 덮어씁니다).' },
	{ key = 'vivid', name = '선명하게 (진한 색 · 또렷)', values = { gamma = 0.78, scurve = 0.20, sat = 1.20, sharp = 45, clarity = 15 },
	  note = '대비와 채도를 올리고 선명도 45 · 명료도 +15 를 함께 넣습니다.' },
	{ key = 'soft', name = '부드럽게 (잔잔한 색)', values = { gamma = 0.95, scurve = 0.06, sat = 0.88, sharp = 15, clarity = -10 },
	  note = '대비와 채도를 낮추고 선명도 15 · 명료도 −10 을 함께 넣습니다.' },
	{ key = 'faded', name = '빛바랜 필름', values = { gamma = 1.0, scurve = 0.0, sat = 0.80, hilite = -0.06, fade = 25, grain = 25 },
	  note = '대비를 풀고 채도를 낮추며 검정을 살짝 띄우고(페이드 25) 입자 25 를 넣습니다.' },
}
local PRESET_BY_KEY = {}
for _, p in ipairs(PRESETS) do PRESET_BY_KEY[p.key] = p end

-- tone profiles (my own curve shapes; not Negative Lab Pro's). Picking one sets only the tone-shape sliders.
local TONE_SET = { 'gamma', 'scurve', 'bright', 'lights', 'darks', 'whites', 'blacks', 'fade', 'softHi', 'softLo' }
local PROFILES = {
	{ key = 'standard', name = '표준', values = {} },
	{ key = 'soft', name = '소프트 (부드러운 대비)', values = { gamma = 0.95, scurve = 0.06 } },
	{ key = 'hard', name = '하드 (강한 대비)', values = { gamma = 0.75, scurve = 0.22 } },
	{ key = 'hi_hard', name = '밝은 부분 하드', values = { lights = -25, whites = 20 } },
	{ key = 'hi_soft', name = '밝은 부분 소프트', values = { lights = 25, whites = -20, softHi = true } },
	{ key = 'sh_hard', name = '어두운 부분 하드', values = { darks = 25, blacks = -20 } },
	{ key = 'sh_soft', name = '어두운 부분 소프트', values = { darks = -25, blacks = 20, softLo = true } },
	{ key = 'flat', name = '플랫 (보정 여지 넉넉하게)', values = { gamma = 1.05, scurve = 0.0, fade = 12, softHi = true } },
	{ key = 'linear', name = '리니어 (곡선 없음)', values = { gamma = 1.0, scurve = 0.0 } },
}
local PROFILE_BY_KEY = {}
for _, p in ipairs(PROFILES) do PROFILE_BY_KEY[p.key] = p end

local function defaultFor(k)
	if DETAIL_DEFAULTS[k] ~= nil then return DETAIL_DEFAULTS[k] end
	return LOOK_DEFAULTS[k]
end
local function presetValues(values)
	local v = {}
	for _, k in ipairs(VALUE_KEYS) do
		if values[k] ~= nil then v[k] = values[k]
		elseif not PHOTO_KEYS[k] then v[k] = defaultFor(k) end
	end
	return v
end
local function profileValues(values)
	local v = {}
	for _, k in ipairs(TONE_SET) do if values[k] ~= nil then v[k] = values[k] else v[k] = LOOK_DEFAULTS[k] end end
	return v
end
local function fmtValue(fmt, v)
	v = tonumber(v) or 0
	if string.find(fmt, 'd', 1, true) then return string.format(fmt, math.floor(v + 0.5)) end
	return string.format(fmt, v)
end

-- the panel function refers to many file-level values; Lua 5.1 allows a function at most 60 upvalues, so they are reached through this one table
local C = {
	VERSION = VERSION_TEXT,
	LOOK_DEFAULTS = LOOK_DEFAULTS,
	DETAIL_DEFAULTS = DETAIL_DEFAULTS,
	OPTION_DEFAULTS = OPTION_DEFAULTS,
	LOOK_KEYS = LOOK_KEYS,
	MODEL_BY_KEY = MODEL_BY_KEY,
	PRESAT = PRESAT,
	DETAIL_KEYS = DETAIL_KEYS,
	VALUE_KEYS = VALUE_KEYS,
	CONVERT_KEYS = CONVERT_KEYS,
	PHOTO_KEYS = PHOTO_KEYS,
	PRESET_BY_KEY = PRESET_BY_KEY,
	PRESETS = PRESETS,
	PROFILE_BY_KEY = PROFILE_BY_KEY,
	PROFILES = PROFILES,
	COLOR_MODELS = COLOR_MODELS,
	NEUTRAL = NEUTRAL,
	NO_CROP = NO_CROP,
	ALL_NEUTRAL = ALL_NEUTRAL,
	EXT_NEUTRAL = EXT_NEUTRAL,
	TOKEN = TOKEN,
	PREVIEW_W = PREVIEW_W,
	PREVIEW_H = PREVIEW_H,
	S_BORDER = S_BORDER,
	S_WB = S_WB,
	S_TONE = S_TONE,
	S_CLIP = S_CLIP,
	S_DETAIL = S_DETAIL,
}

local function showPanel()
	local catalog = LrApplication.activeCatalog()
	local prefs = LrPrefs.prefsForPlugin()
	local f = LrView.osFactory()
	local PLACEHOLDER = LrPathUtils.child(_PLUGIN.path, 'placeholder.png')
	log('--- panel opened, version ' .. C.VERSION)

	LrFunctionContext.callWithContext('NegConvertPanel', function(context)
		local props = LrBinding.makePropertyTable(context)
		for k, v in pairs(C.LOOK_DEFAULTS) do props[k] = v end
		for k, v in pairs(C.DETAIL_DEFAULTS) do props[k] = v end
		for k, v in pairs(C.OPTION_DEFAULTS) do
			local saved = prefs['panel_' .. k]
			if saved == nil then saved = v end
			props[k] = saved
		end
		props.status = '변환할 사진(들)을 선택하고 [변환 시작] 을 누르세요.\n사진마다 미리보기를 보며 조정한 뒤 [확인] 을 누르면 그 사진에 적용되고 다음 사진으로 넘어갑니다.'
		props.title = ''
		props.previewPath = PLACEHOLDER
		props.reviewing = false
		props.idle = true
		props.checking = false
		props.canView = false                       -- turning / enlarging the preview is possible (while reviewing or checking the result)

		local state = { axis = 'srgb', kind = 'cubic', calibrated = false, backups = {}, busy = false, closed = false,
			current = nil, baseline = nil, decision = nil, dirty = false, worker = false, imgN = 0, lastRow = nil, lastKey = nil, lastId = nil,
			previews = {}, silent = false, before = {}, firstRun = {}, looks = {} }
		local function say(msg) if state.closed then return end; props.status = msg; log('status: ' .. msg) end

		-- develop settings from before the first conversion are kept (also across restarts of Lightroom)
		local catKey = tostring(catalog:getPath() or 'catalog')
		local function loadBackups()
			local ok, saved = pcall(function() return prefs.backups end)
			if ok and type(saved) == 'table' and type(saved[catKey]) == 'table' then
				for id, b in pairs(saved[catKey]) do
					if type(b) == 'table' and b.ver == 2 and type(b.all) == 'table' then state.backups[id] = b
					elseif type(b) == 'table' then state.backups[id] = { ver = 2, all = b, partial = true } end      -- made by an older version: only some settings
				end
			end
		end
		local function saveBackups()
			pcall(function()
				local all = {}
				local old = prefs.backups
				if type(old) == 'table' then for k, v in pairs(old) do all[k] = v end end
				local mine = {}
				for id, b in pairs(state.backups) do mine[id] = b end
				all[catKey] = mine
				prefs.backups = all
			end)
		end
		loadBackups()

		-- the slider values each photo was converted with (only the ones that differ from the start values): [선택한 사진 다시 조정] starts from them
		local function loadLooks()
			local ok, saved = pcall(function() return prefs.looks end)
			if ok and type(saved) == 'table' and type(saved[catKey]) == 'table' then
				for id, l in pairs(saved[catKey]) do if type(l) == 'table' then state.looks[id] = l end end
			end
		end
		local function saveLooks()
			pcall(function()
				local all = {}
				local old = prefs.looks
				if type(old) == 'table' then for k, v in pairs(old) do all[k] = v end end
				local mine = {}
				for id, l in pairs(state.looks) do mine[id] = l end
				all[catKey] = mine
				prefs.looks = all
			end)
		end
		loadLooks()

		-- the values the engine gets: colour model x pre-saturation x slider = saturation, model + slider = highlights
		local function look()
			local p = {}
			for _, k in ipairs(C.LOOK_KEYS) do p[k] = props[k] end
			local m = C.MODEL_BY_KEY[p.model] or C.MODEL_BY_KEY.noritsu
			p.sat = (tonumber(p.sat) or 1) * m.sat * (C.PRESAT[tonumber(p.presat) or 3] or 1)
			p.hilite = (tonumber(p.hilite) or 0) + m.hilite
			if m.dgamma then p.gamma = math.max(0.5, math.min(1.3, (tonumber(p.gamma) or 0.85) + m.dgamma)) end
			if m.dscurve then p.scurve = math.max(0, math.min(0.5, (tonumber(p.scurve) or 0.12) + m.dscurve)) end
			if p.noSat then p.sat = 1 end                 -- saturation is not handed to Lightroom: the preview shows it the same way
			return p
		end
		local function detail()
			local d = {}
			for _, k in ipairs(C.DETAIL_KEYS) do d[k] = props[k] end
			return d
		end
		local function snapshot()
			local t = {}
			for _, k in ipairs(C.VALUE_KEYS) do t[k] = props[k] end
			return t
		end
		local function setLook(vals)
			for _, k in ipairs(C.VALUE_KEYS) do if vals[k] ~= nil then props[k] = vals[k] end end
		end
		local function rememberLook(id)
			local l = {}
			for _, k in ipairs(C.VALUE_KEYS) do
				local v, d = props[k], defaultFor(k)
				if v ~= nil and v ~= d then l[k] = v end
			end
			for _, k in ipairs(C.CONVERT_KEYS) do l[k] = props[k] end
			l.rot = props.rot
			state.looks[id] = l
			saveLooks()
		end
		local function savedLookValues(l)
			local v = {}
			for _, k in ipairs(C.VALUE_KEYS) do if l[k] ~= nil then v[k] = l[k] else v[k] = defaultFor(k) end end
			return v
		end
		local function nonPhoto(t)
			local c = {}
			for k, v in pairs(t) do if not C.PHOTO_KEYS[k] then c[k] = v end end
			return c
		end
		local function userPresets()
			local ok, t = pcall(function() return prefs.userPresets end)
			if ok and type(t) == 'table' then return t end
			return {}
		end
		local function valuesForPreset(key)
			if string.sub(key, 1, 5) == 'user:' then
				local u = userPresets()[string.sub(key, 6)]
				if type(u) == 'table' then return presetValues(u) end
				return presetValues({})
			end
			local p = C.PRESET_BY_KEY[key] or C.PRESET_BY_KEY.standard
			return presetValues(p.values)
		end
		local function buildPresetItems()
			local items = {}
			for _, p in ipairs(C.PRESETS) do items[#items + 1] = { title = p.name, value = p.key } end
			local names = {}
			for name in pairs(userPresets()) do names[#names + 1] = name end
			table.sort(names)
			if #names > 0 then
				items[#items + 1] = { separator = true }
				for _, name in ipairs(names) do items[#items + 1] = { title = '★ ' .. name, value = 'user:' .. name } end
			end
			return items
		end
		props.presetItems = buildPresetItems()
		do                                                   -- the preset chosen last time is the starting look
			local key = props.preset
			local known = C.PRESET_BY_KEY[key] or (string.sub(tostring(key), 1, 5) == 'user:' and type(userPresets()[string.sub(key, 6)]) == 'table')
			if not known then props.preset = 'standard' end
			if not C.MODEL_BY_KEY[props.model] then props.model = 'noritsu' end
			setLook(valuesForPreset(props.preset))
		end
		props.profile = 'standard'
		props.tab = 'convert'
		props.presetName = ''
		props.toast = ''
		props.ab = false

		local function photoName(photo)
			local ok, name = LrTasks.pcall(function() return photo:getFormattedMetadata('fileName') end)
			if ok and name and name ~= '' then return tostring(name) end
			return 'ID ' .. tostring(photo.localIdentifier)
		end

		local function cacheFiles(id)
			local dir = LrPathUtils.child(workDir(), 'cache')
			return LrPathUtils.child(dir, 'analysis_' .. id .. '.npz'), LrPathUtils.child(dir, 'last_' .. id .. '.json')
		end
		local function dropCache(id)
			local a, b = cacheFiles(id)
			LrFileUtils.delete(a); LrFileUtils.delete(b)
		end

		---------------------------------------------------------- preview
		local function newPreviewPath()
			state.imgN = state.imgN + 1
			local p = LrPathUtils.child(workDir(), 'prev_' .. C.TOKEN .. '_' .. state.imgN .. '.jpg')
			state.previews[#state.previews + 1] = p
			return p
		end
		local function showPreview(path)
			if state.closed then return end
			props.previewPath = path
			while #state.previews > 3 do                       -- keep the newest few files, drop older ones
				local old = table.remove(state.previews, 1)
				if old ~= path then LrFileUtils.delete(old) end
			end
		end
		local function previewLines(p, out, w, h)
			local l = { 'mode=refit' }
			for _, x in ipairs(lookLines(p, state.axis, state.kind)) do l[#l + 1] = x end
			l[#l + 1] = 'out=' .. out
			l[#l + 1] = 'pw=' .. (w or C.PREVIEW_W)
			l[#l + 1] = 'ph=' .. (h or C.PREVIEW_H)
			l[#l + 1] = 'rot=' .. num(p.rot)
			l[#l + 1] = 'autocrop=' .. (p.autoCrop and '1' or '0')
			l[#l + 1] = 'sat=' .. num(p.sat)
			return l
		end

		-- the picture for the current slider values (the curves Lightroom will get, evaluated like Lightroom does)
		local function renderPreview()
			local cur = state.current
			if not cur or state.closed then return end
			local p = look()
			local out = newPreviewPath()
			local lines = previewLines(p, out)
			lines[#lines + 1] = 'item=' .. cur.id
			local rows, err = runEngine(lines, props.python)
			if state.current ~= cur or state.closed then return end
			local row = rows and rows[1]
			if row and row[2] == 'ok' and row[9] then
				state.lastRow, state.lastKey, state.lastId = row, lookKey(p), cur.id
				showPreview(row[9])
			else
				say('미리보기를 만들지 못했습니다: ' .. tostring((row and row[3]) or err))
			end
		end

		-- slider moved: one new preview after the sliders have rested for a moment (newest values win)
		local function requestPreview()
			if not state.current then return end
			state.dirty = true
			if state.worker then return end
			state.worker = true
			LrTasks.startAsyncTask(function()
				while state.dirty and not state.closed do
					state.dirty = false
					LrTasks.sleep(0.35)
					if not state.dirty then renderPreview() end
				end
				state.worker = false
			end)
		end

		---------------------------------------------------------- restoring
		-- skip / stop / failure: the photo goes back to how it was when this run began (for a first conversion that is the original).
		-- Nothing is written when this run never touched the photo.
		local function restoreRun(photo, why)
			local id = tostring(photo.localIdentifier)
			local target = state.before[id]
			if not target then return true end
			local ok, note, left = restoreTo(catalog, photo, target, '네거티브 변환: ' .. why, C.ALL_NEUTRAL)
			if #left > 0 then log('restore: still different: ' .. table.concat(left, ', ')) end
			state.before[id] = nil
			if state.firstRun[id] then                 -- it was not converted before this run: nothing is left to undo later (unless something stuck)
				state.firstRun[id] = nil
				if ok and #left == 0 then state.backups[id] = nil; saveBackups() end
			end
			return ok, note, left
		end

		---------------------------------------------------------- one photo: analysis (no changes kept yet)
		local function prepare(photo, tag)
			local id = tostring(photo.localIdentifier)
			local full = currentSettings(photo)
			if not full then return nil, '현재 현상 설정을 읽지 못해 백업할 수 없습니다. 사진은 건드리지 않았습니다.' end
			do                                                 -- for the log: which tone-curve keys this Lightroom reports for the photo
				local ks = {}
				for k, v in pairs(full) do
					if string.find(k, 'ToneCurve') then ks[#ks + 1] = k .. '(' .. ((type(v) == 'table') and (#v .. ' values') or tostring(v)) .. ')' end
				end
				table.sort(ks)
				log('curve keys of ' .. id .. ': ' .. table.concat(ks, ' '))
			end
			state.before[id] = deepCopy(full)                  -- how the photo is right now: skip / stop / failure come back to this
			if not state.backups[id] then                      -- first conversion: the complete original settings are kept for [원래대로]
				state.backups[id] = { ver = 2, all = deepCopy(full) }
				state.firstRun[id] = true
				saveBackups()
			end
			say(tag .. '분석 준비: 현상 설정을 중립으로 맞추는 중…')
			local ok1, note1, left1 = applyNeutral(catalog, photo, '네거티브 변환: 분석 준비')
			if not ok1 then return nil, '설정을 적용하지 못했습니다: ' .. tostring(note1) end
			local stuck = curveKeysLeft(left1)
			if #stuck > 0 then
				return nil, '톤 커브를 중립으로 되돌리지 못했습니다 (' .. table.concat(stuck, ', ') .. '). 이 상태로 분석하면 이미 변환된 그림을 분석하게 되어 건너뜁니다. '
					.. '사진을 이전 상태로 되돌렸으니, 라이트룸 현상 모듈에서 [설정 초기화] 를 한 번 한 뒤 다시 시도해 주세요.'
			end

			say(tag .. '분석용 임시 렌더링 중…')
			local r0, err0 = renderSmall(photo, 'a')
			if not r0 then return nil, err0 end

			say(tag .. '필름 분석 중…')
			local p = look()
			local axisAtFit, kindAtFit = state.axis, state.kind
			local out = newPreviewPath()
			local lines = previewLines(p, out)
			lines[1] = 'mode=fit'
			lines[#lines + 1] = 'item=' .. r0 .. '\t' .. id
			local rows, err = runEngine(lines, props.python)
			if not rows then LrFileUtils.delete(r0); return nil, err end
			local row = rows[1]
			if not row or row[2] ~= 'ok' then LrFileUtils.delete(r0); return nil, (row and row[3]) or '엔진이 결과를 주지 않았습니다' end
			local notes = row[3] or ''
			if note1 then notes = notes .. ' ' .. note1 end

			-- once per session: find out how Lightroom really applies point curves (axis / interpolation)
			if not state.calibrated then
				say(tag .. '라이트룸의 커브 적용 방식을 확인하는 중 (한 번만)…')
				local okc = applySettings(catalog, photo, withExtended(photo, curveSettings(row, p, true)), '네거티브 변환: 커브 확인')
				local r1, err1
				if okc then r1, err1 = renderSmall(photo, 'b') else err1 = '커브를 적용하지 못했습니다' end
				if r1 then
					local rowsI, errI = runEngine({ 'mode=identify', 'item=' .. r0 .. '\t' .. r1 .. '\t' .. id }, props.python)
					LrFileUtils.delete(r1)
					local ri = rowsI and rowsI[1]
					if ri and ri[2] == 'ok' then
						local axis, kind, errBest, errDefault = ri[4], ri[5], tonumber(ri[6]) or 99, tonumber(ri[7]) or 99
						state.calibrated = true
						state.calibText = string.format('커브 적용 확인: 축 %s / 보간 %s, 오차 %.2f (기본 가정 %.2f)', axis, kind, errBest, errDefault)
						log(state.calibText)
						if errBest + 0.5 < errDefault and errBest <= 4 then state.axis, state.kind = axis, kind end      -- a large error means the check itself went wrong: keep the default
						if errBest > 1.5 then
							notes = notes .. ' 라이트룸의 커브 동작이 예상과 달라 색이 어긋날 수 있습니다 (오차 ' .. string.format('%.1f', errBest) .. ').'
						end
					else
						state.calibText = '커브 적용 확인 실패: ' .. tostring((ri and ri[3]) or errI)
						log(state.calibText)
					end
				else
					state.calibText = '커브 적용 확인 실패: ' .. tostring(err1)
					log(state.calibText)
				end
			end
			LrFileUtils.delete(r0)
			local fresh = (axisAtFit == state.axis and kindAtFit == state.kind)
			if not fresh then                       -- the first preview was made with a wrong guess of the curve axis: redo it
				local out2 = newPreviewPath()
				local l2 = previewLines(p, out2)
				l2[#l2 + 1] = 'item=' .. id
				local rows2 = runEngine(l2, props.python)
				if rows2 and rows2[1] and rows2[1][2] == 'ok' and rows2[1][9] then row, fresh = rows2[1], true end
			end
			-- until [확인], Lightroom's own view shows the plain (neutral) negative for every photo
			applyNeutral(catalog, photo, '네거티브 변환: 분석 준비')
			return { photo = photo, id = id, notes = notes, row = row, out = row[9], p = p, fresh = fresh }
		end

		---------------------------------------------------------- one photo: look at it, adjust, decide
		local function applyFinal(entry)
			local p = look()
			local row = state.lastRow
			if not (row and state.lastId == entry.id and state.lastKey == lookKey(p)) then
				local lines = { 'mode=refit' }
				for _, x in ipairs(lookLines(p, state.axis, state.kind)) do lines[#lines + 1] = x end
				lines[#lines + 1] = 'item=' .. entry.id
				local rows, err = runEngine(lines, props.python)
				row = rows and rows[1]
				if not (row and row[2] == 'ok') then return false, tostring((row and row[3]) or err) end
			end
			local settings = merge(curveSettings(row, p), detailSettings(detail()))
			if p.autoCrop then
				local cs = cropSettings(row)
				if cs then settings = merge(settings, cs) end
			end
			settings = withExtended(entry.photo, settings)
			local ok, note = applySettings(catalog, entry.photo, settings, '네거티브 변환: 확인')
			if not ok then return false, '적용하지 못했습니다: ' .. tostring(note) end
			return true, note
		end

		local function review(entry, keepBaseline)
			if not keepBaseline then state.baseline = snapshot() end      -- "first conversion" values of this photo: what the reset buttons return to
			state.current, state.decision = entry, nil
			state.lastRow, state.lastKey, state.lastId = nil, nil, nil
			local p = look()
			if entry.fresh and entry.out and lookKey(p) == lookKey(entry.p) then
				state.lastRow, state.lastKey, state.lastId = entry.row, lookKey(p), entry.id
				showPreview(entry.out)
			else
				requestPreview()
			end
			props.reviewing = true
			props.canView = true
			if not state.closed then props.tab = 'edit' end
			while not state.decision and not state.closed do LrTasks.sleep(0.15) end
			if props.ab and not state.closed then props.ab = false end          -- A/B on: bring the current values back before they are used
			props.reviewing = false
			props.canView = false
			state.current = nil
			return state.decision or 'stop'
		end

		-- after [확인]: how Lightroom really draws the photo now (sharpening, grain, noise reduction and the curves included)
		local function checkResult(entry, tag, name)
			say(tag .. name .. ': 적용한 결과를 라이트룸이 실제로 그리는 중…')
			local r, err = renderSmall(entry.photo, 'r', { jpeg = true, px = 1200 })
			if state.closed then return 'next' end
			if not r then
				say(tag .. name .. ': 결과 화면을 만들지 못해 확인 없이 넘어갑니다 (' .. tostring(err) .. ')')
				return 'next', tostring(err)
			end
			state.checkRaw = r
			local function showCheckImage()                              -- the render, turned like the preview, letter-boxed by the engine
				local out = newPreviewPath()                             -- a new file name each time, so the picture control really reloads
				local rows = runEngine({ 'mode=view', 'pw=' .. C.PREVIEW_W, 'ph=' .. C.PREVIEW_H, 'rot=' .. num(props.rot), 'item=' .. r .. '\t' .. out }, props.python)
				local row = rows and rows[1]
				if row and row[2] == 'ok' then showPreview(out); return end
				local shown = newPreviewPath()                           -- no engine: show the plain render
				if LrFileUtils.copy(r, shown) then showPreview(shown) else showPreview(r) end
			end
			state.refreshCheck = showCheckImage
			showCheckImage()
			props.title = tag .. name .. ' — 적용 결과 (라이트룸 실제 화면)'
			say(tag .. name .. ': 라이트룸이 실제로 그린 결과입니다 (세부 설정 포함).\n괜찮으면 [결과 좋음 · 다음으로], 고치려면 [다시 조정] (슬라이더가 다시 열립니다), 마음에 안 들면 [이 사진 변환 취소].')
			state.checkDecision = nil
			props.checking = true
			props.canView = true
			while not state.checkDecision and not state.closed do LrTasks.sleep(0.15) end
			props.checking = false
			props.canView = false
			state.refreshCheck, state.checkRaw = nil, nil
			LrFileUtils.delete(r)
			return state.checkDecision or 'next'
		end

		-- enlarged view: its own window with a larger, more detailed picture (the larger copy of the render), turnable
		local function bigCanvas()
			local w, h = 1200, 780
			if okSI and LrSystemInfo and LrSystemInfo.appWindowSize then
				local okW, win = pcall(LrSystemInfo.appWindowSize)
				if okW and type(win) == 'table' and tonumber(win.width) and tonumber(win.height) then
					w = math.max(800, math.min(1800, math.floor(win.width * 0.82)))
					h = math.max(520, math.min(1200, math.floor(win.height * 0.72)))
				end
			end
			return w, h
		end
		local function openBig()
			if state.bigOpen or not props.canView then return end
			state.bigOpen = true
			local bw, bh = bigCanvas()
			local files, seq, alive = {}, 0, true
			local okD, errD = LrTasks.pcall(function()
				LrFunctionContext.callWithContext('NegConvertBig', function(ctx)
					local bp = LrBinding.makePropertyTable(ctx)
					bp.path = PLACEHOLDER
					bp.note = '큰 미리보기를 만드는 중…'
					local function draw()
						seq = seq + 1
						local my = seq
						local out = LrPathUtils.child(workDir(), 'big_' .. TOKEN .. '_' .. my .. '.jpg')
						files[#files + 1] = out
						local rows, err
						if props.checking and state.checkRaw then
							rows, err = runEngine({ 'mode=view', 'pw=' .. bw, 'ph=' .. bh, 'rot=' .. num(props.rot), 'item=' .. state.checkRaw .. '\t' .. out }, props.python)
						elseif state.current then
							local lines = previewLines(look(), out, bw, bh)
							lines[#lines + 1] = 'item=' .. state.current.id
							rows, err = runEngine(lines, props.python)
						else
							bp.note = '지금은 확대해서 볼 사진이 없습니다.'
							return
						end
						local row = rows and rows[1]
						local path = row and row[2] == 'ok' and (row[9] or row[4])
						if my ~= seq or not alive then return end            -- a newer picture was asked for (or the window is closed)
						if path then
							bp.path = path
							bp.note = props.checking and '라이트룸이 실제로 그린 결과입니다.' or '현재 슬라이더 값으로 계산한 미리보기입니다.'
						else
							bp.note = '큰 미리보기를 만들지 못했습니다: ' .. tostring((row and row[3]) or err)
						end
					end
					local function turn(d)
						props.rot = (props.rot + d) % 360
						bp.note = '돌리는 중…'
						LrTasks.startAsyncTask(draw)
					end
					LrTasks.startAsyncTask(draw)
					LrDialogs.presentModalDialog({
						title = '큰 미리보기',
						contents = f:column {
							bind_to_object = bp,
							spacing = f:control_spacing(),
							f:picture { value = bind { key = 'path', object = bp }, width = bw, height = bh },
							f:row {
								spacing = f:control_spacing(),
								f:push_button { title = '↶ 왼쪽으로 돌리기', action = function() turn(-90) end },
								f:push_button { title = '↷ 오른쪽으로 돌리기', action = function() turn(90) end },
								f:static_text { title = bind { key = 'note', object = bp }, width = 520 },
							},
						},
						actionVerb = '닫기',
						cancelVerb = '< exclude >',
					})
					alive = false
				end)
			end)
			for _, fp in ipairs(files) do LrFileUtils.delete(fp) end
			state.bigOpen = false
			if not okD then say('큰 미리보기 창을 열지 못했습니다: ' .. shortErr(errD)) end
		end

		---------------------------------------------------------- start button
		local function convertSelected(redo)
			if state.busy then return end
			state.busy = true
			props.idle = false
			local photos = catalog:getTargetPhotos()
			local function finish(msg)
				props.canView = false
				props.reviewing = false
				props.idle = true
				state.busy = false
				if not state.closed then props.tab = 'convert' end
				if msg then say(msg) end
			end
			if not photos or #photos == 0 then finish('사진을 먼저 선택해 주세요.'); return end
			local py, tried = pythonCommand(props.python)
			if not py then
				finish('Python 을 찾지 못했습니다 (시도: ' .. table.concat(tried, ', ') .. '). Convert 탭 아래쪽의 "Python 명령" 칸에 python.exe 전체 경로를 적어 주세요 (numpy · OpenCV 필요). 사진의 현상 설정은 건드리지 않았습니다.')
				return
			end
			local okN, skipN, failN, msgs, stopped = 0, 0, 0, {}, false
			local optsBefore = {}
			for _, k in ipairs(C.CONVERT_KEYS) do optsBefore[k] = props[k] end
			local function undo(photo, name, why)
				local ok, note, left = restoreRun(photo, why)
				if ok == false then
					msgs[#msgs + 1] = name .. ': 이전 상태로 되돌리지 못했습니다 (' .. tostring(note) .. ') — [선택한 사진 원래대로] 를 눌러 보세요.'
				elseif left and #left > 0 then
					msgs[#msgs + 1] = name .. ': 이전 상태로 돌아가지 않은 항목: ' .. table.concat(left, ', ') .. ' — [선택한 사진 원래대로] 를 눌러 보세요.'
				end
			end
			for i, photo in ipairs(photos) do
				if state.closed then break end
				local tag = (#photos > 1) and ('(' .. i .. '/' .. #photos .. ') ') or ''
				local name = photoName(photo)
				local id = tostring(photo.localIdentifier)
				local startNote = nil
				local saved = redo and state.looks[id] or nil
				if saved then
					setLook(savedLookValues(saved))
					for _, k in ipairs(C.CONVERT_KEYS) do if saved[k] ~= nil then props[k] = saved[k] end end
				else
					if redo then startNote = '이 사진의 이전 변환 값 기록이 없어 프리셋 값에서 시작합니다.' end
					if not props.carry then setLook(merge(merge(C.LOOK_DEFAULTS, C.DETAIL_DEFAULTS), valuesForPreset(props.preset))) end   -- every photo starts from the chosen preset
				end
				if saved and saved.rot then props.rot = saved.rot elseif not props.carry then props.rot = 0 end      -- turned preview: remembered per photo
				local entry, err = prepare(photo, tag)
				if not entry then
					failN = failN + 1
					msgs[#msgs + 1] = name .. ': ' .. tostring(err)
					undo(photo, name, '실패: 이전 상태로')
				else
					props.title = tag .. name
					local hint = tag .. name .. ': 미리보기를 보며 조정한 뒤 [확인] 을 누르세요.'
					if saved then hint = hint .. '\n이 사진을 변환했을 때의 값에서 시작합니다 (↺ 는 그 값으로 되돌립니다).' end
					if startNote then hint = hint .. '\n' .. startNote end
					if state.calibText and not state.calibShown then hint = hint .. '\n' .. state.calibText; state.calibShown = true end
					if trim(entry.notes) ~= '' then hint = hint .. '\n⚠ ' .. trim(entry.notes) end
					say(hint)
					local decision = review(entry)
					local reviews = 1
					while true do
						if decision == 'ok' then
							say(tag .. name .. ': 사진에 적용하는 중…')
							local okA, noteA = applyFinal(entry)
							if not okA then
								failN = failN + 1
								msgs[#msgs + 1] = name .. ': ' .. tostring(noteA)
								undo(photo, name, '적용 실패: 이전 상태로')
								break
							end
							if noteA and trim(noteA) ~= '' then msgs[#msgs + 1] = name .. ': ' .. trim(noteA) end
							local verdict, vnote = 'next', nil
							if props.verify then verdict, vnote = checkResult(entry, tag, name) end
							if vnote then msgs[#msgs + 1] = name .. ': 실제 결과 화면을 만들지 못해 확인 없이 넘어갔습니다 (' .. vnote .. ')' end
							if verdict == 'again' then
								entry.fresh = false
								reviews = reviews + 1
								props.title = tag .. name .. ' (다시 조정)'
								say(tag .. name .. ': 다시 조정합니다. 슬라이더를 움직이면 미리보기가 바뀌고, [확인] 을 누르면 다시 적용됩니다.')
								decision = review(entry, true)
							elseif verdict == 'skip' then
								skipN = skipN + 1
								undo(photo, name, '변환 취소: 이전 상태로')
								break
							else
								okN = okN + 1
								state.before[id] = nil; state.firstRun[id] = nil          -- converted now: the original stays in the backup
								rememberLook(id)
								break
							end
						elseif decision == 'skip' then
							skipN = skipN + 1
							undo(photo, name, '건너뜀: 이전 상태로')
							break
						else
							stopped = true
							undo(photo, name, '중단: 이전 상태로')
							break
						end
					end
					dropCache(entry.id)
				end
				if stopped then break end
			end
			if redo then for k, v in pairs(optsBefore) do props[k] = v end end          -- the panel's own options come back
			props.title = ''
			local head = '적용 ' .. okN .. '장' .. ((skipN > 0) and (' · 건너뜀 ' .. skipN .. '장') or '') .. ((failN > 0) and (' · 실패 ' .. failN .. '장') or '')
				.. (stopped and ' · 중단함' or '')
			if #msgs > 0 then head = head .. '\n' .. table.concat(msgs, '\n') end
			finish(head)
		end

		local function restoreSelected()
			if state.busy then return end
			state.busy = true
			props.idle = false
			local photos = catalog:getTargetPhotos() or {}
			local full, partial, plain, failed, notes = 0, 0, 0, 0, {}
			for _, ph in ipairs(photos) do
				local id = tostring(ph.localIdentifier)
				local name = photoName(ph)
				local b = state.backups[id]
				if b then
					local target = b.partial and merge(merge(C.NEUTRAL, C.NO_CROP), b.all) or b.all
					local ok, note, left = restoreTo(catalog, ph, target, '네거티브 변환: 원래대로', b.partial and C.EXT_NEUTRAL or C.ALL_NEUTRAL)
					if ok then
						state.before[id] = nil; state.firstRun[id] = nil
						if #left == 0 then state.backups[id] = nil; state.looks[id] = nil end
						if b.partial then partial = partial + 1 else full = full + 1 end
						if #left > 0 then notes[#notes + 1] = name .. ': 원래 값과 아직 다른 항목 ' .. table.concat(left, ', ') .. ' — 백업은 남겨 두었으니 [원래대로] 를 한 번 더 눌러 보세요.' end
						if note and trim(note) ~= '' then notes[#notes + 1] = name .. ': ' .. trim(note) end
					else
						failed = failed + 1
						notes[#notes + 1] = name .. ': 되돌리지 못했습니다 (' .. tostring(note) .. ') — 백업은 그대로 남아 있으니 다시 눌러 보세요.'
					end
				else
					local ok, note, left = restoreTo(catalog, ph, plainTarget(ph), '네거티브 변환: 중립으로')
					if ok then
						plain = plain + 1; state.looks[id] = nil
						if #left > 0 then notes[#notes + 1] = name .. ': 중립으로 돌아가지 않은 항목 ' .. table.concat(left, ', ') end
					else failed = failed + 1 end
				end
			end
			saveBackups()
			saveLooks()
			props.idle = true
			state.busy = false
			local parts = {}
			if full > 0 then parts[#parts + 1] = full .. '장: 변환 전 상태(백업한 전체 설정)로 되돌림' end
			if partial > 0 then parts[#parts + 1] = partial .. '장: 예전 버전의 백업이라 일부 항목(톤 · 채도 · 세부 · 자르기)만 되돌림' end
			if plain > 0 then parts[#parts + 1] = plain .. '장: 백업 기록이 없어 톤 · 채도 · 세부 · 자르기만 중립으로 (다른 보정은 그대로)' end
			if failed > 0 then parts[#parts + 1] = failed .. '장 실패' end
			if #parts == 0 then parts[1] = '되돌릴 사진이 없습니다.' end
			local msg = table.concat(parts, '\n')
			if #notes > 0 then msg = msg .. '\n' .. table.concat(notes, '\n') end
			say(msg)
		end

		---------------------------------------------------------- controls
		for _, k in ipairs(C.LOOK_KEYS) do
			props:addObserver(k, function() requestPreview() end)
		end
		for _, k in ipairs({ 'autoExp', 'autoCrop', 'carry', 'python', 'preset', 'model', 'presat', 'border', 'verify', 'noSat' }) do
			props:addObserver(k, function(_, key, value) prefs['panel_' .. key] = value end)
		end

		props:addObserver('rot', function()                 -- the result picture of Lightroom's own render is turned by the engine too
			if props.checking and state.refreshCheck then LrTasks.startAsyncTask(state.refreshCheck) end
		end)

		local function toast(msg) if not state.closed then props.toast = msg end end
		local function remember() state.undo = snapshot() end          -- one step back for presets / tone profiles / paste / reset-all
		local function silently(key, value)
			state.silent = true
			props[key] = value
			state.silent = false
		end

		-- picking a preset sets its values at once (during review the preview follows); [모든 슬라이더를 처음 값으로] returns to the first conversion
		props:addObserver('preset', function(_, _, value)
			if state.silent then return end
			remember()
			setLook(valuesForPreset(value))
			silently('profile', 'standard')
		end)
		props:addObserver('profile', function(_, _, value)
			if state.silent then return end
			local pr = C.PROFILE_BY_KEY[value]
			if not pr then return end
			remember()
			setLook(profileValues(pr.values))
		end)
		-- A/B: show the first-conversion values, and come back to the current ones
		props:addObserver('ab', function(_, _, on)
			if state.silent then return end
			if on then
				if not props.reviewing then silently('ab', false); return end
				state.abSaved = snapshot()
				setLook(state.baseline or presetValues({}))
			elseif state.abSaved then
				local saved = state.abSaved
				state.abSaved = nil
				setLook(saved)
			end
		end)

		local function copySettings()
			state.clip = nonPhoto(snapshot())
			pcall(function() prefs.clip = state.clip end)
			toast('현재 설정을 복사했습니다 (노출 · 색 균형 · 클립 값은 사진마다 달라서 제외).')
		end
		local function pasteSettings()
			local c = state.clip
			if not c then
				local ok, saved = pcall(function() return prefs.clip end)
				if ok and type(saved) == 'table' then c = saved end
			end
			if not c then toast('복사해 둔 설정이 없습니다.'); return end
			remember()
			setLook(c)
			toast('복사한 설정을 붙여넣었습니다.')
		end
		local function undoSettings()
			if not state.undo then toast('되돌릴 단계가 없습니다.'); return end
			local now = snapshot()
			setLook(state.undo)
			state.undo = now                                    -- pressing it again goes forward again
			toast('직전 프리셋 · 붙여넣기 · 초기화 이전 값으로 되돌렸습니다.')
		end
		local function savePreset()
			local name = trim(props.presetName)
			if name == '' then toast('프리셋 이름을 먼저 적어 주세요.'); return end
			local all = copyOf(userPresets())
			all[name] = nonPhoto(snapshot())
			prefs.userPresets = all
			props.presetItems = buildPresetItems()
			silently('preset', 'user:' .. name)
			toast('내 프리셋 "' .. name .. '" 을 저장했습니다 (목록에서 ★ 표시).')
		end
		local function deletePreset()
			local key = tostring(props.preset)
			if string.sub(key, 1, 5) ~= 'user:' then toast('삭제할 수 있는 것은 ★ 표시가 있는 내 프리셋뿐입니다.'); return end
			local all = copyOf(userPresets())
			all[string.sub(key, 6)] = nil
			prefs.userPresets = all
			props.presetItems = buildPresetItems()
			silently('preset', 'standard')
			toast('내 프리셋을 삭제했습니다.')
		end

		local function nudge(r, dir)
			local v = (tonumber(props[r.key]) or 0) + dir * r.step
			if v < r.min then v = r.min end
			if v > r.max then v = r.max end
			props[r.key] = roundTo(v, 0.01)
		end
		local function resetOne(key)
			local base = state.baseline or C.LOOK_DEFAULTS
			if base[key] == nil then base = C.DETAIL_DEFAULTS end
			if base[key] ~= nil then props[key] = base[key] end
		end

		---------------------------------------------------------- layout
		local reviewing = bind { key = 'reviewing', object = props }
		local checking = bind { key = 'checking', object = props }
		local canView = bind { key = 'canView', object = props }
		local function column(opts, items)
			local t = copyOf(opts)
			for _, v in ipairs(items) do t[#t + 1] = v end
			return f:column(t)
		end
		-- label, < slider > value ↺   (enabled while a photo is under review; r.always: also in between)
		local function sliderRow(r)
			local on = r.always and true or reviewing
			return f:row {
				spacing = f:control_spacing(),
				f:static_text { title = r.label, width = 96, alignment = 'right' },
				f:push_button { title = '<', width = 26, enabled = on, action = function() nudge(r, -1) end },
				f:slider { value = bind { key = r.key, object = props }, min = r.min, max = r.max, width = 150, enabled = on },
				f:push_button { title = '>', width = 26, enabled = on, action = function() nudge(r, 1) end },
				f:static_text { title = bind { key = r.key, object = props, transform = function(v) return fmtValue(r.fmt, v) end }, width = 44 },
				f:push_button { title = '↺', width = 26, enabled = on, action = function() resetOne(r.key) end },
			}
		end
		local function rowsOf(list)
			local c = {}
			for _, r in ipairs(list) do c[#c + 1] = sliderRow(r) end
			return c
		end
		local function small(title, lines, bound)
			return f:static_text { title = title, width = 420, height_in_lines = lines or 2, font = '<system/small>' }
		end

		-- tab_view: if this Lightroom refuses it, stack the groups instead of failing to open the panel
		local function tabsView(items, valueKey)
			local ok, tv = pcall(function()
				local t = {}
				if valueKey then t.value = bind { key = valueKey, object = props } end
				for _, it in ipairs(items) do
					t[#t + 1] = f:tab_view_item { title = it.title, identifier = it.id, it.view }
				end
				return f:tab_view(t)
			end)
			if ok and tv then return tv end
			log('tab_view unavailable: ' .. tostring(tv))
			local col = {}
			for _, it in ipairs(items) do
				col[#col + 1] = f:static_text { title = '── ' .. it.title .. ' ──', font = '<system/bold>' }
				col[#col + 1] = it.view
			end
			return column({ spacing = f:control_spacing() }, col)
		end

		local presetNote = bind { key = 'preset', object = props, transform = function(v)
			v = tostring(v)
			if string.sub(v, 1, 5) == 'user:' then return '저장해 둔 내 프리셋입니다 (노출 · 색 균형 · 클립 값은 들어 있지 않습니다).' end
			local pr = C.PRESET_BY_KEY[v]
			return pr and pr.note or ''
		end }
		local profileItems = {}
		for _, pr in ipairs(C.PROFILES) do profileItems[#profileItems + 1] = { title = pr.name, value = pr.key } end
		local modelItems = {}
		for _, m in ipairs(C.COLOR_MODELS) do modelItems[#modelItems + 1] = { title = m.name, value = m.key } end
		local presatItems = {
			{ title = '1 (낮음)', value = 1 }, { title = '2', value = 2 }, { title = '3 (기본)', value = 3 },
			{ title = '4', value = 4 }, { title = '5 (높음)', value = 5 },
		}

		-- Convert tab
		local convertTab = column({ spacing = f:control_spacing() }, {
			f:row { f:static_text { title = '종류', width = 96, alignment = 'right' }, f:static_text { title = '컬러 네거티브' } },
			f:row { f:static_text { title = '소스', width = 96, alignment = 'right' }, f:static_text { title = '디지털 카메라 (RAW 스캔)' } },
			f:row { f:static_text { title = '컬러 모델', width = 96, alignment = 'right' },
				f:popup_menu { items = modelItems, value = bind { key = 'model', object = props }, width = 250 } },
			f:row { f:spacer { width = 100 },
				f:static_text { title = bind { key = 'model', object = props, transform = function(v) local m = C.MODEL_BY_KEY[v]; return m and m.note or '' end },
					width = 320, height_in_lines = 3, font = '<system/small>' } },
			f:row { f:static_text { title = '기본 채도', width = 96, alignment = 'right' },
				f:popup_menu { items = presatItems, value = bind { key = 'presat', object = props }, width = 120 },
				f:static_text { title = '(Pre-Saturation, 3 = 그대로)' } },
			sliderRow(C.S_BORDER),
			f:row { f:spacer { width = 100 },
				f:checkbox { title = '프레임에 맞춰 자르기', value = bind { key = 'autoCrop', object = props } },
				f:checkbox { title = '자동 노출', value = bind { key = 'autoExp', object = props } } },
			f:row { f:spacer { width = 100 },
				f:checkbox { title = '[확인] 뒤 라이트룸 실제 결과를 다시 보여주기', value = bind { key = 'verify', object = props } } },
			f:row { f:spacer { width = 100 },
				f:checkbox { title = '채도를 라이트룸에 적용하지 않기 (색이 어긋날 때)', value = bind { key = 'noSat', object = props } } },
			f:separator { fill_horizontal = 1 },
			f:push_button { title = '변환 시작 (선택한 사진)', width = 330, enabled = bind { key = 'idle', object = props },
				action = function() LrTasks.startAsyncTask(function() convertSelected(false) end) end },
			f:row {
				f:push_button { title = '선택한 사진 다시 조정', enabled = bind { key = 'idle', object = props },
					action = function() LrTasks.startAsyncTask(function() convertSelected(true) end) end },
				f:static_text { title = '(변환한 사진을 그때 값에서 다시 조정)' } },
			f:row {
				f:push_button { title = '선택한 사진 원래대로', enabled = bind { key = 'idle', object = props },
					action = function() LrTasks.startAsyncTask(restoreSelected) end },
				f:static_text { title = '(변환 취소 · Unconvert)' } },
			f:separator { fill_horizontal = 1 },
			f:static_text {
				title = '디지털 카메라로 찍은 필름 스캔(RAW)용입니다.\n'
					.. '1. 필름 가장자리의 구멍(퍼포레이션)이 사진의 위 · 아래 가장자리에 6개 이상 온전히(잘리지 않게) 찍혀 있어야 합니다. 구멍으로 새어 나온 빛으로 화이트밸런스를, 구멍 사이의 필름 여백으로 필름 베이스 색을 잡기 때문입니다.\n'
					.. '2. 그림 부분(프레임)은 자동으로 찾아 자릅니다. 어긋나면 "프레임에 맞춰 자르기" 를 끄고 라이트룸 자르기 도구로 직접 자르세요. 여백(%)은 자르기 경계를 안쪽으로 더 줄입니다.\n'
					.. '3. [변환 시작] 을 누르면 사진마다 분석한 뒤 Edit 탭으로 넘어갑니다. 미리보기를 보며 보정하고 [확인] 을 눌러야 그 사진에 적용되고 다음 사진으로 넘어갑니다.',
				width = 420, height_in_lines = 8, font = '<system/small>' },
			f:row { f:static_text { title = 'Python 명령', width = 96, alignment = 'right' },
				f:edit_field { value = bind { key = 'python', object = props }, width_in_chars = 24 },
				f:static_text { title = '비우면 자동' } },
			f:static_text { title = '베타 테스트 버전 v' .. C.VERSION .. ' · 문제가 생기면 README_ko.txt 의 "문제 해결" 을 보고, 증상과 로그를 함께 알려 주세요.',
				width = 420, height_in_lines = 2, font = '<system/small>' },
		})

		-- Edit tab
		local balanceTab = tabsView({
			{ title = 'WB', id = 'wb', view = column({ spacing = 2 }, rowsOf(C.S_WB)) },
			{ title = '중간톤', id = 'mids', view = column({ spacing = 2 }, rowsOf(balanceRows('md'))) },
			{ title = '밝은 곳', id = 'highs', view = column({ spacing = 2 }, rowsOf(balanceRows('hi', true))) },
			{ title = '어두운 곳', id = 'shadows', view = column({ spacing = 2 }, rowsOf(balanceRows('sh', true))) },
		}, nil)
		local editItems = {
			f:row { f:static_text { title = '프리셋', width = 96, alignment = 'right' },
				f:popup_menu { items = bind { key = 'presetItems', object = props }, value = bind { key = 'preset', object = props }, width = 250 } },
			f:row { f:spacer { width = 100 }, f:static_text { title = presetNote, width = 320, height_in_lines = 2, font = '<system/small>' } },
			f:row { f:static_text { title = '내 프리셋', width = 96, alignment = 'right' },
				f:edit_field { value = bind { key = 'presetName', object = props }, width_in_chars = 14 },
				f:push_button { title = '저장', action = savePreset },
				f:push_button { title = '삭제', action = deletePreset } },
			f:row { f:spacer { width = 100 },
				f:push_button { title = '복사', enabled = reviewing, action = copySettings },
				f:push_button { title = '붙여넣기', enabled = reviewing, action = pasteSettings },
				f:push_button { title = '되돌리기', enabled = reviewing, action = undoSettings },
				f:push_button { title = '모든 슬라이더를 처음 값으로', enabled = reviewing,
					action = function() remember(); setLook(state.baseline or presetValues({})) end } },
			f:row { f:static_text { title = '톤 프로필', width = 96, alignment = 'right' },
				f:popup_menu { items = profileItems, value = bind { key = 'profile', object = props }, width = 250 } },
			f:separator { fill_horizontal = 1 },
		}
		for _, r in ipairs(C.S_TONE) do editItems[#editItems + 1] = sliderRow(r) end
		editItems[#editItems + 1] = f:row { f:spacer { width = 100 },
			f:checkbox { title = '밝은 곳 부드럽게 (Soft Highs)', value = bind { key = 'softHi', object = props }, enabled = reviewing },
			f:checkbox { title = '어두운 곳 부드럽게 (Soft Lows)', value = bind { key = 'softLo', object = props }, enabled = reviewing } }
		for _, r in ipairs(C.S_CLIP) do editItems[#editItems + 1] = sliderRow(r) end
		editItems[#editItems + 1] = balanceTab
		editItems[#editItems + 1] = f:row { f:spacer { width = 100 },
			f:checkbox { title = '다음 사진에도 현재 값 유지', value = bind { key = 'carry', object = props } } }
		editItems[#editItems + 1] = f:static_text { title = bind { key = 'toast', object = props }, width = 420, height_in_lines = 2, font = '<system/small>' }
		local editTab = column({ spacing = 3 }, editItems)

		-- Detail tab (Lightroom's own settings; applied at [확인])
		local detailItems = rowsOf(C.S_DETAIL)
		detailItems[#detailItems + 1] = small('라이트룸 자신의 현상 설정으로 들어가며 [확인] 때 사진에 적용됩니다. 패널 미리보기에는 보이지 않지만, [확인] 뒤에 나오는 실제 결과 화면에서 볼 수 있고 거기서 [다시 조정] 으로 고칠 수 있습니다. '
			.. '시작 값은 라이트룸 RAW 기본(선명도 25 · 반경 1.0 · 색 노이즈 25)입니다. 변환 전에 이 값들을 손봐 둔 사진은 [확인] 때 이 값으로 바뀝니다.', 4)
		local detailTab = column({ spacing = 3 }, detailItems)

		local tabs = tabsView({
			{ title = 'Convert', id = 'convert', view = convertTab },
			{ title = 'Edit', id = 'edit', view = editTab },
			{ title = '세부 설정', id = 'detail', view = detailTab },
		}, 'tab')

		local contents = f:column {
			bind_to_object = props,
			spacing = f:control_spacing(),
			fill_horizontal = 1,
			f:row {
				spacing = f:control_spacing(),
				f:column {
					spacing = f:control_spacing(),
					f:static_text { title = bind { key = 'status', object = props }, width = 490, height_in_lines = 4 },
					f:picture { value = bind { key = 'previewPath', object = props }, width = C.PREVIEW_W, height = C.PREVIEW_H },
					f:static_text { title = bind { key = 'title', object = props }, width = 490, alignment = 'center' },
					f:row {
						spacing = f:control_spacing(),
						f:checkbox { title = 'A/B (처음 값과 비교)', value = bind { key = 'ab', object = props }, enabled = reviewing },
						f:spacer { width = 8 },
						f:push_button { title = '↶', tooltip = '미리보기를 왼쪽으로 90° 돌립니다 (사진 자체는 그대로)', enabled = canView,
							action = function() props.rot = (props.rot - 90) % 360 end },
						f:push_button { title = '↷', tooltip = '미리보기를 오른쪽으로 90° 돌립니다 (사진 자체는 그대로)', enabled = canView,
							action = function() props.rot = (props.rot + 90) % 360 end },
						f:push_button { title = '크게 보기', tooltip = '더 크고 자세한 미리보기 창을 엽니다', enabled = canView,
							action = function() LrTasks.startAsyncTask(openBig) end },
					},
					f:row {
						spacing = f:control_spacing(),
						f:push_button { title = '확인 · 적용하고 다음으로', enabled = reviewing, action = function() state.decision = 'ok' end },
						f:push_button { title = '이 사진 건너뛰기', enabled = reviewing, action = function() state.decision = 'skip' end },
						f:push_button { title = '중단', enabled = reviewing, action = function() state.decision = 'stop' end },
					},
					f:row {
						spacing = f:control_spacing(),
						f:push_button { title = '결과 좋음 · 다음으로', enabled = checking, action = function() state.checkDecision = 'next' end },
						f:push_button { title = '다시 조정', enabled = checking, action = function() state.checkDecision = 'again' end },
						f:push_button { title = '이 사진 변환 취소', enabled = checking, action = function() state.checkDecision = 'skip' end },
					},
				},
				tabs,
			},
			f:static_text {
				title = '미리보기는 라이트룸이 실제로 적용할 커브를 계산한 화면입니다 (채도는 HSL 로 들어가며 근사). [확인] 을 누르기 전에는 사진에 아무것도 적용하지 않고, 누른 뒤에는 라이트룸이 실제로 그린 결과를 한 번 더 보여 줍니다. '
					.. '확인 후 라이트룸의 노출 · 대비 · 하이라이트 · 섀도 · 화이트 · 블랙 슬라이더는 반대로 동작합니다 (톤 커브로 반전하기 때문). 톤 조절은 이 패널에서 하세요. '
					.. '최고 화질의 파일(파랑 복원 포함)은 파일 > 내보내기 > "네거티브 → 포지티브 변환" 을 쓰세요.',
				width = 960, height_in_lines = 3, font = '<system/small>',
			},
		}

		LrDialogs.presentFloatingDialog(_PLUGIN, {
			title = '네거티브 변환 · 베타 v' .. C.VERSION,
			contents = contents,
			blockTask = true,
			save_frame = 'NegConvertPanelFrame',
			windowWillClose = function()
				state.closed = true
				if not state.decision then state.decision = 'stop' end
			end,
		})
		-- the dialog is closed: let a running conversion finish tidying up before the property table goes away
		state.closed = true
		local waited = 0
		while (state.busy or state.worker) and waited < 600 do LrTasks.sleep(0.1); waited = waited + 1 end
		for _, p in ipairs(state.previews) do LrFileUtils.delete(p) end
	end)
end

LrTasks.startAsyncTask(showPanel)
