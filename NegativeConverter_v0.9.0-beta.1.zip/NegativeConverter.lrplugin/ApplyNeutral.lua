--[[ 선택한 사진에 "중립 현상"을 적용합니다: 톤 커브 선형, 대비/하이라이트/섀도/화이트/블랙/선명도/채도 0.
     네거티브 스캔은 라이트룸의 기본 현상(콘트라스트 커브 등)이 없는 편이 변환 결과가 안정적입니다.
     자르기와 화이트밸런스는 건드리지 않습니다. 되돌리려면 현상 모듈의 히스토리에서 이전 단계를 선택하세요.
     설정 전체가 한 번에 거부되면 항목을 하나씩 적용하고, 거부된 항목과 라이트룸의 오류 문구를 안내 창과 로그에 남깁니다.
     (Lua 5.1 문법만 사용) ]]
local LrApplication = import 'LrApplication'
local LrDialogs     = import 'LrDialogs'
local LrTasks       = import 'LrTasks'
local LrLogger      = import 'LrLogger'

local logger = LrLogger('NegConvert')
logger:enable('logfile')
local function log(msg) logger:info(tostring(msg)) end

local LINEAR = { 0, 0, 255, 255 }
local HISTORY = '네거티브 스캔용 중립 현상'

local function short(e)
	e = tostring(e or '')
	e = string.gsub(e, '[\r\n]+', ' ')
	if #e > 400 then e = string.sub(e, 1, 400) .. '…' end
	return e
end

-- NOTE: plain pcall() cannot wrap SDK calls that may yield (error "Yielding is not allowed within a C or metamethod call"); LrTasks.pcall() is the yield-safe version.
-- applies a whole table; if Lightroom refuses it, key by key. Returns (appliedKeys, rejected{ 'key (message)' ... }, wholeError)
local function applyRobust(photo, settings)
	local okAll, errAll = LrTasks.pcall(function() photo:applyDevelopSettings(settings, HISTORY) end)
	if okAll then
		local n = 0
		for _ in pairs(settings) do n = n + 1 end
		return n, {}, nil
	end
	log('whole settings table refused: ' .. short(errAll))
	local applied, rejected = 0, {}
	for key, value in pairs(settings) do
		local ok, err = LrTasks.pcall(function() photo:applyDevelopSettings({ [key] = value }, HISTORY) end)
		if ok then
			applied = applied + 1
		else
			rejected[#rejected + 1] = key .. ' (' .. short(err) .. ')'
			log('setting refused: ' .. key .. ' -> ' .. short(err))
		end
	end
	return applied, rejected, short(errAll)
end

LrTasks.startAsyncTask(function()
	local catalog = LrApplication.activeCatalog()
	local photos = catalog:getTargetPhotos()
	if not photos or #photos == 0 then
		LrDialogs.message('중립 현상', '사진을 먼저 선택해 주세요.', 'info')
		return
	end
	local settings = {
		ToneCurveName2012 = 'Linear',
		ToneCurvePV2012 = LINEAR, ToneCurvePV2012Red = LINEAR, ToneCurvePV2012Green = LINEAR, ToneCurvePV2012Blue = LINEAR,
		Exposure2012 = 0, Contrast2012 = 0, Highlights2012 = 0, Shadows2012 = 0, Whites2012 = 0, Blacks2012 = 0,
		Texture = 0, Clarity2012 = 0, Dehaze = 0, Vibrance = 0, Saturation = 0,
		Sharpness = 0, LuminanceSmoothing = 0, ColorNoiseReduction = 0,
	}
	local nKeys = 0
	for _ in pairs(settings) do nKeys = nKeys + 1 end

	local done, partial, failed = 0, 0, 0
	local rejectedAll, errors = {}, {}
	local fn = function()
		done, partial, failed, rejectedAll, errors = 0, 0, 0, {}, {}
		for _, photo in ipairs(photos) do
			local s2 = {}
			for k, v in pairs(settings) do s2[k] = v end
			local okC, curS = LrTasks.pcall(function() return photo:getDevelopSettings() end)
			if okC and type(curS) == 'table' then            -- newer Lightroom: a second copy of the tone curves that must be reset as well
				for _, ext in ipairs({ 'ExtendedToneCurvePV2012', 'ExtendedToneCurvePV2012Red', 'ExtendedToneCurvePV2012Green', 'ExtendedToneCurvePV2012Blue' }) do
					if curS[ext] ~= nil then s2[ext] = LINEAR end
				end
			end
			local applied, rejected, wholeErr = applyRobust(photo, s2)
			if applied == 0 then
				failed = failed + 1
				errors[#errors + 1] = wholeErr or '알 수 없는 오류'
			elseif #rejected > 0 then
				partial = partial + 1
				for _, r in ipairs(rejected) do rejectedAll[r] = true end
			else
				done = done + 1
			end
		end
	end
	-- another plug-in (or Lightroom) may be writing to the catalog: without a timeout Lightroom refuses at once, so wait and retry
	local gotAccess, lastErr = false, nil
	for attempt = 1, 4 do
		local ok, res = LrTasks.pcall(function() return catalog:withWriteAccessDo(HISTORY, fn, { timeout = 20 }) end)
		log('withWriteAccessDo try ' .. attempt .. ': ' .. tostring(ok) .. ' / ' .. tostring(res))
		if ok and (res == nil or res == 'executed') then gotAccess = true; break end
		lastErr = ok and ('카탈로그 쓰기 권한을 얻지 못했습니다 (결과: ' .. tostring(res) .. ')') or short(res)
		if attempt < 4 then LrTasks.sleep(1.5) end
	end
	if not gotAccess then errors = { lastErr } end

	local lines = { (done + partial) .. '장에 적용했습니다' .. ((failed > 0) and (' (' .. failed .. '장 실패)') or '') .. '.' }
	if partial > 0 then
		lines[#lines + 1] = ''
		lines[#lines + 1] = '라이트룸이 받아들이지 않은 항목 (나머지는 적용됨):'
		for r in pairs(rejectedAll) do lines[#lines + 1] = '  · ' .. r end
	end
	if #errors > 0 then
		lines[#lines + 1] = ''
		lines[#lines + 1] = '오류: ' .. errors[1]
	end
	if partial > 0 or #errors > 0 then
		lines[#lines + 1] = ''
		lines[#lines + 1] = '자세한 기록: 문서\\LrClassicLogs\\NegConvert.log'
	end
	LrDialogs.message('중립 현상', table.concat(lines, '\n'), (failed > 0 or (done + partial == 0 and #errors > 0)) and 'warning' or 'info')
end)
