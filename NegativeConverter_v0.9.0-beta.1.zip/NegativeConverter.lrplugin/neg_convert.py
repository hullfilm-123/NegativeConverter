#!/usr/bin/env python3
"""
neg_convert.py - camera-scanned colour negative -> positive (Coolscan-ish look)

  python neg_convert.py scan1.tif
  python neg_convert.py scan1.tif scan2.tif        (several files)
  python neg_convert.py *.tif                      (wildcards work on Windows too)

Pipeline
  1. white balance on the perforations (bare light source)
  2. divide by film base (removes the orange mask)
  3. automatic frame detection (frame = everything that is not film base,
     between the two perforation rows)
  4. blue-channel reconstruction where the scan has lost it (dense areas of the negative), one
     film model per roll - see "Blue repair" below
  5. density-domain inversion, per-channel levels measured inside the frame
  6. automatic exposure (dark frames are lifted, never darkened), smooth highlight roll-off,
     gentle S-curve, sRGB encode

Outputs (next to the input file, or in --outdir):
  <name>_positive_crop.jpg        frame only
  <name>_positive_full.jpg        whole scan incl. rebate / perforations
  <name>_positive_crop_16bit.tif  frame only, 16 bit (only for 16-bit input)

Assumes: perforations run along the top and bottom of the image,
input is gamma-encoded (normal TIFF/JPEG export), sRGB by default. A TIFF that carries another RGB profile
(ProPhoto, Adobe RGB, Display P3, a linear one ...) is recognised from the profile and converted (--input forces
a space). 16-bit integer and 32-bit float TIFFs are read (float = linear light, e.g. darktable's "TIFF 32 bit float"
with a linear output profile: no clipping of negative values, the best input). Camera RAW files (CR3, NEF, ARW, DNG
...) are read directly: with rawpy (pip install rawpy) if it loads, otherwise through darktable-cli (a temporary 16-bit
linear TIFF that is deleted afterwards) - linear data, no colour conversion before the density maths. The result is
always written as sRGB.

Blue repair (on by default, --no-fix-blue to disable): seen through the orange mask, a dense negative lets
almost no blue light through, and camera-developed TIFFs/JPEGs have that blue clipped to exactly 0 (often in
half the frame or more: sky, sunlit surfaces). Read as density that is "infinitely dense" and the positive
turns blue. The blue there is reconstructed from green/red with a censored regression ("blue is at least
this dense, and follows green along the film's neutral axis"); all frames of one film are fitted together
(two passes: a quick analysis of every file first). It is a reconstruction, not a measurement. For true
colour the scan has to keep the blue: expose the scan brighter (the blue channel needs ~2-3 stops more than
the film base suggests - bracket if red/green clip), develop the RAW with a wide gamut (ProPhoto) and no black
clipping: in sRGB the camera's colour conversion alone turns much of that blue negative, i.e. clips it to 0.
Colour balance of reconstructed frames can be nudged with --blue / --tint.

Safety: a file is never saved as a black placeholder. If the perforations cannot be measured the
white balance of the previous good frame of the same run is borrowed (and flagged); if there is
none, or the frame has no usable tonal range, the file is reported as FAILED and nothing is written.
The summary at the end lists every file that needs a look. Files named *_positive_* / *_check.jpg
are recognised as outputs and skipped, so `*.tif` can be re-run in the same folder.
"""
import argparse
import contextlib
import struct
import glob
import gc
import io
import os
import shutil
import subprocess
import sys
import tempfile
import time

import numpy as np
import cv2

# ---- look parameters (also available as command-line options) ----
GAMMA_NEG = 0.85      # colour-negative gamma; lower = more contrast
LOW_PCT, HIGH_PCT = 0.5, 99.7
S_CURVE = 0.12        # 0 = none
SAT = 1.0
HILITE = 0.0       # highlights pulled down (negative) / lifted (positive): o += HILITE*o^2 after the S-curve
TONE = None        # extra tone / colour-balance controls (dict, see tone_shape); None = off
CROP_INSET = 20       # px trimmed inside the detected frame edge
DEV_THRESHOLD = 0.08  # density difference from film base that counts as "image"
MIN_HOLES = 6         # fewer perforations than this -> white balance is not trusted
MIN_SPAN = 0.05       # density range inside the frame below this = blank / unusable frame
FIX_BLUE = True       # reconstruct the blue channel where it was lost (dense areas of the negative)
BLUE_CLIP = 0.038     # blue below this fraction of full scale counts as lost (2500 of 65535)
BLUE_FULL = 0.076     # ... and is fully trusted above this one
BLUE_NOISE = 0.0107   # typical noise of a dark blue value, as a fraction of full scale
BLUE_MIN_FRAC = 0.01  # repair a frame when more than this part of it has lost its blue
KAPPA_PRIOR = 1.8     # typical blue/green density slope of colour negative film
KAPPA_RANGE = (1.1, 2.6)
AUTO_EXPOSURE = True  # lift dark frames so the median lands near mid-grey (never darkens)
TARGET_MID = 0.14     # target median luminance (scene-linear)
EXPOSURE = 0.0        # extra exposure in stops
BLUE_SHIFT = 0.0      # colour shift in stops of blue (+ = bluer / cooler)
TINT = 0.0            # colour shift in stops of green (+ = greener, - = more magenta)
LAST_LIGHT = None     # (perf colour, film base, perforations) of the last good frame of this run
LAST_LIGHT_CS = None  # colour space that LAST_LIGHT was measured in
INPUT_SPACE = "auto"   # "auto" = read the TIFF's ICC profile | "srgb" | "prophoto"
CS = None             # colour space of the file being processed (set by _light_and_density)
RAW_BACKEND = "auto"  # camera RAW decoder: "auto" = rawpy if it loads, else darktable-cli | "rawpy" | "darktable"
DARKTABLE_CLI = ""    # path of darktable-cli (or of the darktable folder); empty = look for it
_NOTED = set()        # notices that are printed once per run
NOISE_LIN = None      # linear inputs: noise of the darkest blue, as a fraction of full scale (measured per file)
LAST_STATS = {}       # facts about the file process() converted last (for the GUI)
ROLL = {}             # abspath -> blue model of that file's film (filled by prepare_roll)


# ------------------------------------------------------------------ io
def read_image(path):
    """cv2.imread fails on non-ASCII (e.g. Korean) paths on Windows; decode from bytes instead."""
    data = np.fromfile(path, dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise IOError(f"cannot read image: {path}")
    if img.ndim == 2:
        raise ValueError("grayscale image: a colour scan is required")
    img = img[..., :3]
    if img.dtype.kind == "f":                       # 32-bit float TIFF: may hold negative / >1 values, never NaN
        img = np.nan_to_num(img.astype(np.float32, copy=False), nan=0.0, posinf=1e4, neginf=-1e4)
    return img


def write_image(path, arr, quality=95):
    ext = os.path.splitext(path)[1].lower()
    params = [cv2.IMWRITE_JPEG_QUALITY, quality] if ext in (".jpg", ".jpeg") else []
    ok, buf = cv2.imencode(ext, arr, params)
    if not ok:
        raise IOError(f"cannot encode {path}")
    buf.tofile(path)


# ------------------------------------------------------------- colour
def srgb_to_lin(x):
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4)


def lin_to_srgb(x):
    x = np.clip(x, 0, 1)
    return np.where(x <= 0.0031308, x * 12.92, 1.055 * x ** (1 / 2.4) - 0.055)


# ------------------------------------------------------------ tone shaping (the Edit controls of the Lightroom panel)
TONE_DEFAULTS = dict(bright=0.0, lights=0.0, darks=0.0, whites=0.0, blacks=0.0, fade=0.0,      # -100..100
                     softhi=0.0, softlo=0.0,                                                    # 0 / 1
                     md=(0.0, 0.0, 0.0), hi=(0.0, 0.0, 0.0), sh=(0.0, 0.0, 0.0),               # colour balance R, G, B  -100..100
                     hirange=5.0, shrange=5.0)                                                  # 0..10 (how far into the tones the balance reaches)


def tone_is_neutral(t):
    if not t:
        return True
    d = TONE_DEFAULTS
    for k, v in d.items():
        cur = t.get(k, v)
        if isinstance(v, tuple):
            if any(abs(float(a) - b) > 1e-9 for a, b in zip(cur, v)):
                return False
        elif k in ("hirange", "shrange"):
            if abs(float(cur) - v) > 1e-9 and any(abs(float(a)) > 1e-9 for a in t.get("hi" if k == "hirange" else "sh", (0, 0, 0))):
                return False
        elif abs(float(cur) - v) > 1e-9:
            return False
    return True


def tone_shape(o, t, c=None):
    """Brightness, Lights / Darks / Whites / Blacks, Fade, colour balance of the shadows / mids / highlights and soft clipping, on the
    display-referred signal o (0..1; same axis as the S-curve). o is either one channel (c = 0, 1, 2) or has the 3 channels on its last
    axis (c = None). Returns o unclipped (the caller clips). Everything is separable per channel, so it can also be written as a Lightroom
    point curve."""
    if tone_is_neutral(t):
        return o
    g = lambda k: t.get(k, TONE_DEFAULTS[k])
    o = np.clip(o, 0, None)
    b = float(g("bright")) / 100.0
    if b:
        o = o ** (2.0 ** (-0.6 * b))
    oc = np.clip(o, 0, 1)
    A = 0.20
    adds = 0.0
    l, d, w, k = (float(g(n)) / 100.0 for n in ("lights", "darks", "whites", "blacks"))
    if l:
        adds = adds + A * l * (6.75 * oc * oc * (1 - oc))
    if d:
        adds = adds + A * d * (6.75 * oc * (1 - oc) ** 2)
    if w:
        adds = adds + A * w * oc ** 3
    if k:
        adds = adds + A * k * (1 - oc) ** 3
    o = o + adds
    f = 0.15 * float(g("fade")) / 100.0
    if f:
        o = f + (1 - f) * o
    oc = np.clip(o, 0, 1)

    def amount(key):
        a = np.asarray(g(key), np.float64) / 100.0
        return float(a[c]) if (c is not None and a.ndim) else a
    S = 0.10
    for key, wt in (("md", 4.0 * oc * (1 - oc)),
                    ("hi", oc ** (6.0 - 0.5 * float(g("hirange")))),
                    ("sh", (1 - oc) ** (6.0 - 0.5 * float(g("shrange"))))):
        a = amount(key)
        if np.any(a):
            o = o + S * a * wt
    if float(g("softhi")):
        kk = 0.88
        o = np.where(o > kk, kk + (1 - kk) * np.tanh((o - kk) / (1 - kk)), o)
    if float(g("softlo")):
        kk = 0.12
        o = np.where(o < kk, kk - kk * np.tanh((kk - o) / kk), o)
    return o


# ------------------------------------------------------------ camera RAW
RAW_EXTS = (".cr3", ".cr2", ".crw", ".nef", ".nrw", ".arw", ".srf", ".sr2", ".raf", ".orf", ".rw2", ".pef",
            ".dng", ".srw", ".iiq", ".3fr", ".erf", ".mef", ".kdc", ".dcr", ".x3f")
_XYZ_FROM_SRGB = np.array([[0.4124564, 0.3575761, 0.1804375],
                           [0.2126729, 0.7151522, 0.0721750],
                           [0.0193339, 0.1191920, 0.9503041]])          # linear sRGB -> XYZ (D65)


def python_info():
    return f"Python {sys.version.split()[0]}, {sys.executable}"


def pip_command():
    """the pip command that installs into exactly the Python that is running (a console python, not pythonw)"""
    exe = sys.executable
    d, n = os.path.split(exe)
    if n.lower() == "pythonw.exe":
        exe = os.path.join(d, "python.exe")
    return f'"{exe}" -m pip install rawpy'


def is_raw(path):
    return os.path.splitext(path)[1].lower() in RAW_EXTS


def _matrix_candidates(m):
    """camera -> sRGB matrices that LibRaw's colour matrix can stand for. Whether that matrix maps XYZ->camera
    (dcraw's convention) or camera->XYZ is not something to trust from memory, so every reading is built here and
    the right one is picked by comparing with LibRaw's own sRGB rendering (see camera_to_srgb)."""
    m = np.asarray(m, np.float64)[:3, :3]
    out = []
    for name, to_cam in (("XYZ->camera", lambda: m), ("camera->XYZ", lambda: np.linalg.inv(m))):
        try:
            cam_rgb = to_cam() @ _XYZ_FROM_SRGB                           # sRGB -> camera
            cam_rgb = cam_rgb / cam_rgb.sum(axis=1, keepdims=True)         # white balanced: sRGB white = camera (1,1,1)
            out.append((name, np.linalg.inv(cam_rgb)))
        except np.linalg.LinAlgError:
            pass
    out.append(("camera->sRGB", m))
    return out


def _midtone_pairs(a, b):
    ok = ((a.min(1) > 0.004 * 65535) & (a.max(1) < 0.90 * 65535)
          & (b.min(1) > 0.002 * 65535) & (b.max(1) < 0.95 * 65535))
    return a[ok], b[ok]


def camera_to_srgb(raw, rawpy, common):
    """-> (3x3 matrix camera RGB -> linear sRGB, how it was found, trustworthy?)
    LibRaw can render the same RAW as camera RGB and as sRGB. Both are linear, so the sRGB one must equal the camera
    one times a 3x3 matrix; that is used to check the matrices built from the camera profile and, if none of them
    fits, to fit one directly."""
    a = raw.postprocess(output_color=rawpy.ColorSpace.raw, half_size=True, **common).reshape(-1, 3)[::3]
    b = raw.postprocess(output_color=rawpy.ColorSpace.sRGB, half_size=True, **common).reshape(-1, 3)[::3]
    a, b = _midtone_pairs(a.astype(np.float64), b.astype(np.float64))
    if len(a) >= 2000:
        scored = []
        try:
            for name, M in _matrix_candidates(raw.rgb_xyz_matrix):
                if np.all(np.isfinite(M)):
                    scored.append((float(np.abs(a @ M.T - b).mean() / b.mean()), name, M))
        except Exception:
            pass
        if scored:
            print("  RAW matrix candidates (error vs LibRaw's sRGB): " +
                  ", ".join(f"{n} {100 * e:.2f}%" for e, n, _ in sorted(scored, key=lambda t: t[0])))
            err, name, M = min(scored, key=lambda t: t[0])
            if err < 0.03:
                return M, f"from the camera profile ({name}), matches LibRaw's own sRGB rendering within {100 * err:.2f}%", True
        if np.linalg.cond(a) < 200:                                        # enough colour variety to fit it directly
            X = np.linalg.lstsq(a, b, rcond=None)[0]
            err = float(np.abs(a @ X - b).mean() / b.mean())
            if err < 0.03:
                return X.T, f"fitted to LibRaw's own sRGB rendering (error {100 * err:.2f}%)", True
    return np.eye(3), "NOT FOUND (colours will be off)", False


class RawpyUnavailable(RuntimeError):
    pass


class DarktableUnavailable(RuntimeError):
    pass


def read_raw_rawpy(path):
    """Camera RAW (CR3, NEF, ARW, DNG ...) -> linear, camera-native 16-bit RGB as a BGR array (like read_image gives),
    plus its ColourSpace. No gamma, no colour conversion (so nothing is clipped by one), no auto brightness, the
    camera's white balance; the demosaic is LibRaw's default. Needs the 'rawpy' package."""
    try:
        import rawpy
    except ModuleNotFoundError as e:
        if (e.name or "").split(".")[0] != "rawpy":
            raise RawpyUnavailable(f"'rawpy' needs a module that is missing in this Python ({python_info()}): {e}")
        raise RawpyUnavailable(f"'rawpy' is not installed for the Python that runs this program ({python_info()}). "
                               f"Install it for THAT Python with:  {pip_command()}")
    except Exception as e:                      # e.g. "DLL load failed", numpy version clash: installed but unusable
        raise RawpyUnavailable(f"'rawpy' is installed but cannot be loaded by this Python ({python_info()}): "
                               f"{type(e).__name__}: {e}")
    common = dict(use_camera_wb=True, no_auto_bright=True, adjust_maximum_thr=0.0, gamma=(1, 1), output_bps=16)
    with contextlib.ExitStack() as st:
        try:
            raw = st.enter_context(rawpy.imread(st.enter_context(open(path, "rb"))))    # file object: any (Korean) path works
        except TypeError:
            raw = st.enter_context(rawpy.imread(path))
        if getattr(raw, "num_colors", 3) != 3:
            raise RuntimeError("only RGB cameras are supported (this RAW has %s colours)" % raw.num_colors)
        facts = []
        for label, attr in (("black levels", "black_level_per_channel"), ("white level", "white_level"),
                            ("camera WB", "camera_whitebalance"), ("colours", "color_desc")):
            try:
                facts.append(f"{label} {getattr(raw, attr)}")
            except Exception:
                pass
        lib = getattr(rawpy, "libraw_version", None)
        print(f"  RAW: rawpy {getattr(rawpy, '__version__', '?')}" + (f" / LibRaw {'.'.join(map(str, lib))}" if lib else "")
              + ("; " + "; ".join(facts) if facts else ""))
        M, how, ok = camera_to_srgb(raw, rawpy, common)
        rgb = raw.postprocess(output_color=rawpy.ColorSpace.raw, **common)
    sub = rgb[::8, ::8].reshape(-1, 3)
    print("  RAW data  zeros % (R,G,B): " + ", ".join(f"{100 * float((sub[:, c] == 0).mean()):.2f}" for c in range(3))
          + "   median: " + ", ".join(f"{int(np.median(sub[:, c]))}" for c in range(3))
          + "   p99.9: " + ", ".join(f"{int(np.percentile(sub[:, c], 99.9))}" for c in range(3)) + "   (of 65535)")
    bgr = np.ascontiguousarray(rgb[..., ::-1])
    del rgb, sub
    warn = None if ok else "the camera colour matrix could not be determined: colours are probably off"
    return (bgr, ColourSpace("camera RAW", gamma=1.0, to_srgb=M),
            f"rawpy: linear, camera white balance; camera->sRGB matrix {how}", warn)


# ---- darktable route: darktable-cli is a signed program, so it runs where unsigned Python extensions (rawpy) are blocked
_CLEAN_XMP = """<?xpacket begin="" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="XMP Core 4.4.0-Exiv2">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about=""
   xmlns:darktable="http://darktable.sf.net/"
   darktable:xmp_version="5"
   darktable:raw_params="0"
   darktable:auto_presets_applied="1"
   darktable:history_end="0">
   <darktable:history>
    <rdf:Seq/>
   </darktable:history>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>
"""


def find_darktable_cli():
    cands = []
    for c in (DARKTABLE_CLI, os.environ.get("DARKTABLE_CLI", "")):
        if c:
            cands.append(c)
    for n in ("darktable-cli", "darktable-cli.exe"):
        w = shutil.which(n)
        if w:
            cands.append(w)
    for key in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)", "LOCALAPPDATA"):
        root = os.environ.get(key)
        if root:
            for pat in ("darktable*", os.path.join("Programs", "darktable*")):
                cands += sorted(glob.glob(os.path.join(root, pat, "bin", "darktable-cli.exe")), reverse=True)
    cands += ["/Applications/darktable.app/Contents/MacOS/darktable-cli", "/usr/bin/darktable-cli",
              "/usr/local/bin/darktable-cli", "/opt/darktable/bin/darktable-cli"]
    for c in cands:
        if os.path.isdir(c):                                           # the user gave the darktable folder
            for sub in ("bin", ""):
                for n in ("darktable-cli.exe", "darktable-cli"):
                    f = os.path.join(c, sub, n)
                    if os.path.isfile(f):
                        return f
        elif os.path.isfile(c):
            if "cli" not in os.path.basename(c).lower():                   # darktable.exe given: use its -cli sibling
                for n in ("darktable-cli.exe", "darktable-cli"):
                    sib = os.path.join(os.path.dirname(c), n)
                    if os.path.isfile(sib):
                        return sib
            return c
    return None


def _run_darktable(cmd, timeout=900):
    kw = dict(stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    if os.name == "nt":
        kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        r = subprocess.run(cmd, **kw)
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"darktable-cli did not finish within {timeout} s")
    except OSError as e:
        raise RuntimeError(f"darktable-cli could not be started: {e}")
    return r.returncode, r.stdout.decode("utf-8", "replace")


def _ascii_tempdir():
    """a fresh temp folder whose path is plain ASCII (a Korean Windows user name in %TEMP% would otherwise end up in
    the paths handed to darktable-cli); falls back to the normal temp folder when no ASCII place is writable."""
    base = [tempfile.gettempdir()]
    if os.name == "nt":
        base += [os.environ.get("PUBLIC", ""), os.path.join(os.environ.get("SystemDrive", "C:") + os.sep, "Users", "Public"),
                 os.environ.get("ProgramData", "")]
    first = None
    for b in base:
        if not b or not os.path.isdir(b):
            continue
        try:
            d = tempfile.mkdtemp(prefix="negconv_", dir=b)
        except OSError:
            continue
        if d.isascii():
            if first:
                shutil.rmtree(first, ignore_errors=True)
            return d
        first = first or d
    if first:
        return first
    return tempfile.mkdtemp(prefix="negconv_")


def read_raw_darktable(path):
    """Camera RAW -> 16-bit linear TIFF made by darktable-cli in a temp folder (deleted afterwards) -> the usual
    reader. The workflow is set to "none" (no filmic / exposure / colour calibration), the output profile to linear
    Rec2020, a clean XMP replaces any history, and a private config + in-memory library keep the user's darktable
    (and its .xmp sidecars) untouched, also while the darktable window is open."""
    exe = find_darktable_cli()
    if exe is None:
        raise DarktableUnavailable("darktable-cli was not found (looked in PATH and the usual install folders"
                                   + (f"; the path given was {DARKTABLE_CLI!r}" if DARKTABLE_CLI else "")
                                   + ") - give its path (GUI: 'darktable-cli 경로', command line: --darktable PATH)")
    tmp = _ascii_tempdir()
    try:
        src = os.path.join(tmp, "in" + os.path.splitext(path)[1].lower())
        shutil.copyfile(path, src)                          # ASCII name; no user .xmp sidecar next to it
        xmp = os.path.join(tmp, "clean.xmp")
        with open(xmp, "w", encoding="utf-8") as f:
            f.write(_CLEAN_XMP)
        cfg = os.path.join(tmp, "cfg")
        os.makedirs(cfg)
        out = os.path.join(tmp, "out.tif")
        tail = ["--core", "--configdir", cfg, "--library", ":memory:",
                "--conf", "plugins/darkroom/workflow=none",
                "--conf", "plugins/imageio/format/tiff/bpp=16",
                "--conf", "plugins/imageio/format/tiff/compress=0"]
        tries = [("clean xmp + linear Rec2020", True, True), ("linear Rec2020, no xmp", False, True),
                 ("default output profile", False, False)]
        last = ""
        for label, use_xmp, use_icc in tries:
            for old in glob.glob(os.path.join(tmp, "out*.tif*")):
                os.remove(old)
            cmd = ([exe, src] + ([xmp] if use_xmp else []) + [out]
                   + (["--icc-type", "LIN_REC2020"] if use_icc else []) + ["--apply-custom-presets", "0"] + tail)
            t0 = time.time()
            code, text = _run_darktable(cmd)
            hits = sorted(glob.glob(os.path.join(tmp, "out*.tif*")))
            if code == 0 and hits:
                secs = time.time() - t0
                break
            last = f"[{label}] exit code {code}; output: {text.strip()[-500:] or '(none)'}"
        else:
            raise RuntimeError("darktable-cli failed. Last try " + last + "  | command: " + " ".join(f'"{c}"' for c in cmd[:3]) + " ...")
        bgr = read_image(hits[0])
        cs = detect_colourspace(hits[0], bgr.dtype)
        warn = None
        if bgr.dtype == np.uint8:
            warn = "darktable wrote an 8-bit file - colour precision is poor (the bit-depth option was not accepted)"
        elif not cs.is_linear:
            warn = (f"darktable did not write a linear profile (got: {cs.name}): the data is gamma-encoded and the "
                    "wide-gamut advantage is probably lost (the output-profile option was not accepted)")
        return bgr, cs, f"darktable-cli [{label}], {cs.name}, {bgr.dtype}, {secs:.0f} s", warn
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def read_raw(path):
    """-> (BGR array, ColourSpace, description, warning or None). RAW_BACKEND decides: rawpy (fast, but it is an
    unsigned Python extension that Windows' Smart App Control may block) or darktable-cli; "auto" tries rawpy first."""
    if RAW_BACKEND == "darktable":
        return read_raw_darktable(path)
    try:
        return read_raw_rawpy(path)
    except RawpyUnavailable as e:
        if RAW_BACKEND == "rawpy":
            raise
        if "rawpy" not in _NOTED:
            _NOTED.add("rawpy")
            print(f"  note: rawpy cannot be used here -> camera RAW files are converted with darktable-cli instead.\n"
                  f"        ({str(e)[:300]})")
        try:
            return read_raw_darktable(path)
        except DarktableUnavailable as e2:
            raise RuntimeError(f"cannot read camera RAW. (1) rawpy: {e}   (2) darktable: {e2}")


# ------------------------------------------------- input colour space
_XYZ50_TO_SRGB = np.array([[3.1338561, -1.6168667, -0.4906146],
                           [-0.9787684, 1.9161415, 0.0334540],
                           [0.0719453, -0.2289914, 1.4052427]])


class ColourSpace:
    """Transfer curve + primaries of the input file. sRGB keeps the original analytic code path (to_srgb is None);
    anything else is decoded with its own curve and converted to sRGB primaries at the very end."""

    def __init__(self, name, gamma=None, table=None, to_srgb=None):
        self.name, self.gamma, self.table, self.to_srgb = name, gamma, table, to_srgb
        if gamma is None and table is None:                          # sRGB
            self.noise_k = 1.04                                      # = log10(e) * 2.4
        else:
            g = gamma if gamma is not None else float(np.log(max(self.decode(np.float64(0.5)), 1e-9)) / np.log(0.5))
            self.noise_k = float(np.log10(np.e) * np.clip(g, 1.0, 3.0))

    @property
    def is_srgb(self):
        return self.gamma is None and self.table is None

    @property
    def is_linear(self):
        if self.is_srgb:
            return False
        return abs(float(self.decode(np.float64(0.5))) - 0.5) < 0.01

    def decode(self, x):
        """encoded 0..1 -> linear light"""
        if self.is_srgb:
            return srgb_to_lin(x)
        if self.gamma is not None:
            return np.power(np.maximum(x, 0), self.gamma)
        xs = np.linspace(0.0, 1.0, len(self.table))
        return np.interp(x, xs, self.table)

    def encode(self, y):
        """linear light -> encoded 0..1"""
        if self.is_srgb:
            return lin_to_srgb(y)
        if self.gamma is not None:
            return np.power(np.clip(y, 0, None), 1.0 / self.gamma)
        xs = np.linspace(0.0, 1.0, len(self.table))
        return np.interp(y, self.table, xs)


SRGB = ColourSpace("sRGB")
LINEAR = ColourSpace("linear (no profile)", gamma=1.0)      # linear light, primaries taken as sRGB's
PROPHOTO = ColourSpace("ProPhoto RGB", gamma=1.8, to_srgb=_XYZ50_TO_SRGB @ np.array(
    [[0.7977, 0.1352, 0.0313], [0.2880, 0.7119, 0.0001], [0.0000, 0.0000, 0.8249]]))


def _tiff_icc(path):
    """the embedded ICC profile of a (classic) TIFF, or None"""
    try:
        with open(path, "rb") as f:
            h = f.read(8)
            if h[:2] not in (b"II", b"MM"):
                return None
            e = "<" if h[:2] == b"II" else ">"
            if struct.unpack(e + "H", h[2:4])[0] != 42:
                return None
            f.seek(struct.unpack(e + "I", h[4:8])[0])
            n = struct.unpack(e + "H", f.read(2))[0]
            for _ in range(n):
                tag, _typ, cnt, val = struct.unpack(e + "HHI4s", f.read(12))
                if tag == 34675:
                    f.seek(struct.unpack(e + "I", val)[0])
                    return f.read(cnt)
    except (OSError, struct.error):
        return None
    return None


def _icc_tags(icc):
    tags = {}
    for i in range(struct.unpack(">I", icc[128:132])[0]):
        sig, off, size = struct.unpack(">4sII", icc[132 + 12 * i:144 + 12 * i])
        tags[sig] = icc[off:off + size]
    return tags


def _icc_curve(d):
    """-> ("gamma", g) or ("table", samples of the curve at linspace(0, 1, n))"""
    if d[:4] == b"curv":
        n = struct.unpack(">I", d[8:12])[0]
        if n == 0:
            return "gamma", 1.0
        if n == 1:
            return "gamma", struct.unpack(">H", d[12:14])[0] / 256.0
        return "table", np.frombuffer(d[12:12 + 2 * n], ">u2").astype(np.float64) / 65535.0
    if d[:4] == b"para":
        ft = struct.unpack(">H", d[8:10])[0]
        npar = {0: 1, 1: 3, 2: 4, 3: 5, 4: 7}[ft]
        p = [struct.unpack(">i", d[12 + 4 * i:16 + 4 * i])[0] / 65536.0 for i in range(npar)]
        p += [0.0] * (7 - len(p))
        g, a, b, c, dd, e, f = p
        x = np.linspace(0.0, 1.0, 4096)
        lin = np.maximum(a * x + b, 0) ** g
        if ft == 0:
            y = x ** g
        elif ft == 1:
            y = np.where(x >= -b / a, lin, 0.0)
        elif ft == 2:
            y = np.where(x >= -b / a, lin + c, c)
        elif ft == 3:
            y = np.where(x >= dd, lin, c * x)
        else:
            y = np.where(x >= dd, lin + e, c * x + f)
        return "table", np.maximum.accumulate(np.clip(y, 0, 1))
    raise ValueError("unsupported tone curve")


def _cs_from_icc(icc):
    tags = _icc_tags(icc)
    desc = tags.get(b"desc", b"")
    text = desc.decode("latin1").replace("\x00", "")
    if desc[:4] == b"desc" and len(desc) > 12:                      # ICC v2 text description
        name = desc[12:12 + max(struct.unpack(">I", desc[8:12])[0] - 1, 0)].decode("latin1").strip()
    else:
        name = ""
    name = name or "ICC profile"
    kind, val = _icc_curve(tags[b"rTRC"])
    if "sRGB" in text and not (kind == "gamma" and abs(val - 1.0) < 0.05):     # (a linear "sRGB" profile is not sRGB)
        return SRGB
    cols = []
    for k in (b"rXYZ", b"gXYZ", b"bXYZ"):
        cols.append([struct.unpack(">i", tags[k][8 + 4 * i:12 + 4 * i])[0] / 65536.0 for i in range(3)])
    to_srgb = _XYZ50_TO_SRGB @ np.array(cols).T
    if not np.allclose(to_srgb @ np.ones(3), 1.0, atol=0.03):
        raise ValueError("white point does not map to white")
    if kind == "gamma":
        return ColourSpace(name, gamma=val, to_srgb=to_srgb)
    return ColourSpace(name, table=val, to_srgb=to_srgb)


def detect_colourspace(path, dtype=None):
    if INPUT_SPACE == "srgb":
        return SRGB
    if INPUT_SPACE == "prophoto":
        return PROPHOTO
    if INPUT_SPACE == "linear":
        return LINEAR
    unknown = LINEAR if (dtype is not None and np.dtype(dtype).kind == "f") else SRGB     # float files are linear
    icc = _tiff_icc(path)
    if icc is None:
        return unknown
    try:
        return _cs_from_icc(icc)
    except Exception as e:
        print(f"  WARNING: colour profile of the file not understood ({e}) -> treated as {unknown.name}")
        return unknown


def estimate_blue_noise(blue, maxv):
    """Noise of the blue channel where it is darkest (robust, from the high-pass residual of the centre of the frame),
    as a fraction of full scale. Linear data has no gamma curve to turn the noise floor into "so many sRGB levels",
    so here the thresholds of the blue model follow the measured noise instead."""
    H, W = blue.shape
    x = np.ascontiguousarray(blue[int(H * 0.2):int(H * 0.8), int(W * 0.2):int(W * 0.8)], dtype=np.float32)
    bl = cv2.GaussianBlur(x, (0, 0), 2.0)
    res = x - cv2.GaussianBlur(x, (0, 0), 0.8)
    m = bl <= np.percentile(bl[::4, ::4], 2.0)                      # the darkest 2 % of the blue channel
    r = res[m]
    sig = 1.4826 * float(np.median(np.abs(r - np.median(r)))) / 0.79   # /0.79: the residual of white noise is that much smaller
    return float(np.clip(sig, 0.5 / (maxv if maxv > 1.0 else 65535.0), 0.02))


def blue_levels(maxv):
    """(lost below, trusted above, noise) of the blue channel in raw units. They are defined for sRGB-encoded data
    (BLUE_CLIP etc.) and converted to the input's own curve, so that they mean the same amount of light."""
    if CS is None or CS.is_srgb:
        return BLUE_CLIP * maxv, BLUE_FULL * maxv, BLUE_NOISE * maxv
    if CS.is_linear and NOISE_LIN:                                  # same multiples of the noise as for sRGB data
        sg = NOISE_LIN * maxv
        return 3.55 * sg, 8.05 * sg, sg
    lin_c, lin_f = srgb_to_lin(BLUE_CLIP), srgb_to_lin(BLUE_FULL)
    sig_lin = BLUE_NOISE / 12.92                                    # BLUE_NOISE sits on sRGB's linear toe
    h = 0.05 * lin_c
    slope = (CS.encode(lin_c + h) - CS.encode(lin_c - h)) / (2 * h)
    return float(CS.encode(lin_c) * maxv), float(CS.encode(lin_f) * maxv), float(sig_lin * slope * maxv)


def chroma_denoise(bgr8, scale=0.5):
    # 8-bit source: blue channel of an orange-masked negative is very coarse -> smooth chroma only
    lab = cv2.cvtColor(bgr8, cv2.COLOR_BGR2LAB)
    small = cv2.resize(lab, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    for c in (1, 2):
        ch = np.ascontiguousarray(small[..., c])
        ch = cv2.bilateralFilter(ch, 9, 14, 7)
        ch = cv2.bilateralFilter(ch, 9, 14, 7)
        small[..., c] = ch
    up = cv2.resize(small, (lab.shape[1], lab.shape[0]), interpolation=cv2.INTER_CUBIC)
    lab[..., 1:] = up[..., 1:]
    return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)


# ------------------------------------------------- blue channel reconstruction
# Seen through the orange mask, a DENSE negative lets almost no blue light through. In a camera-developed TIFF the
# blue channel is therefore clipped to exactly 0 wherever the scene is bright or blue (measured on real scans: 5-78 %
# of the frame, starting about 1.4 density above the film base on Ektar, 0.95 on Gold). Read as a density, 0 means
# "infinitely dense", and the positive turns blue. The true value is unknown but not arbitrary:
#   * it is at least as dense as the clipping level (that is all "clipped" tells us), and
#   * blue density follows green density along the film's neutral axis (slope kappa, a property of the film),
#     plus a little of the red-vs-green colour difference u (blue sky: red is low).
# A censored (Tobit) regression  B = a + kappa*G + beta*u  is fitted on the pixels where blue is still measurable;
# for clipped pixels the conditional mean E[B | B >= clip level] is used. kappa is estimated over all frames of a
# film at once (prepare_roll), because one frame with 50-80 % clipping says little about it.
# This is a reconstruction, not a measurement: for true colour the scan itself has to be exposed/developed so that
# blue is not clipped (see the advice printed with the warning).
def _pdf(x):
    return np.exp(-0.5 * x * x) / np.sqrt(2.0 * np.pi)


def _cdf(x):
    z = np.abs(x) / np.sqrt(2.0)                      # Abramowitz-Stegun 7.1.26, abs. error 1.5e-7
    t = 1.0 / (1.0 + 0.3275911 * z)
    y = 1.0 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t
               + 0.254829592) * t * np.exp(-z * z)
    return 0.5 * (1.0 + np.sign(x) * y)


def _lam(a):
    """inverse Mills ratio pdf(a) / (1 - cdf(a)); 1 - cdf loses all precision for a > 5, so a > 3 uses the
    continued fraction a + 1/(a + 2/(a + 3/(a + ...)))"""
    a = np.maximum(np.asarray(a, np.float64), -35.0)
    out = np.empty_like(a)
    lo = a < 3.0
    out[lo] = _pdf(a[lo]) / np.maximum(1.0 - _cdf(a[lo]), 1e-300)
    x = a[~lo]
    t = x.copy()
    for k in range(40, 0, -1):
        t = x + k / t
    out[~lo] = t
    return out


def _smooth(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3.0 - 2.0 * x)


def tobit_fit(X, y, c, cens, iters=60):
    """Right-censored linear regression (Tobit), maximum likelihood by Newton's method on the concave
    Olsen (1978) parametrisation. X (n,p); y (n,) valid where ~cens; c (n,) clip level per sample.
    Returns (weights, sigma)."""
    X, y, c = np.asarray(X, np.float64), np.asarray(y, np.float64), np.asarray(c, np.float64)
    n, p = X.shape
    obs = ~cens
    Xo, yo, Xc, cc = X[obs], y[obs], X[cens], c[cens]
    no = len(yo)
    w0 = np.linalg.lstsq(Xo, yo, rcond=None)[0]
    s0 = max(float(np.std(yo - Xo @ w0)), 0.05)
    th = np.concatenate([w0 / s0, [1.0 / s0]])        # gamma = w / sigma, h = 1 / sigma
    XtX, Xty, yy = Xo.T @ Xo, Xo.T @ yo, float(yo @ yo)

    def fgh(th):
        g, h = th[:p], th[p]
        r = h * yo - Xo @ g
        ll = no * np.log(h) - 0.5 * float(r @ r)
        grad = np.zeros(p + 1)
        H = np.zeros((p + 1, p + 1))
        grad[:p] = Xo.T @ r
        grad[p] = no / h - float(r @ yo)
        H[:p, :p] = -XtX
        H[:p, p] = Xty
        H[p, :p] = Xty
        H[p, p] = -no / h ** 2 - yy
        if len(cc):
            a = np.maximum(h * cc - Xc @ g, -35.0)
            lam = _lam(a)
            ll += float(np.sum(-0.5 * a * a - 0.9189385332 - np.log(lam)))     # log(1 - cdf(a))
            lp = lam * (lam - a)
            grad[:p] += Xc.T @ lam
            grad[p] -= float(lam @ cc)
            H[:p, :p] -= (Xc * lp[:, None]).T @ Xc
            H[:p, p] += Xc.T @ (lp * cc)
            H[p, :p] += Xc.T @ (lp * cc)
            H[p, p] -= float(np.sum(lp * cc * cc))
        return ll, grad, H

    ll, grad, H = fgh(th)
    for _ in range(iters):
        try:
            step = np.linalg.solve(H - 1e-9 * np.eye(p + 1), -grad)
        except np.linalg.LinAlgError:
            break
        t, ok = 1.0, False
        while t > 1e-4:
            th2 = th + t * step
            if th2[p] > 0:
                ll2, g2, H2 = fgh(th2)
                if np.isfinite(ll2) and ll2 >= ll - 1e-9:
                    ok = True
                    break
            t *= 0.5
        if not ok:
            break
        done = abs(ll2 - ll) < 1e-9 * max(1.0, abs(ll))
        th, ll, grad, H = th2, ll2, g2, H2
        if done:
            break
    sig = 1.0 / th[p]
    return th[:p] * sig, sig


def _d_of_raw(raw, perf_b, base_b, maxv):
    """density (relative to the film base) that a raw blue value corresponds to"""
    return float(-np.log10(CS.decode(np.float64(raw) / maxv) / perf_b / base_b))


def blue_samples(D, rawB, box, perf_b, base_b, maxv, step=8, inset=30):
    """small sample of the frame interior: densities, raw blue, and which blue values count as lost"""
    x0, y0, x1, y1 = box
    sl = (slice(y0 + inset, y1 - inset, step), slice(x0 + inset, x1 - inset, step))
    d = D[sl].reshape(-1, 3)
    rb = rawB[sl].reshape(-1).astype(np.float32)
    T = blue_levels(maxv)[0]
    return dict(DR=d[:, 0].copy(), DG=d[:, 1].copy(), DB=d[:, 2].copy(), cens=rb < T,
                c=_d_of_raw(T, perf_b, base_b, maxv))


def _even_subset(n, k):
    """k evenly spread indices out of n (deterministic). numpy.random is deliberately not used: its extension modules
    are blocked by Windows Smart App Control on some PCs ('DLL load failed while importing _bounded_integers')."""
    return np.linspace(0, n - 1, k).astype(np.int64)


def fit_blue_group(samples):
    """fit the blue model on the pooled samples of one film (one or more frames)"""
    DR = np.concatenate([s["DR"] for s in samples]).astype(np.float64)
    DG = np.concatenate([s["DG"] for s in samples]).astype(np.float64)
    DB = np.concatenate([s["DB"] for s in samples]).astype(np.float64)
    cens = np.concatenate([s["cens"] for s in samples])
    c = np.concatenate([np.full(len(s["DG"]), s["c"]) for s in samples])
    if len(DG) > 1500000:
        idx = _even_subset(len(DG), 1500000)
        DR, DG, DB, cens, c = DR[idx], DG[idx], DB[idx], cens[idx], c[idx]
    frac = float(cens.mean())
    m = DG > 0.05                                           # neutral axis of red vs green: orthogonal fit
    xm, ym = DG[m].mean(), DR[m].mean()
    ev, V = np.linalg.eigh(np.cov(np.stack([DG[m] - xm, DR[m] - ym])))
    rho = float(V[1, -1] / V[0, -1])
    u = DR - rho * DG
    su = float(u.std()) + 1e-6
    us = u / su
    one = np.ones_like(DG)
    w, sig = tobit_fit(np.stack([one, DG, us], 1), DB, c, cens)
    kappa_free = float(w[1])
    # a frame with most of its blue lost says little about the slope: lean on the typical value of the film,
    # the more so the less blue was measurable and the fewer frames there are
    wt = float(np.clip((1.0 - frac) * np.sqrt(len(samples)), 0.0, 1.0))
    kappa = float(np.clip(KAPPA_PRIOR + (kappa_free - KAPPA_PRIOR) * wt, KAPPA_RANGE[0], KAPPA_RANGE[1]))
    if abs(kappa - kappa_free) > 1e-6:                      # slope pinned: refit the remaining coefficients
        w2, sig = tobit_fit(np.stack([one, us], 1), DB - kappa * DG, c - kappa * DG, cens)
        a, beta = float(w2[0]), float(w2[1])
    else:
        a, beta = float(w[0]), float(w[2])
    return dict(a=a, kappa=kappa, beta=beta, rho=rho, su=su, sig=float(sig), frac=frac, n=len(samples),
                kappa_free=kappa_free)


def apply_blue_model(D, rawB, m, perf_b, base_b, maxv, rows=400):
    """replace the blue density where blue is lost (in place, in row chunks)"""
    T_c, T_full, s_raw = blue_levels(maxv)
    c = _d_of_raw(T_c, perf_b, base_b, maxv)
    a, kap, beta, rho, su, sig = m["a"], m["kappa"], m["beta"], m["rho"], m["su"], m["sig"]
    for r in range(0, D.shape[0], rows):
        d = D[r:r + rows]
        rb = rawB[r:r + rows].astype(np.float32)
        dg, dr, db = d[..., 1], d[..., 0], d[..., 2]
        mu = a + kap * dg + beta * ((dr - rho * dg) / su)             # what green/red say about blue
        clipped = (mu + sig * _lam((c - mu) / sig)).astype(np.float32)   # E[B | B >= c]
        sm = CS.noise_k * s_raw / np.maximum(rb, 1.0 if maxv > 1.0 else 1.5e-5)                       # noise of the measured value (density units)
        wm = sig ** 2 / (sig ** 2 + sm ** 2)                          # precision weighting: measured vs model
        meas = (1.0 - wm) * mu + wm * db
        s = _smooth((rb - T_c) / (T_full - T_c))
        d[..., 2] = (1.0 - s) * clipped + s * meas


_ANALYSIS = {}        # (path, mtime, size, box) -> result of analyze(); re-running a few frames costs nothing


def analyze(path, manual_box=None):
    """pass 1 for one file: light source, film base, frame, and a small sample for the blue model"""
    key = (os.path.abspath(path), os.path.getmtime(path), os.path.getsize(path),
           tuple(manual_box) if manual_box else None)
    if key in _ANALYSIS:
        return _ANALYSIS[key]
    with contextlib.redirect_stdout(io.StringIO()):
        bgr, maxv, H, W, D, comps, perf, base, problems = _light_and_density(path)
        box = _frame_box(D, comps, H, W, manual_box, [])
    smp = blue_samples(D, bgr[..., 0], box, float(perf[2]), float(base[2]), maxv)
    info = dict(samples=smp, frac=float(smp["cens"].mean()), base_density=-np.log10(np.asarray(base, np.float64)),
                cs=CS.name)
    _ANALYSIS[key] = info
    return info


def prepare_roll(paths, manual_box=None, progress=None, should_stop=None):
    """pass 1 over all files: group them by film base colour and fit ONE blue model per film (ROLL)."""
    global LAST_LIGHT
    ROLL.clear()
    infos = []
    for k, p in enumerate(paths):
        if should_stop is not None and should_stop():
            break
        if progress is not None:
            progress(k, len(paths), p)
        if is_raw(p):                       # decoding a RAW takes seconds; linear data has its blue measured anyway
            if "rollraw" not in _NOTED:
                _NOTED.add("rollraw")
                print("  camera RAW files are not part of the film analysis (converted on their own)")
            continue
        try:
            info = analyze(p, manual_box)
        except Exception as e:                         # that file will be fitted on its own later
            print(f"  analysis skipped for {os.path.basename(p)}: {e}")
            continue
        infos.append((p, info))
        print(f"  analysed {os.path.basename(p)}: blue lost in {100 * info['frac']:.0f}% of the frame")
    LAST_LIGHT = None
    groups = []
    for p, info in infos:
        for g in groups:
            if (g[0][1]["cs"] == info["cs"]
                    and np.all(np.abs(g[0][1]["base_density"] - info["base_density"]) < np.array([0.10, 0.10, 0.15]))):
                g.append((p, info))
                break
        else:
            groups.append([(p, info)])
    for gi, g in enumerate(groups, 1):
        if max(i["frac"] for _, i in g) < BLUE_MIN_FRAC:
            continue
        m = fit_blue_group([i["samples"] for _, i in g])
        for p, _ in g:
            ROLL[os.path.abspath(p)] = m
        print(f"  film group {gi}: {len(g)} frame(s), base density {np.round(g[0][1]['base_density'], 2)}, "
              f"blue lost in {100 * m['frac']:.0f}% -> blue/green slope kappa = {m['kappa']:.2f} "
              f"(free fit {m['kappa_free']:.2f})")


# ------------------------------------------------------ perforations
def find_perforations(gray, H, W):
    """Perforation holes = bright, rectangular blobs in the top/bottom bands.
    The threshold is chosen per band with Otsu (separates 'film' from 'light'), NOT relative to the
    brightest pixel: holes are often not equally bright (light falloff), and a threshold tied to the
    brightest hole misses all the dimmer ones. Blobs are then filtered by shape and size."""
    mask = np.zeros(gray.shape, np.uint8)
    for sl in (slice(0, int(H * 0.16)), slice(int(H * 0.84), H)):
        b8 = np.clip(gray[sl] * 255.0, 0, 255).astype(np.uint8)
        t, _ = cv2.threshold(b8, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        mask[sl] = b8 > t
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    cand = []
    for i in range(1, n):
        x, y, w, h, a = stats[i]
        fill, aspect = a / float(w * h), h / float(w)
        if (a > 5000 and fill > 0.85 and 1.15 < aspect < 1.8          # solid, upright rectangle
                and x > 0 and y > 0 and x + w < W and y + h < H):      # not cut by the image edge
            cand.append((i, x, y, w, h))
    if not cand:
        raise RuntimeError("no perforations found (are they along the top/bottom edge?)")
    mw, mh = np.median([c[3] for c in cand]), np.median([c[4] for c in cand])
    comps = [c for c in cand if 0.8 < c[3] / mw < 1.25 and 0.8 < c[4] / mh < 1.25]
    if len(comps) < MIN_HOLES:
        raise RuntimeError(f"only {len(comps)} perforations found (need at least {MIN_HOLES})")
    return comps


def hole_colour(lin, c):
    """median linear RGB of the central part of one perforation (stays clear of its soft edges)"""
    _, x, y, w, h = c
    return np.median(lin[y + h // 4: y + 3 * h // 4, x + w // 4: x + 3 * w // 4].reshape(-1, 3), axis=0)


def rebate_base(lin_wb, comps, H):
    """film-base colour: the strip between two NEIGHBOURING holes of the same row"""
    samples = []
    for is_top in (True, False):
        row = sorted([c for c in comps if (c[2] < H / 2) == is_top], key=lambda t: t[1])
        if len(row) < 2:
            continue
        pitch = np.median(np.diff([c[1] for c in row]))
        for a, b in zip(row[:-1], row[1:]):
            if not (0.8 * pitch < b[1] - a[1] < 1.25 * pitch):      # a hole is missing in between
                continue
            x0, x1 = a[1] + a[3] + 40, b[1] - 40
            yc = a[2] + a[4] // 2
            y0, y1 = yc - a[4] // 4, yc + a[4] // 4
            if x1 > x0:
                samples.append(np.median(lin_wb[y0:y1, x0:x1].reshape(-1, 3), axis=0))
    if not samples:
        raise RuntimeError("could not measure the film base between the perforations")
    return np.median(np.array(samples), axis=0)


# -------------------------------------------------- frame detection
def _peaks(g, lo, hi, n, sep):
    """strongest local maxima of g in [lo, hi), at least `sep` samples apart."""
    out = []
    for i in np.argsort(g[lo:hi])[::-1]:
        i += lo
        if all(abs(i - j) > sep for j, _ in out):
            out.append((int(i), float(g[i])))
        if len(out) == n:
            break
    return out


def _edge_profile(p, k=3):
    """edge strength of a (n,3) density profile: |p[i+k] - p[i-k]| summed over channels."""
    g = np.zeros(len(p), np.float32)
    g[k:-k] = np.abs(p[2 * k:] - p[:-2 * k]).sum(axis=1)
    return g


def detect_frame(D, comps, H, W, step=2):
    """Find the picture area between the two perforation rows.
    Frame edges are sharp density steps. Candidates are scored by edge strength and by
    whether the strip just OUTSIDE the edge looks like bare film base (D ~ 0 after base
    division); the left/right pair must also have a plausible 3:2 shape."""
    Ds = cv2.resize(D, (W // step, H // step), interpolation=cv2.INTER_AREA)
    dev = np.abs(Ds).max(axis=2)                     # 0 = bare film base
    h, w = dev.shape
    top = [c for c in comps if c[2] < H / 2]
    bot = [c for c in comps if c[2] >= H / 2]
    if not top or not bot:
        return None
    ya = int(np.median([c[2] + c[4] for c in top])) // step      # bottom edge of top perforations
    yb = int(np.median([c[2] for c in bot])) // step             # top edge of bottom perforations
    band = yb - ya
    if band < h * 0.3:
        return None
    m = 6                                                        # stay clear of the perforation edges

    # ---- rows (top / bottom edge), profile over the central 40 % of the width
    xs0, xs1 = int(w * 0.3), int(w * 0.7)
    gy = _edge_profile(Ds[:, xs0:xs1].mean(axis=1))
    win = int(band * 0.22)

    def row_score(e, outer_dir):
        a, b = (e - 20, e - 4) if outer_dir < 0 else (e + 4, e + 20)
        a, b = max(a, ya + 2), min(b, yb - 2)
        d = dev[a:b, xs0:xs1].mean() if b > a else 1.0
        return gy[e] - d

    tops = _peaks(gy, ya + m, ya + win, 6, 6)
    bots = _peaks(gy, yb - win, yb - m, 6, 6)
    if not tops or not bots:
        return None
    y0 = max(tops, key=lambda t: row_score(t[0], -1))[0]
    y1 = max(bots, key=lambda t: row_score(t[0], +1))[0]
    fh = y1 - y0
    if fh < h * 0.25:
        return None

    # ---- columns (left / right edge) inside the frame rows
    r0, r1 = y0 + fh // 4, y1 - fh // 4
    gx = _edge_profile(Ds[r0:r1].mean(axis=0))
    cand = _peaks(gx, 4, w - 4, 40, 8)
    gapw = int(0.02 * w)

    # A 35 mm frame is 36 mm wide and the perforation pitch is 4.75 mm -> width = 7.58 x pitch.
    # (Measured on real scans: 7.50 .. 7.62.) This stops the neighbouring frame's edge from being
    # mistaken for this frame's edge: that gives ~8.0 x pitch.
    pitches = []
    for grp in (top, bot):
        xs = sorted(c[1] for c in grp)
        d = np.diff(xs)
        if len(d):
            pitches += [v for v in d if 0.8 * np.median(d) < v < 1.25 * np.median(d)]
    exp_w = 7.58 * np.median(pitches) / step if pitches else None

    def outer_dev(x, side):
        a, b = (x - 2 * gapw, x - gapw // 2) if side < 0 else (x + gapw // 2, x + 2 * gapw)
        a, b = max(a, 0), min(b, w)
        return dev[r0:r1, a:b].mean() if b - a > 10 else 0.5

    # The outer boundary of a frame always borders the bare-film gap between two frames (about 2 mm),
    # so the strip just outside a true frame edge looks like film base. A neighbouring frame's edge
    # has picture content outside it -> rejected. This is a hard condition, not a score: a true edge
    # can be very weak (dark picture content next to the gap) while the neighbour's edge is strong.
    CLEAN = 0.6

    def pairs(max_outer):
        best = None
        for xl, gl in cand:
            ol = outer_dev(xl, -1)
            if ol > max_outer:
                continue
            for xr, gr in cand:
                ratio = (xr - xl) / fh
                if xr <= xl or not (1.38 <= ratio <= 1.60) or not (xl < w / 2 < xr):
                    continue
                if exp_w is not None and abs((xr - xl) / exp_w - 1) > 0.03:   # +-3 % of expected width
                    continue
                orr = outer_dev(xr, +1)
                if orr > max_outer:
                    continue
                score = gl + gr - (ol + orr) - 0.1 * ratio
                if best is None or score > best[0]:
                    best = (score, xl, xr, ratio, "")
        return best

    def inferred():
        """only one edge is visible: take the other one from the expected frame width"""
        if exp_w is None:
            return None
        best = None
        for x, g in cand:
            for side in (-1, +1):                       # x is the left (-1) or the right (+1) edge
                if outer_dev(x, side) > CLEAN:
                    continue
                xl, xr = (x, int(round(x + exp_w))) if side < 0 else (int(round(x - exp_w)), x)
                if xl < 4 or xr > w - 4 or not (xl < w / 2 < xr):
                    continue
                other = outer_dev(xr if side < 0 else xl, +1 if side < 0 else -1)
                if other > CLEAN:
                    continue
                score = g - outer_dev(x, side) - other
                if best is None or score > best[0]:
                    best = (score, xl, xr, (xr - xl) / fh, " (one edge inferred from the perforation pitch)")
        return best

    best = pairs(CLEAN) or inferred() or pairs(9.0)       # last resort: old behaviour
    if best is None:
        return None
    _, xl, xr, ratio, note = best
    print(f"  frame aspect {ratio:.2f}{note}")
    return (xl * step, y0 * step, xr * step, y1 * step)


# ----------------------------------------------------------- main job
def _light_and_density(path):
    """steps 1-3: read the scan, white balance on the perforations (bare light source), divide by the film base
    (removes the orange mask), convert to density. Returns the pieces process() and analyze() need."""
    global CS, NOISE_LIN
    raw_warn = None
    if is_raw(path):
        bgr, cs, how, raw_warn = read_raw(path)
        print(f"  camera RAW decoded: {how}")
    else:
        bgr = read_image(path)
        cs = detect_colourspace(path, bgr.dtype)
    CS = cs
    if not cs.is_srgb:
        print(f"  input colour space: {cs.name} (converted to sRGB at the end)")
    maxv = {np.dtype(np.uint8): 255.0, np.dtype(np.uint16): 65535.0}.get(bgr.dtype, 1.0)     # float: 1.0 = full scale
    H, W = bgr.shape[:2]
    rgb = bgr[..., ::-1].astype(np.float32) / maxv
    # zeros mean "below 1 LSB", not infinite density -> floor at half an LSB (float: half a 16-bit LSB)
    lin = cs.decode(np.maximum(rgb, 0.5 / (maxv if maxv > 1.0 else 65535.0))).astype(np.float32)
    if cs.is_linear:                      # linear light: look at it through a display-like curve to find the holes
        ref = max(float(np.percentile(rgb[::16, ::16], 99.9)), 1e-4)       # (the light source = brightest thing)
        gray = cv2.cvtColor(np.power(np.clip(rgb / ref, 0, 1), np.float32(1 / 2.2)), cv2.COLOR_RGB2GRAY)
        NOISE_LIN = estimate_blue_noise(rgb[..., 2], maxv)
        print(f"  blue noise floor (measured): {NOISE_LIN:.5f} of full scale")
    else:
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        NOISE_LIN = None

    global LAST_LIGHT, LAST_LIGHT_CS
    problems = []                         # things the user should look at; printed + summarised
    if raw_warn:
        problems.append(raw_warn)
        print("  WARNING:", raw_warn)

    # --- 1+2. light source (perforations) and film base (rebate between the perforations)
    try:
        comps = find_perforations(gray, H, W)
        perf = np.median(np.array([hole_colour(lin, c) for c in comps]), axis=0)
        if not np.all(np.isfinite(perf)) or perf.min() <= 0:
            raise RuntimeError("perforation colour could not be measured")
        lin_wb = lin / perf.astype(np.float32)    # perforation -> (1,1,1): neutral, = clear light
        base = rebate_base(lin_wb, comps, H)
        if not np.all(np.isfinite(base)) or base.min() <= 0:
            raise RuntimeError("film base colour could not be measured")
        LAST_LIGHT, LAST_LIGHT_CS = (perf, base, comps), cs.name
        print(f"  perforations used: {len(comps)}   WB gain: {perf.max() / perf}")
    except RuntimeError as e:
        if LAST_LIGHT is None or LAST_LIGHT_CS != cs.name:
            raise RuntimeError(f"{e}; no earlier frame in this run to borrow the white balance from")
        perf, base, comps = LAST_LIGHT        # light and film base are the same for the whole roll
        lin_wb = lin / perf.astype(np.float32)
        problems.append(f"{e} -> white balance / film base borrowed from the previous good frame")
        print("  WARNING:", problems[-1])

    # --- 3. transmittance -> density (float32, in place: full frames are big)
    del lin, rgb, gray
    D = lin_wb
    D /= base.astype(np.float32)
    np.clip(D, 1e-3, 8.0, out=D)
    np.log10(D, out=D)
    np.negative(D, out=D)
    if not np.isfinite(D[::16, ::16]).all():
        raise RuntimeError("density contains NaN/inf - nothing written (would be a black image)")
    return bgr, maxv, H, W, D, comps, perf, base, problems


def _frame_box(D, comps, H, W, manual_box, problems):
    """step 4: the picture area"""
    if manual_box is not None:
        box = tuple(manual_box)
        print("  frame box (manual):", box)
    else:
        box = detect_frame(D, comps, H, W)
        if box is not None:
            print("  frame box (auto):  ", box)
        else:
            box = (int(W * 0.134), int(H * 0.1215), int(W * 0.872), int(H * 0.878))
            problems.append("frame detection failed, default proportions used (check with --check)")
            print("  WARNING:", problems[-1])
    fx0, fy0, fx1, fy1 = box
    if not (0 <= fx0 < fx1 <= W and 0 <= fy0 < fy1 <= H) or fx1 - fx0 < 400 or fy1 - fy0 < 400:
        raise RuntimeError(f"frame box {box} is not inside the image - use --box x0 y0 x1 y1")
    return box


def process(path, outdir=None, manual_box=None, check=False, name=None):
    global LAST_STATS
    LAST_STATS = {}
    print(f"\n== {path}")
    bgr, maxv, H, W, D, comps, perf, base, problems = _light_and_density(path)
    box = _frame_box(D, comps, H, W, manual_box, problems)
    fx0, fy0, fx1, fy1 = box

    # --- 4b. blue-channel reconstruction (see the long comment above blue_samples). Only done when a noticeable
    # part of the frame has lost its blue; the film model comes from prepare_roll() (all frames of the film)
    # or, when the file is converted on its own, from this frame alone.
    blue_fixed, model, frac_blue = False, None, 0.0
    if FIX_BLUE:
        rawB = bgr[..., 0]
        frac_blue = float((rawB[fy0:fy1:4, fx0:fx1:4] < blue_levels(maxv)[0]).mean())
        if frac_blue > BLUE_MIN_FRAC:
            model = ROLL.get(os.path.abspath(path))
            src = f"{model['n']} frame(s) of this film" if model is not None else "this frame only"
            if model is None:
                model = fit_blue_group([blue_samples(D, rawB, box, float(perf[2]), float(base[2]), maxv)])
            apply_blue_model(D, rawB, model, float(perf[2]), float(base[2]), maxv)
            blue_fixed = True
            print(f"  note: blue lost in {100 * frac_blue:.0f}% of the frame (too dense for the exposure) -> "
                  f"reconstructed, blue/green slope {model['kappa']:.2f} from {src}")
            if frac_blue > 0.25:
                problems.append(f"blue lost in {100 * frac_blue:.0f}% of the frame: the colour of those areas is "
                                "estimated, not measured. For true colour: scan ~2-3 stops brighter for blue "
                                "(bracket so red/green do not clip) and develop the RAW to a wide gamut / "
                                "without black clipping")
                print("  WARNING:", problems[-1])

    # --- 5. per-channel levels inside the frame (subsampled, ignoring clipped pixels)
    inset = 30
    inner = D[fy0 + inset: fy1 - inset: 3, fx0 + inset: fx1 - inset: 3].reshape(-1, 3)
    raw_inner = bgr[fy0 + inset: fy1 - inset: 3, fx0 + inset: fx1 - inset: 3, ::-1].reshape(-1, 3)
    lo, hi = np.zeros(3), np.zeros(3)
    for c in range(3):
        v = inner[:, c] if (blue_fixed and c == 2) else inner[raw_inner[:, c] > 0, c]
        if v.size < 500:                  # channel (almost) completely clipped -> use every pixel
            v = inner[:, c]
        if v.size == 0:
            raise RuntimeError("no pixels inside the frame box")
        lo[c], hi[c] = np.percentile(v, [LOW_PCT, HIGH_PCT])
    if not np.all(np.isfinite(hi - lo)) or (hi - lo).min() < MIN_SPAN:
        raise RuntimeError(f"no usable tonal range inside the frame ({np.round(hi - lo, 3)}): "
                           "blank frame, or the frame box is wrong - nothing written")
    if blue_fixed:
        # the brightest blue values are the ones that were lost, so blue's white point comes from the film's
        # neutral axis (blue follows green with slope kappa) instead of from the reconstructed extremes
        f = min(1.0, frac_blue / 0.2)
        hi[2] = (1 - f) * hi[2] + f * (lo[2] + model["kappa"] * (hi[1] - lo[1]))
    span = hi - lo
    drange = float(span[1]) if blue_fixed else float(np.mean(span))   # tone shape from green: the reliable channel
    Lmin = 10 ** (-drange / GAMMA_NEG)
    kexp = drange / GAMMA_NEG
    lo32, span32 = lo.astype(np.float32), span.astype(np.float32)
    gains = np.array([1.0, 2.0 ** TINT, 2.0 ** BLUE_SHIFT], np.float32)    # user colour shift, in stops (R, G, B)

    M = None if CS.to_srgb is None else CS.to_srgb.T.astype(np.float32)     # input primaries -> sRGB primaries

    def scene_linear(Dx):                 # levels -> scene-linear sRGB light (0 = black, 1 = white point)
        xx = np.clip((Dx - lo32) / span32, 0, 1)      # 0 = shadow, 1 = highlight
        L = np.power(np.float32(10.0), (xx - 1.0) * np.float32(kexp))
        L = (L - Lmin) / (1 - Lmin) * gains
        return L if M is None else np.maximum(L @ M, 0)

    # --- 5b. exposure: a dense/dark frame is lifted so its median lands near mid-grey (never darkened),
    # highlights roll off smoothly (extended Reinhard: white stays white, no clipping of the brightened picture)
    gain = 2.0 ** EXPOSURE
    if AUTO_EXPOSURE:
        Ls = scene_linear(inner)
        Y = 0.2126 * Ls[:, 0] + 0.7152 * Ls[:, 1] + 0.0722 * Ls[:, 2]
        gain *= float(np.clip((TARGET_MID / max(float(np.median(Y)), 1e-4)) ** 0.65, 1.0, 6.0))
        del Ls, Y
    print(f"  exposure: {np.log2(gain):+.1f} stops" + (" (auto)" if AUTO_EXPOSURE else ""))
    LAST_STATS = dict(bits={255.0: 8, 65535.0: 16}.get(float(maxv), 32), space=CS.name, srgb=CS.is_srgb, blue_lost=frac_blue, blue_fixed=blue_fixed,
                      exposure=float(np.log2(gain)), noise=NOISE_LIN)

    # --- 6. levels -> scene-linear -> exposure -> tone curve -> sRGB, in row chunks
    out8 = np.empty((H, W, 3), np.uint8)
    out16 = np.empty((H, W, 3), np.uint16) if maxv != 255.0 else None
    for r in range(0, H, 400):
        L = scene_linear(D[r:r + 400]) * np.float32(gain)
        if gain > 1.0:
            L = L * (1 + L / np.float32(gain * gain)) / (1 + L)
        o = lin_to_srgb(L).astype(np.float32)
        if S_CURVE > 0:
            o = (1 - S_CURVE) * o + S_CURVE * (o * o * (3 - 2 * o))
        if HILITE != 0.0:
            o = o + np.float32(HILITE) * o * o
        if TONE:
            o = tone_shape(o, TONE).astype(np.float32, copy=False)
        if SAT != 1.0:
            g = o.mean(axis=2, keepdims=True)
            o = g + (o - g) * SAT
        o = np.clip(o, 0, 1)[..., ::-1]                          # RGB -> BGR for cv2
        out8[r:r + 400] = (o * 255 + 0.5).astype(np.uint8)
        if out16 is not None:
            out16[r:r + 400] = (o * 65535 + 0.5).astype(np.uint16)
    del D, bgr
    if out16 is None:
        out8 = chroma_denoise(out8)

    # --- 7. save
    stem = name or os.path.splitext(os.path.basename(path))[0]        # name: used by the Lightroom plug-in (temp file names are not the photo's)
    folder = outdir or os.path.dirname(os.path.abspath(path))
    os.makedirs(folder, exist_ok=True)
    sl = (slice(fy0 + CROP_INSET, fy1 - CROP_INSET), slice(fx0 + CROP_INSET, fx1 - CROP_INSET))
    p_full = os.path.join(folder, f"{stem}_positive_full.jpg")
    p_crop = os.path.join(folder, f"{stem}_positive_crop.jpg")
    mean_level = float(out8[sl][::8, ::8].mean())
    if mean_level < 20:
        problems.append(f"result is very dark (average {mean_level:.0f} of 255) - check this frame")
        print("  WARNING:", problems[-1])
    write_image(p_full, out8)
    write_image(p_crop, np.ascontiguousarray(out8[sl]))
    saved = [p_crop, p_full]
    if out16 is not None:
        p16 = os.path.join(folder, f"{stem}_positive_crop_16bit.tif")
        write_image(p16, np.ascontiguousarray(out16[sl]))
        saved.append(p16)
    if check:
        prev = cv2.resize(out8, None, fx=0.25, fy=0.25, interpolation=cv2.INTER_AREA)
        cv2.rectangle(prev, (fx0 // 4, fy0 // 4), (fx1 // 4, fy1 // 4), (0, 255, 0), 2)
        for _, x, y, w, h in comps:
            cv2.rectangle(prev, (x // 4, y // 4), ((x + w) // 4, (y + h) // 4), (255, 0, 255), 1)
        pc = os.path.join(folder, f"{stem}_check.jpg")
        write_image(pc, prev, 85)
        saved.append(pc)
    for s in saved:
        print("  saved:", s)
    del out8, out16
    gc.collect()
    return problems


def is_result(path):
    n = os.path.basename(path).lower()
    return "_positive_" in n or n.endswith("_check.jpg")


def expand(patterns):
    files = []
    for p in patterns:
        hits = sorted(glob.glob(p))
        files.extend(hits if hits else [p])
    keep = []
    for f in files:
        if is_result(f):
            print(f"skipped (looks like an output of this script): {f}")
        elif f not in keep:
            keep.append(f)
    return keep


# ======================================================================================================
# Lightroom "develop settings" mode (Negative-Lab-Pro style)
#   Lightroom hands over a SMALL neutral wide-gamut render of the RAW (the plug-in does this itself, nothing to export).
#   Everything the conversion does to a pixel is a function of that pixel's own channel (levels -> density curve ->
#   exposure roll-off -> S-curve), so it can be written as three point curves (R, G, B) for Lightroom's tone curve,
#   plus a crop for the frame. The RAW stays a RAW; nothing is rendered here.
#   Not expressible that way (and therefore absent in this mode): the blue-channel reconstruction (it uses the
#   other channels) and the saturation (approximated by Lightroom's own slider).
# ======================================================================================================
def _axis_funcs(name):
    """curve axis of Lightroom's tone curve (Melissa RGB = ProPhoto primaries with an sRGB tone curve) -> (to linear, from linear)"""
    if name == "srgb":
        return srgb_to_lin, lin_to_srgb
    g = {"g22": 2.2, "g18": 1.8, "g24": 2.4, "lin": 1.0}[name]
    return (lambda u: np.power(np.clip(u, 0, 1), g)), (lambda L: np.power(np.clip(L, 0, 1), 1.0 / g))


def lr_analyse(path, manual_box=None, inset_frac=0.005):
    """small neutral render from Lightroom -> everything the curves are built from (a dict that can be saved)."""
    global INPUT_SPACE
    bgr, maxv, H, W, D, comps, perf, base, problems = _light_and_density(path)
    box = _frame_box(D, comps, H, W, manual_box, problems)
    fx0, fy0, fx1, fy1 = box
    inset = max(4, int(round(0.005 * W)))
    inner = D[fy0 + inset: fy1 - inset: 2, fx0 + inset: fx1 - inset: 2].reshape(-1, 3)
    raw_inner = bgr[fy0 + inset: fy1 - inset: 2, fx0 + inset: fx1 - inset: 2, ::-1].reshape(-1, 3)
    lo, hi = np.zeros(3), np.zeros(3)
    for c in range(3):
        v = inner[raw_inner[:, c] > 0, c]
        if v.size < 500:
            v = inner[:, c]
        if v.size == 0:
            raise RuntimeError("no pixels inside the frame box")
        lo[c], hi[c] = np.percentile(v, [LOW_PCT, HIGH_PCT])
    if not np.all(np.isfinite(hi - lo)) or (hi - lo).min() < MIN_SPAN:
        raise RuntimeError(f"no usable tonal range inside the frame ({np.round(hi - lo, 3)})")
    if len(inner) > 40000:
        inner = inner[_even_subset(len(inner), 40000)]
    zeros = float((raw_inner[::7, 2] <= 0.5 / 65535).mean())
    sc = 640.0 / max(H, W)                                        # small copy of the whole render (density) for the plug-in's preview
    prevD = cv2.resize(D, (max(1, int(round(W * sc))), max(1, int(round(H * sc)))), interpolation=cv2.INTER_AREA) if sc < 1.0 else D
    sc2 = 1600.0 / max(H, W)                                      # larger copy for the enlarged view (more detail)
    prevDbig = cv2.resize(D, (max(1, int(round(W * sc2))), max(1, int(round(H * sc2)))), interpolation=cv2.INTER_AREA) if sc2 < 1.0 else D
    return dict(perf=np.asarray(perf, np.float64), base=np.asarray(base, np.float64), lo=lo, hi=hi, prevD=np.asarray(prevD, np.float16),
                prevDbig=np.asarray(prevDbig, np.float16),
                inner=inner.astype(np.float32), to_srgb=(np.eye(3) if CS.to_srgb is None else np.asarray(CS.to_srgb, np.float64)),
                box=np.array([fx0 / W, fy0 / H, fx1 / W, fy1 / H]), size=np.array([W, H]), inset_frac=float(inset_frac),
                blue_zero=zeros, space=np.array(CS.name), problems=np.array(problems, dtype=str))


def _spline_eval(xk, yk, xq, kind):
    """interpolators Lightroom might use between the control points: 'linear' | 'cubic' (natural spline) | 'pchip'-like"""
    xk, yk = np.asarray(xk, float), np.asarray(yk, float)
    if kind == "linear" or len(xk) < 3:
        return np.interp(xq, xk, yk)
    n = len(xk)
    h = np.diff(xk)
    if kind == "pchip":                    # monotone-preserving cubic (Fritsch-Carlson)
        d = np.diff(yk) / h
        m = np.zeros(n)
        for i in range(1, n - 1):
            m[i] = 0.0 if d[i - 1] * d[i] <= 0 else 2 * d[i - 1] * d[i] / (d[i - 1] + d[i])
        m[0], m[-1] = d[0], d[-1]
        i = np.clip(np.searchsorted(xk, xq, side="right") - 1, 0, n - 2)
        t = (xq - xk[i]) / h[i]
        h00, h10, h01, h11 = 2 * t**3 - 3 * t**2 + 1, t**3 - 2 * t**2 + t, -2 * t**3 + 3 * t**2, t**3 - t**2
        return h00 * yk[i] + h10 * h[i] * m[i] + h01 * yk[i + 1] + h11 * h[i] * m[i + 1]
    A = np.zeros((n, n)); r = np.zeros(n)                       # natural cubic spline
    A[0, 0] = A[-1, -1] = 1.0
    for i in range(1, n - 1):
        A[i, i - 1], A[i, i], A[i, i + 1] = h[i - 1], 2 * (h[i - 1] + h[i]), h[i]
        r[i] = 3 * ((yk[i + 1] - yk[i]) / h[i] - (yk[i] - yk[i - 1]) / h[i - 1])
    cc = np.linalg.solve(A, r)
    bb = np.diff(yk) / h - h * (2 * cc[:-1] + cc[1:]) / 3
    dd = np.diff(cc) / (3 * h)
    i = np.clip(np.searchsorted(xk, xq, side="right") - 1, 0, n - 2)
    dx = xq - xk[i]
    return yk[i] + bb[i] * dx + cc[i] * dx**2 + dd[i] * dx**3


def _pick_points(yfun, tol=1.0, max_pts=48, used=None):
    """control points (integer x on the 0..255 axis) so that linear AND cubic interpolation both stay within tol levels
    wherever the picture has pixels (used: boolean mask over xs, see lr_curves)"""
    xs = np.arange(0, 255.01, 0.25)
    yt = yfun(xs / 255.0)
    nodes = [0, 255]
    err = 0.0
    while True:
        xk = np.array(sorted(nodes), float)
        yk = np.round(yfun(xk / 255.0))                       # Lightroom stores whole numbers
        e = np.maximum(np.abs(np.clip(_spline_eval(xk, yk, xs, "linear"), 0, 255) - yt),
                       np.abs(np.clip(_spline_eval(xk, yk, xs, "cubic"), 0, 255) - yt))      # Lightroom clips the result to 0..255
        if used is not None:
            e = np.where(used, e, 0.0)
        err = float(e.max())
        if err <= tol or len(nodes) >= max_pts:
            break
        cand = int(round(xs[int(np.argmax(e))]))
        if cand in nodes:                                    # already a node: the error is rounding; take the next worst
            e2 = e.copy()
            for n_ in nodes:
                e2[np.abs(xs - n_) < 0.5] = -1
            cand = int(round(xs[int(np.argmax(e2))]))
            if cand in nodes:
                break
        nodes.append(cand)
    pts = []
    for x, y in zip(xk, yk):
        pts += [int(x), int(np.clip(y, 0, 255))]
    return pts, err


def lr_curves(cache, gamma=None, scurve=None, exposure=None, blue=None, tint=None, autoexp=None, axis="srgb", tol=1.0, hilite=None, tone=None, border=None, wclip=0.0, bclip=0.0):
    """the three point curves (lists x0,y0,x1,y1,... on 0..255) + info, from an analysis (lr_analyse) and the look parameters"""
    gamma = GAMMA_NEG if gamma is None else gamma
    scurve = S_CURVE if scurve is None else scurve
    hilite = HILITE if hilite is None else hilite
    tone = TONE if tone is None else tone
    exposure = EXPOSURE if exposure is None else exposure
    blue = BLUE_SHIFT if blue is None else blue
    tint = TINT if tint is None else tint
    autoexp = AUTO_EXPOSURE if autoexp is None else autoexp
    to_lin, from_lin = _axis_funcs(axis)
    perf, base, lo, hi = cache["perf"], cache["base"], np.array(cache["lo"], np.float64), np.array(cache["hi"], np.float64)
    if wclip or bclip:                      # clip more (or less) of the white / black ends than the analysis did, in % of the pixels
        inn = np.asarray(cache["inner"], np.float64)
        for c in range(3):
            p0 = np.percentile(inn[:, c], [LOW_PCT, HIGH_PCT])
            p1 = np.percentile(inn[:, c], [float(np.clip(LOW_PCT + bclip, 0, 45)), float(np.clip(HIGH_PCT - wclip, 55, 100))])
            lo[c] += p1[0] - p0[0]
            hi[c] += p1[1] - p0[1]
        if not np.all(np.isfinite(hi - lo)) or (hi - lo).min() < MIN_SPAN:
            raise RuntimeError("the white / black clip values leave no tonal range")
    span = hi - lo
    drange = float(np.mean(span))
    Lmin = 10 ** (-drange / gamma)
    kexp = drange / gamma
    gains = np.array([1.0, 2.0 ** tint, 2.0 ** blue])
    M = np.asarray(cache["to_srgb"], np.float64).T

    def density(Lin, c):                      # same as _light_and_density: white balance, film base, -log10, clip
        T = np.clip(Lin / perf[c] / base[c], 1e-3, 8.0)
        return -np.log10(T)

    def scene(Lin_rgb):                       # (n,3) linear light of the render -> scene-linear light, before exposure
        out = np.empty_like(Lin_rgb)
        for c in range(3):
            xx = np.clip((density(Lin_rgb[:, c], c) - lo[c]) / span[c], 0, 1)
            out[:, c] = (10.0 ** ((xx - 1.0) * kexp) - Lmin) / (1 - Lmin) * gains[c]
        return out

    gain = 2.0 ** exposure
    if autoexp:
        # median luminance of the frame, in sRGB primaries like process(): inner holds densities, so go back to light
        Dn = cache["inner"].astype(np.float64)
        xx = np.clip((Dn - lo) / span, 0, 1)
        Ls = ((10.0 ** ((xx - 1.0) * kexp) - Lmin) / (1 - Lmin) * gains) @ M
        Ls = np.maximum(Ls, 0)
        Y = 0.2126 * Ls[:, 0] + 0.7152 * Ls[:, 1] + 0.0722 * Ls[:, 2]
        gain *= float(np.clip((TARGET_MID / max(float(np.median(Y)), 1e-4)) ** 0.65, 1.0, 6.0))

    def finish(L, c=None):                    # exposure roll-off, tone curve, S-curve, highlights, tone shaping -> 0..1 on the curve axis
        L = L * gain
        if gain > 1.0:
            L = L * (1 + L / (gain * gain)) / (1 + L)
        o = from_lin(L)
        if scurve > 0:
            o = (1 - scurve) * o + scurve * (o * o * (3 - 2 * o))
        if hilite != 0.0:
            o = o + hilite * o * o
        if tone:
            o = tone_shape(o, tone, c)
        return np.clip(o, 0, 1)

    curves, errs = {}, []
    xs_grid = np.arange(0, 255.01, 0.25)
    Dn_all = cache["inner"].astype(np.float64)
    for c, key in enumerate("RGB"):
        # where on the curve axis does this channel have pixels? (not the clipped ones: D >= 3 is "lost")
        ok = Dn_all[:, c] < 2.99
        Lin_s = np.power(10.0, -Dn_all[ok, c]) * perf[c] * base[c]
        u_s = from_lin(np.clip(Lin_s, 0, 1)) * 255.0
        cnt, _ = np.histogram(u_s, bins=np.arange(-0.125, 255.5, 0.25))
        used = np.convolve(cnt >= max(3, 0.0002 * len(u_s)), np.ones(5, bool), mode="same")[:len(xs_grid)]

        def yfun(uu, c=c):
            Lin = to_lin(np.asarray(uu, float))
            z = np.zeros((len(Lin), 3)); z[:, c] = Lin
            xx = np.clip((density(Lin, c) - lo[c]) / span[c], 0, 1)
            Ls = (10.0 ** ((xx - 1.0) * kexp) - Lmin) / (1 - Lmin) * gains[c]
            return finish(Ls, c) * 255.0
        pts, e = _pick_points(yfun, tol, used=used)
        curves[key] = pts
        errs.append(e)
    fx0, fy0, fx1, fy1 = [float(v) for v in cache["box"]]
    W, H = [float(v) for v in cache["size"]]
    ins = float(cache["inset_frac"]) if border is None else max(0.0, float(border)) / 100.0
    crop = (fx0 + ins, fy0 + ins * W / H, fx1 - ins, fy1 - ins * W / H)           # left, top, right, bottom (0..1)
    return dict(curves=curves, crop=crop, gain_stops=float(np.log2(gain)), fit_error=max(errs), points=[len(curves[k]) // 2 for k in "RGB"])


def lr_simulate(rgb_render_lin, curves, axis="srgb", kind="cubic"):
    """what Lightroom does with the curves: linear light of the render -> curve axis -> point curve -> linear light.
    rgb_render_lin: (...,3) linear light in the render's primaries. Returns linear light in the same primaries."""
    to_lin, from_lin = _axis_funcs(axis)
    out = np.empty_like(rgb_render_lin, dtype=np.float64)
    for c, key in enumerate("RGB"):
        pts = np.array(curves[key], float).reshape(-1, 2)
        u = from_lin(np.clip(rgb_render_lin[..., c], 0, 1)) * 255.0
        y = np.clip(_spline_eval(pts[:, 0], pts[:, 1], u.ravel(), kind), 0, 255).reshape(u.shape) / 255.0
        out[..., c] = to_lin(y)
    return out


def lr_identify(render0_lin, render1_lin, curves, subsample=7):
    """Lightroom's real result (render1) vs what each assumption about its tone-curve axis / interpolation predicts.
    Returns (best_axis, best_kind, {(axis, kind): mean abs error in 8-bit levels of the curve axis})."""
    a = render0_lin[::subsample, ::subsample].reshape(-1, 3)
    b = render1_lin[::subsample, ::subsample].reshape(-1, 3)
    table = {}
    for axis in ("srgb", "g22", "g18", "g24", "lin"):
        _, from_lin = _axis_funcs(axis)
        for kind in ("cubic", "linear", "pchip"):
            sim = lr_simulate(a, curves, axis, kind)
            table[(axis, kind)] = float(np.mean(np.abs(from_lin(np.clip(sim, 0, 1)) - from_lin(np.clip(b, 0, 1)))) * 255.0)
    best = min(table, key=table.get)
    return best[0], best[1], table


def _canvas_page(img, canvas, rot=0):
    """uint8 BGR picture -> turned clockwise by rot (0 / 90 / 180 / 270 degrees) -> letter-boxed into a canvas."""
    k90 = (int(round(rot / 90.0)) % 4)
    if k90:
        img = np.ascontiguousarray(np.rot90(img, k=-k90))          # np.rot90 turns counter-clockwise for positive k
    cw, ch = canvas
    h, w = img.shape[:2]
    k = min(cw / w, ch / h)
    nw, nh = max(1, int(round(w * k))), max(1, int(round(h * k)))
    img = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_AREA if k < 1 else cv2.INTER_LINEAR)
    page = np.full((ch, cw, 3), 38, np.uint8)
    x, y = (cw - nw) // 2, (ch - nh) // 2
    page[y:y + nh, x:x + nw] = img
    return page


def view_image(src, canvas=(520, 340), rot=0):
    """any picture file (e.g. Lightroom's own render) turned and letter-boxed the same way as the panel's preview. uint8 BGR page."""
    img = read_image(src)
    if img.dtype != np.uint8:
        mx = 65535.0 if img.dtype == np.uint16 else 1.0
        img = (np.clip(img.astype(np.float32) / mx, 0, 1) * 255 + 0.5).astype(np.uint8)
    return _canvas_page(img, canvas, rot)


def lr_preview(cache, res, axis="srgb", kind="cubic", sat=1.0, use_crop=True, canvas=(520, 340), rot=0):
    """what the picture will look like once Lightroom applies the curves: the kept small render -> curves (as Lightroom
    evaluates them) -> sRGB for the screen, cropped to the frame, letter-boxed into a canvas. Returns uint8 BGR."""
    if "prevD" not in cache:
        raise RuntimeError("this analysis has no preview data (made by an older version) - convert the photo again")
    # the enlarged view takes the larger copy of the render (when this analysis has one), small canvases the small copy (faster)
    Dm = np.asarray(cache["prevDbig"] if (max(canvas) > 700 and "prevDbig" in cache) else cache["prevD"], np.float32)
    Lin = np.power(10.0, -Dm.astype(np.float64)) * (np.asarray(cache["perf"], np.float64) * np.asarray(cache["base"], np.float64))
    out = lr_simulate(Lin, res["curves"], axis, kind)
    M = np.asarray(cache["to_srgb"], np.float64).T
    o = lin_to_srgb(np.clip(out @ M, 0, 1).astype(np.float32)).astype(np.float32)
    if abs(sat - 1.0) > 1e-3:
        g = o.mean(axis=2, keepdims=True)
        o = g + (o - g) * np.float32(sat)
    o = np.clip(o, 0, 1)
    h, w = o.shape[:2]
    if use_crop:
        l, t, r, b = res["crop"]
        x0, x1 = int(round(max(0.0, l) * w)), int(round(min(1.0, r) * w))
        y0, y1 = int(round(max(0.0, t) * h)), int(round(min(1.0, b) * h))
        if x1 - x0 >= 8 and y1 - y0 >= 8:
            o = o[y0:y1, x0:x1]
    img = (o[..., ::-1] * 255 + 0.5).astype(np.uint8)
    return _canvas_page(img, canvas, rot)


def _read_job(path):
    """job file written by the Lightroom plug-in: UTF-8, one 'key=value' per line (paths may contain anything but
    line breaks), and  item=<input file><TAB><output folder><TAB><name for the outputs>  for every photo."""
    opts, items = {}, []
    with open(path, encoding="utf-8-sig") as f:
        for raw in f:
            line = raw.rstrip("\r\n")
            if not line.strip() or line.startswith("#"):
                continue
            key, _, val = line.partition("=")
            key = key.strip().lower()
            if key == "item":
                parts = val.split("\t")
                items.append((parts[0], parts[1] if len(parts) > 1 else "", parts[2] if len(parts) > 2 else ""))
            else:
                opts[key] = val.strip()
    return opts, items


def _clean(text):
    return " ".join(str(text).replace("\t", " ").split())


def run_job(job_path):
    """python neg_convert.py --job job.txt : converts what the job file lists and writes a result file
    (one tab-separated line per photo: status, name, crop jpg, 16-bit tif, info, message). Used by the Lightroom plug-in."""
    global GAMMA_NEG, S_CURVE, SAT, HILITE, CROP_INSET, FIX_BLUE, AUTO_EXPOSURE, EXPOSURE, BLUE_SHIFT, TINT, INPUT_SPACE
    for stream in (sys.stdout, sys.stderr):                         # the log file is read as UTF-8 by the plug-in
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    opts, items = _read_job(job_path)

    def num(key, default, kind=float):
        try:
            return kind(opts[key]) if key in opts else default
        except ValueError:
            print(f"  WARNING: job option {key}={opts[key]!r} is not a number, using {default}")
            return default

    def flag(key, default):
        return opts[key].lower() in ("1", "true", "yes", "on") if key in opts else default

    GAMMA_NEG, S_CURVE, SAT = num("gamma", GAMMA_NEG), num("scurve", S_CURVE), num("sat", SAT)
    HILITE = num("hilite", HILITE)
    CROP_INSET, EXPOSURE, BLUE_SHIFT, TINT = num("inset", CROP_INSET, int), num("exposure", EXPOSURE), num("blue", BLUE_SHIFT), num("tint", TINT)
    FIX_BLUE, AUTO_EXPOSURE = flag("fixblue", True), flag("autoexp", True)
    INPUT_SPACE = opts.get("input", "auto") if opts.get("input", "auto") in ("auto", "srgb", "prophoto", "linear") else "auto"
    result_path = opts.get("result") or job_path + ".result"
    check, roll = flag("check", False), flag("roll", True)
    print(f"job: {len(items)} photo(s); gamma {GAMMA_NEG} s-curve {S_CURVE} sat {SAT} exposure {EXPOSURE:+} blue {BLUE_SHIFT:+} "
          f"tint {TINT:+} fix-blue {FIX_BLUE} auto-exposure {AUTO_EXPOSURE} roll {roll}")
    files = [i[0] for i in items]
    if FIX_BLUE and roll and files:
        print("\n== analysing all photos first (film colour model)")
        prepare_roll(files)
    rows = []
    for n, (inp, outdir, name) in enumerate(items, 1):
        print(f"\n[{n}/{len(items)}]", end="")
        stem = name or os.path.splitext(os.path.basename(inp))[0]
        folder = outdir or os.path.dirname(os.path.abspath(inp))
        crop, t16 = os.path.join(folder, f"{stem}_positive_crop.jpg"), os.path.join(folder, f"{stem}_positive_crop_16bit.tif")
        try:
            problems = process(inp, outdir or None, None, check, name=name or None)
            st = dict(LAST_STATS)
            if st.get("bits") == 8:
                problems.append("the photo was exported with 8 bits - colour precision is low (use a 16-bit TIFF)")
            info = f"{st.get('space', '')}; exposure {st.get('exposure', 0):+.1f}" + ("; blue reconstructed" if st.get("blue_fixed") else "")
            rows.append(("warn" if problems else "ok", stem, crop, t16 if os.path.exists(t16) else "", info, "; ".join(problems)))
        except Exception as e:
            print(f"  ERROR: {e}")
            rows.append(("fail", stem, "", "", "", str(e)))
    with open(result_path, "w", encoding="utf-8", newline="\n") as f:
        for r in rows:
            f.write("\t".join(_clean(x) for x in r) + "\n")
    print("\n==== summary ====")
    print(f"converted: {sum(r[0] != 'fail' for r in rows)} / {len(rows)}; result list: {result_path}")


def _curve_text(pts):
    return ",".join(str(int(v)) for v in pts)


def run_lr_job(job_path):
    """python neg_convert.py --job job.txt  with  mode=fit | refit | identify   (Lightroom develop-settings mode).
    fit      item=<neutral render><TAB><id>         analyse the render, keep the analysis in cachedir, answer with curves + crop
    refit    item=<id>                              same look parameters changed: curves from the kept analysis (no image needed)
    identify item=<render before><TAB><render after><TAB><id>
                                                    which tone-curve axis / interpolation did Lightroom really use? (compares
                                                    the render made after the curves were applied with what each assumption predicts)
    view     item=<picture><TAB><out jpg>          turn the picture (rot=0|90|180|270 clockwise) and fit it into pw x ph
    (mode=preview is the same as refit.) With  out=<jpg>  fit/refit also write a preview picture of the result
    (pw= ph= canvas size, rot= turn, autocrop=0|1, kind=cubic|linear|pchip, sat=): used by the plug-in's panel.
    result file, one tab-separated line per item:
       fit/refit : id, ok|fail, message, left,top,right,bottom, R curve, G curve, B curve, info [, preview path]
       identify  : id, ok|fail, message, axis, interpolation, error with that, error with the default (sRGB axis, cubic)"""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    opts, items = _read_job(job_path)
    mode = opts.get("mode", "fit")
    cachedir = opts.get("cachedir") or os.path.dirname(os.path.abspath(job_path))
    os.makedirs(cachedir, exist_ok=True)
    result_path = opts.get("result") or job_path + ".result"

    def fnum(key, default):
        try:
            return float(opts[key]) if key in opts else default
        except ValueError:
            return default

    if opts.get("mode") == "preview":
        opts["mode"] = mode = "refit"
    kind = opts.get("kind", "cubic") if opts.get("kind", "cubic") in ("cubic", "linear", "pchip") else "cubic"
    out_path = opts.get("out", "")
    canvas = (int(fnum("pw", 520)), int(fnum("ph", 340)))
    rot = int(fnum("rot", 0))
    use_crop = opts.get("autocrop", "1").lower() in ("1", "true", "yes", "on")
    tone = dict(TONE_DEFAULTS)
    for key in ("bright", "lights", "darks", "whites", "blacks", "fade", "softhi", "softlo", "hirange", "shrange"):
        tone[key] = fnum(key, TONE_DEFAULTS[key])
    for key, short in (("md", "md"), ("hi", "hi"), ("sh", "sh")):
        tone[key] = tuple(fnum(short + ch, 0.0) for ch in "rgb")
    look = dict(gamma=fnum("gamma", GAMMA_NEG), scurve=fnum("scurve", S_CURVE), hilite=fnum("hilite", HILITE), exposure=fnum("exposure", EXPOSURE),
                tone=(None if tone_is_neutral(tone) else tone), wclip=fnum("wclip", 0.0), bclip=fnum("bclip", 0.0),
                border=(fnum("border", -1.0) if "border" in opts else None),
                blue=fnum("blue", BLUE_SHIFT), tint=fnum("tint", TINT),
                autoexp=opts.get("autoexp", "1").lower() in ("1", "true", "yes", "on"), axis=opts.get("axis", "srgb"))
    if look["axis"] not in ("srgb", "g22", "g18", "g24", "lin"):
        look["axis"] = "srgb"
    global INPUT_SPACE
    INPUT_SPACE = opts.get("input", "auto") if opts.get("input", "auto") in ("auto", "srgb", "prophoto", "linear") else "auto"
    print(f"lightroom job: mode {mode}, {len(items)} item(s), look {look}")
    rows = []
    for n, it in enumerate(items, 1):
        try:
            if mode == "fit":
                path, pid = it[0], (it[1] if len(it) > 1 and it[1] else str(n))
                print(f"\n[{n}/{len(items)}] analysing {path}")
                cache = lr_analyse(path, inset_frac=fnum("inset", 0.0035))
                np.savez(os.path.join(cachedir, f"analysis_{pid}.npz"), **cache)
            elif mode == "refit":
                pid = it[0]
                cache = dict(np.load(os.path.join(cachedir, f"analysis_{pid}.npz"), allow_pickle=False))
            elif mode == "view":                                  # turn / letter-box a picture file: item=<in><TAB><out>
                write_image(it[1], view_image(it[0], canvas, rot))
                rows.append((it[1], "ok", "", it[1]))
                continue
            elif mode == "identify":
                p0, p1, pid = it[0], it[1], (it[2] if len(it) > 2 and it[2] else str(n))
                import json
                last = json.load(open(os.path.join(cachedir, f"last_{pid}.json")))
                lins = []
                for pp in (p0, p1):
                    bgr = read_image(pp)
                    mx = {np.dtype(np.uint8): 255.0, np.dtype(np.uint16): 65535.0}.get(bgr.dtype, 1.0)
                    cs = detect_colourspace(pp, bgr.dtype)
                    lins.append(cs.decode(np.maximum(bgr[..., ::-1].astype(np.float32) / mx, 0.0)).astype(np.float64))
                if lins[0].shape != lins[1].shape:
                    raise RuntimeError(f"the two renders differ in size {lins[0].shape} vs {lins[1].shape}")
                best_axis, best_kind, table = lr_identify(lins[0], lins[1], last["curves"])
                rows.append((pid, "ok", f"identified from {lins[0].shape[1]}x{lins[0].shape[0]} renders", best_axis, best_kind,
                             f"{table[(best_axis, best_kind)]:.3f}", f"{table[('srgb', 'cubic')]:.3f}"))
                print(f"  axis {best_axis}/{best_kind}: error {table[(best_axis, best_kind)]:.3f} (sRGB/cubic: {table[('srgb', 'cubic')]:.3f})")
                continue
            else:
                raise RuntimeError(f"unknown mode {mode!r}")
            res = lr_curves(cache, **look)
            import json
            json.dump(dict(curves=res["curves"], axis=look["axis"]), open(os.path.join(cachedir, f"last_{pid}.json"), "w"))
            notes = [str(x) for x in cache["problems"]]
            bz = float(cache["blue_zero"])
            if bz > 0.03:
                notes.append(f"blue is cut off in {bz * 100:.0f}% of the picture (Lightroom clipped it): use the file export (blue reconstruction) for this one")
            info = f"exposure {res['gain_stops']:+.1f}; fit error {res['fit_error']:.1f}; points {res['points']}; {cache['space']}"
            c = res["crop"]
            row = (pid, "ok", "; ".join(notes), ",".join(f"{v:.5f}" for v in c),
                   _curve_text(res["curves"]["R"]), _curve_text(res["curves"]["G"]), _curve_text(res["curves"]["B"]), info)
            if out_path:                                          # preview picture for the plug-in's panel
                page = lr_preview(cache, res, look["axis"], kind, fnum("sat", 1.0), use_crop, canvas, rot)
                write_image(out_path, page)
                row = row + (out_path,)
            rows.append(row)
            print(f"  curves {res['points']} points, exposure {res['gain_stops']:+.1f}, crop {tuple(round(v, 3) for v in c)}")
        except Exception as e:
            print(f"  ERROR: {e}")
            pid = it[1] if (mode == "fit" and len(it) > 1) else (it[2] if (mode == "identify" and len(it) > 2) else (it[0] if it else "?"))
            rows.append((pid, "fail", str(e)))
    with open(result_path, "w", encoding="utf-8", newline="\n") as f:
        for r in rows:
            f.write("\t".join(_clean(x) for x in r) + "\n")
    print(f"\nresult list: {result_path}")


def main():
    if len(sys.argv) >= 3 and sys.argv[1] == "--job":
        try:
            (run_lr_job if any(l.startswith("mode=") for l in open(sys.argv[2], encoding="utf-8-sig").read().splitlines()) else run_job)(sys.argv[2])
        except Exception:
            import traceback
            traceback.print_exc()
            sys.exit(1)
        return
    global GAMMA_NEG, S_CURVE, SAT, HILITE, CROP_INSET, DEV_THRESHOLD, FIX_BLUE
    global AUTO_EXPOSURE, EXPOSURE, BLUE_SHIFT, TINT, INPUT_SPACE, RAW_BACKEND, DARKTABLE_CLI
    ap = argparse.ArgumentParser(description="Colour negative scan -> positive")
    ap.add_argument("inputs", nargs="+", help="scan file(s); wildcards allowed")
    ap.add_argument("--outdir", help="output folder (default: next to each input)")
    ap.add_argument("--box", nargs=4, type=int, metavar=("X0", "Y0", "X1", "Y1"),
                    help="set the frame manually instead of auto-detecting it")
    ap.add_argument("--check", action="store_true",
                    help="also save <name>_check.jpg with the detected frame (green) and perforations (magenta)")
    ap.add_argument("--gamma", type=float, default=GAMMA_NEG, help="lower = more contrast (default 0.85)")
    ap.add_argument("--scurve", type=float, default=S_CURVE, help="0 = none (default 0.12)")
    ap.add_argument("--sat", type=float, default=SAT, help="saturation (default 1.0)")
    ap.add_argument("--hilite", type=float, default=HILITE,
                    help="highlights: negative pulls them down (Fuji Frontier-like is about -0.09), positive lifts (default 0)")
    ap.add_argument("--inset", type=int, default=CROP_INSET, help="px trimmed inside the frame edge (default 20)")
    ap.add_argument("--threshold", type=float, default=DEV_THRESHOLD,
                    help="frame detection sensitivity (default 0.08)")
    ap.add_argument("--no-fix-blue", action="store_true",
                    help="do not reconstruct the blue channel where it was lost (blue/lavender highlights may appear)")
    ap.add_argument("--no-roll", action="store_true",
                    help="fit the blue model on each file separately instead of on all files of the same film")
    ap.add_argument("--input", choices=("auto", "srgb", "prophoto", "linear"), default=INPUT_SPACE,
                    help="colour space of the scans: auto = read the TIFF's profile (default), or force sRGB / ProPhoto / "
                         "linear (no gamma, sRGB primaries)")
    ap.add_argument("--raw-backend", choices=("auto", "rawpy", "darktable"), default=RAW_BACKEND,
                    help="camera RAW decoder: auto = rawpy if it loads, otherwise darktable-cli (default)")
    ap.add_argument("--darktable", metavar="PATH", default=DARKTABLE_CLI,
                    help="darktable-cli.exe (or the darktable folder); not needed when it is found automatically")
    ap.add_argument("--exposure", type=float, default=EXPOSURE, help="extra exposure in stops (default 0)")
    ap.add_argument("--no-auto-exposure", action="store_true",
                    help="do not lift dark frames automatically (the old behaviour)")
    ap.add_argument("--blue", type=float, default=BLUE_SHIFT,
                    help="colour balance: stops of blue, + = bluer/cooler, - = yellower/warmer (default 0)")
    ap.add_argument("--tint", type=float, default=TINT,
                    help="colour balance: stops of green, + = greener, - = more magenta (default 0)")
    a = ap.parse_args()
    GAMMA_NEG, S_CURVE, SAT, CROP_INSET, DEV_THRESHOLD = a.gamma, a.scurve, a.sat, a.inset, a.threshold
    HILITE = a.hilite
    FIX_BLUE = not a.no_fix_blue
    AUTO_EXPOSURE, EXPOSURE, BLUE_SHIFT, TINT = not a.no_auto_exposure, a.exposure, a.blue, a.tint
    INPUT_SPACE = a.input
    RAW_BACKEND, DARKTABLE_CLI = a.raw_backend, a.darktable

    failed, flagged = [], []
    files = expand(a.inputs)
    if FIX_BLUE and not a.no_roll and files:
        print("\n== analysing all files first (film colour model)")
        prepare_roll(files, a.box)
    for n, f in enumerate(files, 1):
        print(f"\n[{n}/{len(files)}]", end="")
        try:
            if process(f, a.outdir, a.box, a.check):
                flagged.append(f)
        except Exception as e:          # keep going with the other files
            failed.append(f)
            print(f"  ERROR: {e}")
    print("\n==== summary ====")
    print(f"converted: {len(files) - len(failed)} / {len(files)}")
    for f in flagged:
        print("  look at this one (see WARNING above):", f)
    for f in failed:
        print("  FAILED, no file written:", f)
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
